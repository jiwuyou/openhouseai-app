#!/data/data/com.termux/files/usr/bin/sh
set -eu
: "${HOME:?HOME is required}"
runtime="$HOME/.local/share/openhouseai/runtime"
test -x "$runtime/bin/pi"
test -x "$runtime/bin/openhouse-pi-runtime"
test -x "$HOME/.local/bin/openhouse-pi"
test -x "$HOME/.local/bin/openhouse-pi-runtime-start"
"$runtime/bin/pi" --help >/dev/null
"$runtime/bin/openhouse-pi-runtime" --help >/dev/null
printf 'ok: Pi Rust and OpenHouse Pi runtime are installed\n'
