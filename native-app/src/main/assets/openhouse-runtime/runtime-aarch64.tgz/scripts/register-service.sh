#!/data/data/com.termux/files/usr/bin/sh
set -eu
: "${HOME:?HOME is required}"
config_dir="${OPENHOUSEAI_CONFIG_DIR:-$HOME/.config/openhouseai}"
service_dir="$config_dir/service-manager/services.d"
spec="$service_dir/pi-agent.json"
mkdir -p "$service_dir"
tmp=$(mktemp "${TMPDIR:-$PREFIX/tmp}/pi-agent.json.XXXXXX")
cat > "$tmp" <<JSON
{
  "name": "pi-agent",
  "description": "Pi Rust JSONL RPC runtime for OpenHouseAI and WuxianPi",
  "provider": "termux-process",
  "command": ["sh", "-lc", "openhouse-pi-runtime-start & child=\$!; trap 'kill -TERM \$child 2>/dev/null; wait \$child 2>/dev/null || true' TERM INT HUP; wait \$child"],
  "working_dir": "$HOME/workspace",
  "env": {
    "HOME": "$HOME",
    "PATH": "$HOME/.local/bin:${PREFIX:-/data/data/com.termux/files/usr}/bin:/system/bin",
    "OPENHOUSE_PI_RUNTIME_ORIGIN": "http://127.0.0.1:8765",
    "OPENHOUSE_PI_RUNTIME_TOKEN_FILE": "$HOME/.local/share/openhouseai/runtime/state/token"
  },
  "runtime": {"strategy": "termux-process", "runtime": "termux", "platform": "android-arm64"},
  "restart": {"mode": "always", "max_retries": 0},
  "health": [{"type": "tcp", "address": "127.0.0.1:8765", "interval": "15s", "timeout": "3s"}],
  "enabled": true,
  "tags": ["group:local-stack", "openhouseai", "agent", "pi-rust", "openhouse-component:pi-agent"]
}
JSON
python3 -m json.tool "$tmp" >/dev/null
mv "$tmp" "$spec"
printf 'registered: %s\n' "$spec"
