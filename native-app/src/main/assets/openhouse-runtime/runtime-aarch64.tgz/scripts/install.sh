#!/data/data/com.termux/files/usr/bin/sh
set -eu
: "${HOME:?HOME is required}"
root=$(CDPATH= cd "$(dirname "$0")/.." && pwd)
runtime="$HOME/.local/share/openhouseai/runtime"
local_bin="$HOME/.local/bin"
mkdir -p "$runtime/bin" "$runtime/extensions" "$runtime/state" "$local_bin" "$HOME/.pi/agent/sessions" "$HOME/workspace"
install -m 0755 "$root/bin/pi" "$runtime/bin/pi"
install -m 0755 "$root/bin/openhouse-pi-runtime" "$runtime/bin/openhouse-pi-runtime"
install -m 0755 "$root/bin/openhouse-pi" "$local_bin/openhouse-pi"
install -m 0755 "$root/bin/openhouse-pi-runtime-start" "$local_bin/openhouse-pi-runtime-start"
if [ -d "$root/extensions" ]; then
  (cd "$root/extensions" && tar -cf - .) | (cd "$runtime/extensions" && tar -xf -)
fi
"$runtime/bin/pi" --help >/dev/null
"$runtime/bin/openhouse-pi-runtime" --help >/dev/null
printf 'Installed WuxianPi runtime under %s\n' "$runtime"
