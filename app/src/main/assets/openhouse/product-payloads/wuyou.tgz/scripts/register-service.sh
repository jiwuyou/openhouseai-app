#!/bin/sh
set -eu

printf '%s\n' "wuyou is installed as a standalone global command. No service-manager service is registered by default."
