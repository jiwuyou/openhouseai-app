#!/bin/sh
set -eu

die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

command -v wuyou >/dev/null 2>&1 || die "wuyou global command is missing"
wuyou --help >/dev/null 2>&1 || die "wuyou global command failed"

printf '%s\n' "ok: wuyou global command is installed"
