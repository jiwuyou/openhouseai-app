#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

SCRIPT_DIR=$(CDPATH= cd "$(dirname "$0")" && pwd)
ROOT_DIR=$(CDPATH= cd "$SCRIPT_DIR/.." && pwd)
BIN_SRC="$ROOT_DIR/wuyou"
GLOBAL_BIN="${WUYOU_GLOBAL_BIN:-}"

if [ -z "$GLOBAL_BIN" ]; then
  if [ -n "${PREFIX:-}" ] && [ -d "${PREFIX:-}/bin" ]; then
    GLOBAL_BIN="$PREFIX/bin"
  else
    GLOBAL_BIN="${HOME:-/root}/.local/bin"
  fi
fi

[ -f "$BIN_SRC" ] || die "bundled wuyou binary is missing: $BIN_SRC"

mkdir -p "$GLOBAL_BIN"
if command -v install >/dev/null 2>&1; then
  install -m 755 "$BIN_SRC" "$GLOBAL_BIN/wuyou"
else
  cp "$BIN_SRC" "$GLOBAL_BIN/wuyou"
  chmod 755 "$GLOBAL_BIN/wuyou"
fi

"$GLOBAL_BIN/wuyou" --help >/dev/null 2>&1 || die "installed wuyou failed --help"
log "done: wuyou installed at $GLOBAL_BIN/wuyou"
