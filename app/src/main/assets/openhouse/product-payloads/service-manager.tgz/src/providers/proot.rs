use std::{
    collections::HashMap,
    fs,
    io::{Read, Write},
    path::{Path, PathBuf},
    process::Stdio,
    sync::{Mutex, OnceLock},
    time::{Duration, SystemTime},
};

#[cfg(unix)]
use std::os::unix::process::CommandExt;

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::{
    error::Result,
    model::{
        Capability, DetectResult, LogEntry, LogsOptions, Provider, ProviderId, Service,
        ServiceState, ServiceStatus,
    },
};

use super::{bad_request, find_in_path, lossy_stderr, run_command_output};

static PROOT_START_LOCK: Mutex<()> = Mutex::new(());
static PROOT_MONITORS: OnceLock<Mutex<HashMap<String, tokio::task::AbortHandle>>> = OnceLock::new();

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
struct ProcMetaV1 {
    version: u32,
    provider: String,
    service_id: String,
    boot_id: String,
    pid: u32,
    pgid: i32,
    exe: String,
    argv: Vec<String>,
    proc_starttime_ticks: u64,
    created_at: DateTime<Utc>,
}

#[derive(Clone, Debug)]
enum ProcVerify {
    Managed,
    Stale(String),
    Unverifiable(String),
}

#[derive(Clone, Debug)]
struct ObservedRuntimeProcess {
    boot_id: String,
    pid: u32,
    pgid: i32,
    exe: String,
    argv: Vec<String>,
    proc_starttime_ticks: u64,
}

#[derive(Clone, Debug)]
pub struct ProotDistroProvider {
    data_dir: PathBuf,
}

impl ProotDistroProvider {
    pub fn new(data_dir: PathBuf) -> Self {
        Self { data_dir }
    }

    fn termux_bin_dirs() -> Vec<PathBuf> {
        vec![PathBuf::from("/data/data/com.termux/files/usr/bin")]
    }

    fn state_dir(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self
            .data_dir
            .clone()
            .join("providers")
            .join("proot-distro")
            .join(&svc.id.0))
    }

    fn pid_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("pid"))
    }

    fn stdout_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("stdout.log"))
    }

    fn stderr_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("stderr.log"))
    }

    fn started_at_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("started_at"))
    }

    fn meta_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("meta.json"))
    }

    fn orphan_meta_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("orphan-meta.json"))
    }

    fn ensure_dirs(&self, svc: &Service) -> Result<()> {
        fs::create_dir_all(self.state_dir(svc)?)?;
        Ok(())
    }

    fn distro(&self, svc: &Service) -> Result<String> {
        let Some(v) = svc.spec.runtime.get("distro") else {
            return Err(bad_request(
                "runtime.distro is required for proot-distro provider (e.g. \"ubuntu\")",
            ));
        };
        let Some(s) = v.as_str() else {
            return Err(bad_request("runtime.distro must be a string"));
        };
        let s = s.trim();
        if s.is_empty() {
            return Err(bad_request("runtime.distro must be non-empty"));
        }
        Ok(s.to_string())
    }

    fn optional_runtime_string(&self, svc: &Service, key: &str) -> Result<Option<String>> {
        let Some(v) = svc.spec.runtime.get(key) else {
            return Ok(None);
        };
        let Some(s) = v.as_str() else {
            return Err(bad_request(format!("runtime.{key} must be a string")));
        };
        let s = s.trim();
        if s.is_empty() {
            return Ok(None);
        }
        Ok(Some(s.to_string()))
    }

    fn runtime_user(&self, svc: &Service) -> Result<Option<String>> {
        if let Some(user) = self.optional_runtime_string(svc, "user")? {
            return Ok(Some(user));
        }
        self.optional_runtime_string(svc, "login_user")
    }

    fn runtime_home(&self, svc: &Service) -> Result<Option<String>> {
        self.optional_runtime_string(svc, "home")
    }

    fn read_pid(path: &Path) -> Result<Option<u32>> {
        let mut f = match fs::File::open(path) {
            Ok(f) => f,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Err(e) => return Err(crate::error::AppError::Io(e)),
        };
        let mut s = String::new();
        f.read_to_string(&mut s)?;
        let s = s.trim();
        if s.is_empty() {
            return Ok(None);
        }
        let pid: u32 = s
            .parse()
            .map_err(|_| bad_request(format!("invalid pid file contents: {s:?}")))?;
        Ok(Some(pid))
    }

    fn write_pid(path: &Path, pid: u32) -> Result<()> {
        let mut f = fs::File::create(path)?;
        writeln!(f, "{pid}")?;
        Ok(())
    }

    fn write_started_at(path: &Path, t: DateTime<Utc>) -> Result<()> {
        let mut f = fs::File::create(path)?;
        writeln!(f, "{}", t.to_rfc3339())?;
        Ok(())
    }

    fn read_started_at(path: &Path) -> Result<Option<DateTime<Utc>>> {
        let mut f = match fs::File::open(path) {
            Ok(f) => f,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Err(e) => return Err(crate::error::AppError::Io(e)),
        };
        let mut s = String::new();
        f.read_to_string(&mut s)?;
        let s = s.trim();
        if s.is_empty() {
            return Ok(None);
        }
        let dt = DateTime::parse_from_rfc3339(s)
            .map_err(|e| bad_request(format!("invalid started_at file: {e}")))?
            .with_timezone(&Utc);
        Ok(Some(dt))
    }

    async fn pid_is_alive(&self, pid: u32) -> Result<bool> {
        #[cfg(unix)]
        {
            Ok(Self::proc_state_parent_and_pgrp(pid).is_some_and(|(state, _, _)| state != 'Z'))
        }
        #[cfg(not(unix))]
        {
            let _ = pid;
            Ok(false)
        }
    }

    async fn process_group_is_alive(&self, pgid: i32) -> Result<bool> {
        #[cfg(unix)]
        {
            let Ok(entries) = fs::read_dir(Self::proc_root()) else {
                return Ok(false);
            };
            for entry in entries.flatten() {
                let Some(name) = entry.file_name().to_str().map(str::to_string) else {
                    continue;
                };
                let Ok(pid) = name.parse::<u32>() else {
                    continue;
                };
                if Self::proc_state_parent_and_pgrp(pid)
                    .is_some_and(|(state, _, observed_pgid)| state != 'Z' && observed_pgid == pgid)
                {
                    return Ok(true);
                }
            }
            Ok(false)
        }
        #[cfg(not(unix))]
        {
            let _ = pgid;
            Ok(false)
        }
    }

    async fn signal_process_group(&self, pgid: i32, signal: &str) -> Result<()> {
        #[cfg(unix)]
        {
            let out = run_command_output(
                "kill".to_string(),
                vec![signal.to_string(), "--".to_string(), format!("-{pgid}")],
            )
            .await?;
            if !out.status.success() && self.process_group_is_alive(pgid).await.unwrap_or(true) {
                return Err(bad_request(format!(
                    "kill {signal} -- -{pgid} failed: {}",
                    lossy_stderr(&out)
                )));
            }
            Ok(())
        }
        #[cfg(not(unix))]
        {
            let _ = (pgid, signal);
            Err(bad_request(
                "proot-distro provider is only supported on unix",
            ))
        }
    }

    async fn wait_for_process_group_exit(&self, pgid: i32, timeout: Duration) -> Result<bool> {
        #[cfg(unix)]
        {
            let deadline = tokio::time::Instant::now() + timeout;
            loop {
                if !self.process_group_is_alive(pgid).await.unwrap_or(false) {
                    return Ok(true);
                }
                if tokio::time::Instant::now() >= deadline {
                    return Ok(false);
                }
                tokio::time::sleep(Duration::from_millis(50)).await;
            }
        }
        #[cfg(not(unix))]
        {
            let _ = (pgid, timeout);
            Ok(false)
        }
    }

    async fn terminate_process_group_with_timeouts(
        &self,
        pgid: i32,
        term_timeout: Duration,
        kill_timeout: Duration,
    ) -> Result<()> {
        if !self.process_group_is_alive(pgid).await? {
            return Ok(());
        }
        self.signal_process_group(pgid, "-TERM").await?;
        if self.wait_for_process_group_exit(pgid, term_timeout).await? {
            return Ok(());
        }
        self.signal_process_group(pgid, "-KILL").await?;
        if self.wait_for_process_group_exit(pgid, kill_timeout).await? {
            return Ok(());
        }
        Err(bad_request(format!(
            "proot process group remains alive after SIGTERM and SIGKILL: pgid={pgid}"
        )))
    }

    async fn terminate_process_group(&self, pgid: i32) -> Result<()> {
        self.terminate_process_group_with_timeouts(
            pgid,
            Duration::from_secs(5),
            Duration::from_secs(2),
        )
        .await
    }

    fn proot_distro_exe_for(&self, svc: &Service) -> Result<String> {
        if let Some(v) = svc.spec.runtime.get("proot_distro_path") {
            let Some(s) = v.as_str() else {
                return Err(bad_request("runtime.proot_distro_path must be a string"));
            };
            let s = s.trim();
            if s.is_empty() {
                return Err(bad_request("runtime.proot_distro_path must be non-empty"));
            }
            return Ok(s.to_string());
        }

        if let Some(path) = find_in_path("proot-distro", &[]) {
            return Ok(path.to_string_lossy().to_string());
        }
        find_in_path("proot-distro", &Self::termux_bin_dirs())
            .map(|p| p.to_string_lossy().to_string())
            .ok_or_else(|| bad_request("proot-distro not found"))
    }

    fn build_login_command(&self, svc: &Service) -> Result<(String, Vec<String>)> {
        let exe = self.proot_distro_exe_for(svc)?;
        let distro = self.distro(svc)?;
        let user = self.runtime_user(svc)?;
        let home = self.runtime_home(svc)?;

        // proot-distro login <distro> -- <command...>
        if svc.spec.command.is_empty() {
            return Err(bad_request("command is required"));
        }
        let mut args = vec!["login".to_string(), distro];
        if let Some(user) = user {
            args.extend(["--user".to_string(), user]);
        }
        args.push("--".to_string());
        let guest_working_dir = svc.spec.working_dir.trim();
        if let Some(home) = home {
            let guest_working_dir = if guest_working_dir.is_empty() {
                home.clone()
            } else {
                guest_working_dir.to_string()
            };
            args.extend([
                "sh".to_string(),
                "-lc".to_string(),
                "export HOME=\"$1\" && shift && cd \"$1\" && shift && exec \"$@\"".to_string(),
                "service-manager-proot".to_string(),
                home,
                guest_working_dir,
            ]);
            args.extend(svc.spec.command.iter().cloned());
        } else if guest_working_dir.is_empty() {
            args.extend(svc.spec.command.iter().cloned());
        } else {
            args.extend([
                "sh".to_string(),
                "-lc".to_string(),
                "cd \"$1\" && shift && exec \"$@\"".to_string(),
                "service-manager-proot".to_string(),
                guest_working_dir.to_string(),
            ]);
            args.extend(svc.spec.command.iter().cloned());
        }
        Ok((exe, args))
    }

    fn slice_log_lines(s: &str, limit: Option<usize>) -> Vec<&str> {
        let mut lines: Vec<&str> = s.lines().collect();
        if let Some(n) = limit
            && lines.len() > n
        {
            lines = lines[lines.len() - n..].to_vec();
        }
        lines
    }

    fn proc_root() -> PathBuf {
        if let Ok(v) = std::env::var("SERVICE_MANAGER_PROCFS_ROOT") {
            let v = v.trim().to_string();
            if !v.is_empty() {
                return PathBuf::from(v);
            }
        }
        PathBuf::from("/proc")
    }

    fn proc_stat_starttime_from_str(s: &str) -> Option<u64> {
        let end = s.rfind(')')?;
        let after = s[end + 1..].trim();
        let mut it = after.split_whitespace();
        let _state = it.next()?;
        for _ in 0..18 {
            it.next()?;
        }
        it.next()?.parse::<u64>().ok()
    }

    fn proc_stat_state_parent_and_pgrp_from_str(s: &str) -> Option<(char, u32, i32)> {
        let end = s.rfind(')')?;
        let after = s[end + 1..].trim();
        let mut it = after.split_whitespace();
        let state = it.next()?.chars().next()?;
        let ppid = it.next()?.parse::<u32>().ok()?;
        let pgrp = it.next()?.parse::<i32>().ok()?;
        Some((state, ppid, pgrp))
    }

    fn proc_starttime_ticks(pid: u32) -> Option<u64> {
        let p = Self::proc_root().join(pid.to_string()).join("stat");
        let s = fs::read_to_string(p).ok()?;
        Self::proc_stat_starttime_from_str(&s)
    }

    fn proc_state_parent_and_pgrp(pid: u32) -> Option<(char, u32, i32)> {
        let p = Self::proc_root().join(pid.to_string()).join("stat");
        let s = fs::read_to_string(p).ok()?;
        Self::proc_stat_state_parent_and_pgrp_from_str(&s)
    }

    fn proc_parent_and_pgrp(pid: u32) -> Option<(u32, i32)> {
        Self::proc_state_parent_and_pgrp(pid).map(|(_, ppid, pgrp)| (ppid, pgrp))
    }

    fn proc_boot_id() -> Option<String> {
        let path = Self::proc_root()
            .join("sys")
            .join("kernel")
            .join("random")
            .join("boot_id");
        let boot_id = fs::read_to_string(path).ok()?;
        let boot_id = boot_id.trim();
        if boot_id.is_empty() {
            None
        } else {
            Some(boot_id.to_string())
        }
    }

    fn proc_exe(pid: u32) -> Option<String> {
        let path = Self::proc_root().join(pid.to_string()).join("exe");
        fs::canonicalize(&path)
            .or_else(|_| fs::read_link(&path))
            .ok()
            .map(|value| value.to_string_lossy().to_string())
    }

    fn proc_cwd(pid: u32) -> Option<PathBuf> {
        let path = Self::proc_root().join(pid.to_string()).join("cwd");
        fs::canonicalize(path).ok()
    }

    fn runtime_pid_candidates(launch_pid: u32) -> Vec<u32> {
        let mut out = vec![launch_pid];
        let Ok(entries) = fs::read_dir(Self::proc_root()) else {
            return out;
        };
        for entry in entries.flatten() {
            let Some(name) = entry.file_name().to_str().map(|s| s.to_string()) else {
                continue;
            };
            let Ok(pid) = name.parse::<u32>() else {
                continue;
            };
            if pid == launch_pid {
                continue;
            }
            let Some((ppid, pgrp)) = Self::proc_parent_and_pgrp(pid) else {
                continue;
            };
            if ppid == launch_pid || pgrp == launch_pid as i32 {
                out.push(pid);
            }
        }
        out
    }

    fn proc_cmdline(pid: u32) -> Option<Vec<String>> {
        let p = Self::proc_root().join(pid.to_string()).join("cmdline");
        let b = fs::read(p).ok()?;
        if b.is_empty() {
            return None;
        }
        let mut out = Vec::new();
        for part in b.split(|c| *c == 0u8) {
            if part.is_empty() {
                continue;
            }
            out.push(String::from_utf8_lossy(part).to_string());
        }
        if out.is_empty() { None } else { Some(out) }
    }

    fn read_meta(path: &Path) -> Option<ProcMetaV1> {
        let b = fs::read(path).ok()?;
        serde_json::from_slice::<ProcMetaV1>(&b).ok()
    }

    fn read_meta_with_fallback(meta_path: &Path, orphan_meta_path: &Path) -> Option<ProcMetaV1> {
        Self::read_meta(meta_path).or_else(|| Self::read_meta(orphan_meta_path))
    }

    fn write_meta(path: &Path, meta: &ProcMetaV1) -> Result<()> {
        let b = serde_json::to_vec_pretty(meta).map_err(crate::error::AppError::Json)?;
        fs::write(path, b)?;
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    fn verify_pid_with_obs(
        svc: &Service,
        pid: u32,
        meta: Option<&ProcMetaV1>,
        boot_id: Option<String>,
        start: Option<u64>,
        pgrp: Option<i32>,
        exe: Option<String>,
        cmdline: Option<Vec<String>>,
    ) -> ProcVerify {
        let Some(meta) = meta else {
            return ProcVerify::Unverifiable("missing meta.json".to_string());
        };

        if meta.pid != pid {
            return ProcVerify::Stale("pid mismatch".to_string());
        }
        if meta.provider != "proot-distro" {
            return ProcVerify::Stale(format!("provider mismatch: {}", meta.provider));
        }
        if meta.service_id != svc.id.0 {
            return ProcVerify::Stale("service_id mismatch".to_string());
        }

        match boot_id {
            Some(current) if current == meta.boot_id => {}
            Some(current) => {
                return ProcVerify::Stale(format!(
                    "boot_id mismatch: recorded {}, observed {current}",
                    meta.boot_id
                ));
            }
            None => {
                return ProcVerify::Unverifiable(
                    "boot_id unavailable; refusing to manage pid".to_string(),
                );
            }
        }

        match start {
            Some(observed) if meta.proc_starttime_ticks != observed => {
                return ProcVerify::Stale("proc starttime mismatch".to_string());
            }
            None => {
                return ProcVerify::Unverifiable(
                    "proc starttime unavailable; refusing to manage pid".to_string(),
                );
            }
            _ => {}
        }

        match pgrp {
            Some(actual_pgid) if actual_pgid == meta.pgid => {}
            Some(actual_pgid) => {
                return ProcVerify::Unverifiable(format!(
                    "process group changed: expected {}, observed {actual_pgid}",
                    meta.pgid
                ));
            }
            None => {
                return ProcVerify::Unverifiable(
                    "proc process group unavailable; refusing to manage pid".to_string(),
                );
            }
        }

        match exe {
            Some(actual_exe) if actual_exe == meta.exe => {}
            Some(actual_exe) => {
                return ProcVerify::Unverifiable(format!(
                    "executable identity mismatch: recorded {:?}, observed {:?}",
                    meta.exe, actual_exe
                ));
            }
            None => {
                return ProcVerify::Unverifiable(
                    "proc executable identity unavailable; refusing to manage pid".to_string(),
                );
            }
        }

        // Node and other runtimes may rewrite their process title. The launch argv remains useful
        // for diagnostics, but PID + starttime + process group are the management identity.
        let _ = cmdline;

        ProcVerify::Managed
    }

    fn cmdline_matches_proot_runtime(
        svc: &Service,
        launch_argv: &[String],
        pid: u32,
        cmdline: &[String],
    ) -> bool {
        let Some(distro) = svc.spec.runtime.get("distro").and_then(|v| v.as_str()) else {
            return false;
        };
        let joined = cmdline.join(" ");

        let has_proot_loader = cmdline.iter().take(3).any(|arg| {
            Path::new(arg)
                .file_name()
                .and_then(|v| v.to_str())
                .is_some_and(|name| name == "proot")
        });
        if !has_proot_loader {
            return false;
        }

        let rootfs_markers = [
            format!("/containers/{distro}/rootfs"),
            format!("/installed-rootfs/{distro}"),
        ];
        let has_absolute_rootfs = joined.contains("--rootfs=")
            && rootfs_markers.iter().any(|m| joined.contains(m));
        let has_relative_rootfs = cmdline.iter().any(|arg| arg == "--rootfs=.")
            && Self::proc_cwd(pid).is_some_and(|cwd| {
                let cwd = cwd.to_string_lossy();
                rootfs_markers.iter().any(|marker| cwd.contains(marker))
            });
        if !has_absolute_rootfs && !has_relative_rootfs {
            return false;
        }

        let Some(separator) = launch_argv.iter().position(|arg| arg == "--") else {
            return false;
        };
        let command = &launch_argv[separator + 1..];
        !command.is_empty()
            && command
                .iter()
                .filter(|arg| !arg.is_empty())
                .all(|arg| joined.contains(arg))
    }

    #[allow(clippy::collapsible_if)]
    fn observe_runtime_process(
        svc: &Service,
        launch_argv: &[String],
        launch_pid: u32,
    ) -> Result<ObservedRuntimeProcess> {
        let boot_id = Self::proc_boot_id()
            .ok_or_else(|| bad_request("boot_id unavailable while observing proot runtime"))?;
        let mut previous_identity: Option<(u32, i32, u64, String)> = None;
        for _ in 0..40 {
            for pid in Self::runtime_pid_candidates(launch_pid) {
                if let Some(argv) = Self::proc_cmdline(pid)
                    && Self::cmdline_matches_proot_runtime(svc, launch_argv, pid, &argv)
                {
                    if let (Some(proc_starttime_ticks), Some((_, pgid)), Some(exe)) = (
                        Self::proc_starttime_ticks(pid),
                        Self::proc_parent_and_pgrp(pid),
                        Self::proc_exe(pid),
                    ) {
                        let identity = (pid, pgid, proc_starttime_ticks, exe.clone());
                        if previous_identity.as_ref() == Some(&identity) {
                            return Ok(ObservedRuntimeProcess {
                                boot_id,
                                pid,
                                pgid,
                                exe,
                                argv,
                                proc_starttime_ticks,
                            });
                        }
                        previous_identity = Some(identity);
                    }
                }
            }
            std::thread::sleep(Duration::from_millis(50));
        }

        Err(bad_request(
            "spawned proot-distro process did not expose a matching proot runtime cmdline",
        ))
    }

    fn verify_pid(svc: &Service, pid: u32, meta: Option<&ProcMetaV1>) -> ProcVerify {
        let boot_id = Self::proc_boot_id();
        let start = Self::proc_starttime_ticks(pid);
        let pgrp = Self::proc_parent_and_pgrp(pid).map(|(_, pgrp)| pgrp);
        let exe = Self::proc_exe(pid);
        let cmdline = Self::proc_cmdline(pid);
        Self::verify_pid_with_obs(svc, pid, meta, boot_id, start, pgrp, exe, cmdline)
    }

    fn verify_runtime_identity(meta: &ProcMetaV1) -> ProcVerify {
        match Self::proc_boot_id() {
            Some(current) if current == meta.boot_id => {}
            Some(_) => return ProcVerify::Stale("boot_id mismatch".to_string()),
            None => {
                return ProcVerify::Unverifiable(
                    "boot_id unavailable; refusing to manage proot runtime".to_string(),
                );
            }
        }
        match Self::proc_starttime_ticks(meta.pid) {
            Some(current) if current == meta.proc_starttime_ticks => {}
            Some(_) => return ProcVerify::Stale("proc starttime mismatch".to_string()),
            None => {
                return ProcVerify::Unverifiable(
                    "proc starttime unavailable; refusing to manage proot runtime".to_string(),
                );
            }
        }
        match Self::proc_parent_and_pgrp(meta.pid).map(|(_, pgid)| pgid) {
            Some(current) if current == meta.pgid => {}
            Some(current) => {
                return ProcVerify::Unverifiable(format!(
                    "process group changed: expected {}, observed {current}",
                    meta.pgid
                ));
            }
            None => {
                return ProcVerify::Unverifiable(
                    "proc process group unavailable; refusing to manage proot runtime".to_string(),
                );
            }
        }
        match Self::proc_exe(meta.pid) {
            Some(current) if current == meta.exe => ProcVerify::Managed,
            Some(current) => ProcVerify::Unverifiable(format!(
                "executable identity mismatch: recorded {:?}, observed {:?}",
                meta.exe, current
            )),
            None => ProcVerify::Unverifiable(
                "proc executable identity unavailable; refusing to manage proot runtime"
                    .to_string(),
            ),
        }
    }

    async fn verify_dead_leader_group(&self, meta: Option<&ProcMetaV1>) -> ProcVerify {
        let Some(meta) = meta else {
            return ProcVerify::Unverifiable(
                "proot leader exited and process metadata is missing".to_string(),
            );
        };
        match Self::proc_boot_id() {
            Some(current) if current == meta.boot_id => {}
            Some(_) => return ProcVerify::Stale("boot_id mismatch".to_string()),
            None => {
                return ProcVerify::Unverifiable(
                    "boot_id unavailable while checking exited proot leader".to_string(),
                );
            }
        }
        if self.process_group_is_alive(meta.pgid).await.unwrap_or(true) {
            ProcVerify::Unverifiable(format!(
                "proot leader pid {} exited but process group {} remains alive (orphan)",
                meta.pid, meta.pgid
            ))
        } else {
            ProcVerify::Stale("proot leader and process group exited".to_string())
        }
    }

    fn cleanup_stale(
        pid_path: &Path,
        meta_path: &Path,
        orphan_meta_path: &Path,
        started_at_path: &Path,
    ) {
        let _ = fs::remove_file(pid_path);
        let _ = fs::remove_file(meta_path);
        let _ = fs::remove_file(orphan_meta_path);
        let _ = fs::remove_file(started_at_path);
    }

    fn cleanup_stale_if_matches(
        expected: &ProcMetaV1,
        pid_path: &Path,
        meta_path: &Path,
        orphan_meta_path: &Path,
        started_at_path: &Path,
    ) {
        if Self::read_meta_with_fallback(meta_path, orphan_meta_path).as_ref() == Some(expected) {
            Self::cleanup_stale(pid_path, meta_path, orphan_meta_path, started_at_path);
        }
    }

    fn append_reaper_error(stderr_path: &Path, message: &str) {
        if let Ok(mut file) = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(stderr_path)
        {
            let _ = writeln!(file, "[service-manager proot reaper] {message}");
        }
    }

    fn monitor_registry() -> &'static Mutex<HashMap<String, tokio::task::AbortHandle>> {
        PROOT_MONITORS.get_or_init(|| Mutex::new(HashMap::new()))
    }

    fn monitor_key(meta_path: &Path, meta: &ProcMetaV1) -> String {
        format!(
            "{}:{}:{}:{}",
            meta_path.display(),
            meta.boot_id,
            meta.pid,
            meta.proc_starttime_ticks
        )
    }

    fn ensure_runtime_monitor(
        &self,
        meta: ProcMetaV1,
        pid_path: PathBuf,
        meta_path: PathBuf,
        orphan_meta_path: PathBuf,
        started_at_path: PathBuf,
        stderr_path: PathBuf,
    ) -> Result<()> {
        let key = Self::monitor_key(&meta_path, &meta);
        let mut registry = Self::monitor_registry()
            .lock()
            .map_err(|_| bad_request("proot monitor registry lock poisoned"))?;
        registry.retain(|_, handle| !handle.is_finished());
        if registry.contains_key(&key) {
            return Ok(());
        }

        let provider = self.clone();
        let task = tokio::spawn(async move {
            loop {
                tokio::time::sleep(Duration::from_millis(100)).await;
                if provider.pid_is_alive(meta.pid).await.unwrap_or(false) {
                    match Self::verify_runtime_identity(&meta) {
                        ProcVerify::Managed => continue,
                        ProcVerify::Stale(reason) | ProcVerify::Unverifiable(reason) => {
                            Self::append_reaper_error(
                                &stderr_path,
                                &format!(
                                    "proot runtime identity changed; metadata retained as orphan: {reason}"
                                ),
                            );
                            break;
                        }
                    }
                }
                match provider.terminate_process_group(meta.pgid).await {
                    Ok(()) => Self::cleanup_stale_if_matches(
                        &meta,
                        &pid_path,
                        &meta_path,
                        &orphan_meta_path,
                        &started_at_path,
                    ),
                    Err(error) => Self::append_reaper_error(
                        &stderr_path,
                        &format!(
                            "unable to clean process group {}; metadata retained: {error}",
                            meta.pgid
                        ),
                    ),
                }
                break;
            }
        });
        registry.insert(key, task.abort_handle());
        Ok(())
    }
}

#[async_trait]
impl Provider for ProotDistroProvider {
    fn id(&self) -> ProviderId {
        ProviderId("proot-distro".to_string())
    }

    fn display_name(&self) -> String {
        "Termux proot-distro".to_string()
    }

    fn description(&self) -> String {
        "Spawn a service command inside a Termux proot-distro environment (login -- <cmd...>) and track it via PID/log files under the service-manager data dir."
            .to_string()
    }

    fn capabilities(&self) -> Vec<Capability> {
        vec![
            Capability::Register,
            Capability::Unregister,
            Capability::Start,
            Capability::Stop,
            Capability::Restart,
            Capability::Status,
            Capability::Logs,
        ]
    }

    async fn detect(&self) -> Result<DetectResult> {
        let found = find_in_path("proot-distro", &[]).is_some()
            || find_in_path("proot-distro", &Self::termux_bin_dirs()).is_some();
        if !found {
            return Ok(DetectResult {
                detected: false,
                details: "proot-distro not found".to_string(),
            });
        }
        Ok(DetectResult {
            detected: true,
            details: "ok".to_string(),
        })
    }

    async fn register(&self, svc: &Service) -> Result<()> {
        self.ensure_dirs(svc)?;
        // Validate required runtime options early.
        let _ = self.distro(svc)?;
        let _ = self.runtime_user(svc)?;
        let _ = self.runtime_home(svc)?;
        Ok(())
    }

    async fn unregister(&self, svc: &Service) -> Result<()> {
        self.stop(svc).await?;
        let dir = self.state_dir(svc)?;
        let _ = fs::remove_dir_all(&dir);
        Ok(())
    }

    async fn start(&self, svc: &Service) -> Result<()> {
        self.ensure_dirs(svc)?;
        let pid_path = self.pid_path(svc)?;
        let meta_path = self.meta_path(svc)?;
        let orphan_meta_path = self.orphan_meta_path(svc)?;
        let started_at_path = self.started_at_path(svc)?;
        let existing_meta = Self::read_meta_with_fallback(&meta_path, &orphan_meta_path);
        let existing_pid =
            Self::read_pid(&pid_path)?.or_else(|| existing_meta.as_ref().map(|m| m.pid));
        if let Some(pid) = existing_pid {
            if !self.pid_is_alive(pid).await.unwrap_or(false) {
                match self.verify_dead_leader_group(existing_meta.as_ref()).await {
                    ProcVerify::Stale(_) => Self::cleanup_stale(
                        &pid_path,
                        &meta_path,
                        &orphan_meta_path,
                        &started_at_path,
                    ),
                    ProcVerify::Unverifiable(reason) => {
                        return Err(bad_request(format!(
                            "refusing to start: previous proot leader is unavailable and its process group cannot be safely replaced: pid={pid} ({reason})"
                        )));
                    }
                    ProcVerify::Managed => unreachable!(),
                }
            } else {
                match Self::verify_pid(svc, pid, existing_meta.as_ref()) {
                    ProcVerify::Managed => {
                        let meta = existing_meta
                            .clone()
                            .expect("managed proot process has metadata");
                        self.ensure_runtime_monitor(
                            meta,
                            pid_path.clone(),
                            meta_path.clone(),
                            orphan_meta_path.clone(),
                            started_at_path.clone(),
                            self.stderr_path(svc)?,
                        )?;
                        return Ok(());
                    }
                    ProcVerify::Stale(_) => Self::cleanup_stale(
                        &pid_path,
                        &meta_path,
                        &orphan_meta_path,
                        &started_at_path,
                    ),
                    ProcVerify::Unverifiable(reason) => {
                        return Err(bad_request(format!(
                            "refusing to start: existing pidfile points to a live process but identity cannot be verified: pid={pid} ({reason})"
                        )));
                    }
                }
            }
        }

        let stdout = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(self.stdout_path(svc)?)?;
        let stderr = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(self.stderr_path(svc)?)?;

        let (exe, args) = self.build_login_command(svc)?;
        let mut argv = Vec::with_capacity(1 + args.len());
        argv.push(exe.clone());
        argv.extend(args.iter().cloned());

        let (mut child, launch_pid, observed_result) = {
            let _start_guard = PROOT_START_LOCK
                .lock()
                .map_err(|_| bad_request("proot-distro start lock poisoned"))?;
            let mut cmd = std::process::Command::new(&exe);
            cmd.args(args.iter());
            for (k, v) in &svc.spec.env {
                cmd.env(k, v);
            }
            cmd.stdin(Stdio::null());
            cmd.stdout(Stdio::from(stdout));
            cmd.stderr(Stdio::from(stderr));

            #[cfg(unix)]
            {
                cmd.process_group(0);
            }

            let child = cmd
                .spawn()
                .map_err(|e| bad_request(format!("spawn proot-distro: {e}")))?;
            let launch_pid = child.id();
            let observed = Self::observe_runtime_process(svc, &argv, launch_pid);
            (child, launch_pid, observed)
        };

        let observed = match observed_result {
            Ok(observed) => observed,
            Err(error) => {
                let rollback = self.terminate_process_group(launch_pid as i32).await;
                if rollback.is_ok() {
                    let _ = tokio::task::spawn_blocking(move || child.wait()).await;
                }
                return match rollback {
                    Ok(()) => Err(bad_request(format!(
                        "failed to observe proot runtime; launch process group rolled back: {error}"
                    ))),
                    Err(rollback_error) => Err(bad_request(format!(
                        "failed to observe proot runtime and rollback could not confirm process-group exit; manual cleanup required: launch_pid={launch_pid}, pgid={launch_pid}: {error}; rollback: {rollback_error}"
                    ))),
                };
            }
        };
        if observed.pgid != launch_pid as i32 {
            let rollback = self.terminate_process_group(launch_pid as i32).await;
            if rollback.is_ok() {
                let _ = tokio::task::spawn_blocking(move || child.wait()).await;
            }
            return match rollback {
                Ok(()) => Err(bad_request(format!(
                    "observed proot runtime escaped its launch process group; rolled back: launch_pid={launch_pid}, runtime_pid={}, runtime_pgid={}",
                    observed.pid, observed.pgid
                ))),
                Err(rollback_error) => Err(bad_request(format!(
                    "observed proot runtime escaped its launch process group and rollback failed; manual cleanup required: launch_pid={launch_pid}, runtime_pid={}, runtime_pgid={}: {rollback_error}",
                    observed.pid, observed.pgid
                ))),
            };
        }

        let meta = ProcMetaV1 {
            version: 2,
            provider: "proot-distro".to_string(),
            service_id: svc.id.0.clone(),
            boot_id: observed.boot_id,
            pid: observed.pid,
            pgid: observed.pgid,
            exe: observed.exe,
            argv: observed.argv,
            proc_starttime_ticks: observed.proc_starttime_ticks,
            created_at: Utc::now(),
        };
        let persist_result = (|| -> Result<()> {
            Self::write_meta(&meta_path, &meta)?;
            Self::write_pid(&pid_path, meta.pid)?;
            Self::write_started_at(&started_at_path, meta.created_at)?;
            Ok(())
        })();
        if let Err(error) = persist_result {
            let _ = Self::write_meta(&orphan_meta_path, &meta);
            let rollback = self.terminate_process_group(meta.pgid).await;
            if rollback.is_ok() {
                let _ = tokio::task::spawn_blocking(move || child.wait()).await;
                Self::cleanup_stale(&pid_path, &meta_path, &orphan_meta_path, &started_at_path);
            }
            return match rollback {
                Ok(()) => Err(bad_request(format!(
                    "failed to persist proot metadata; spawned process group was rolled back: {error}"
                ))),
                Err(rollback_error) => Err(bad_request(format!(
                    "failed to persist proot metadata and rollback could not confirm process-group exit; metadata retained at {:?} / {:?}, runtime_pid={}, pgid={}: {error}; rollback: {rollback_error}",
                    meta_path, orphan_meta_path, meta.pid, meta.pgid
                ))),
            };
        }

        if let Err(monitor_error) = self.ensure_runtime_monitor(
            meta.clone(),
            pid_path.clone(),
            meta_path.clone(),
            orphan_meta_path.clone(),
            started_at_path.clone(),
            self.stderr_path(svc)?,
        ) {
            let rollback = self.terminate_process_group(meta.pgid).await;
            if rollback.is_ok() {
                Self::cleanup_stale_if_matches(
                    &meta,
                    &pid_path,
                    &meta_path,
                    &orphan_meta_path,
                    &started_at_path,
                );
            }
            let _ = tokio::task::spawn_blocking(move || child.wait()).await;
            return match rollback {
                Ok(()) => Err(bad_request(format!(
                    "failed to establish proot monitor; process group rolled back: {monitor_error}"
                ))),
                Err(rollback_error) => Err(bad_request(format!(
                    "failed to establish proot monitor and rollback could not confirm process-group exit; metadata retained: {monitor_error}; rollback: {rollback_error}"
                ))),
            };
        }
        tokio::spawn(async move {
            let _ = tokio::task::spawn_blocking(move || child.wait()).await;
        });

        Ok(())
    }

    async fn stop(&self, svc: &Service) -> Result<()> {
        let pid_path = self.pid_path(svc)?;
        let meta_path = self.meta_path(svc)?;
        let orphan_meta_path = self.orphan_meta_path(svc)?;
        let started_at_path = self.started_at_path(svc)?;
        let meta = Self::read_meta_with_fallback(&meta_path, &orphan_meta_path);
        let Some(pid) = Self::read_pid(&pid_path)?.or_else(|| meta.as_ref().map(|m| m.pid)) else {
            return Ok(());
        };
        if !self.pid_is_alive(pid).await.unwrap_or(false) {
            return match self.verify_dead_leader_group(meta.as_ref()).await {
                ProcVerify::Stale(_) => {
                    Self::cleanup_stale(&pid_path, &meta_path, &orphan_meta_path, &started_at_path);
                    Ok(())
                }
                ProcVerify::Unverifiable(reason) => Err(bad_request(format!(
                    "refusing to stop orphan proot process group without a live leader identity: pid={pid} ({reason})"
                ))),
                ProcVerify::Managed => unreachable!(),
            };
        }

        match Self::verify_pid(svc, pid, meta.as_ref()) {
            ProcVerify::Managed => {
                let meta = meta.as_ref().expect("managed proot process has metadata");
                self.terminate_process_group(meta.pgid).await?;
                Self::cleanup_stale_if_matches(
                    meta,
                    &pid_path,
                    &meta_path,
                    &orphan_meta_path,
                    &started_at_path,
                );
                Ok(())
            }
            ProcVerify::Stale(_) => {
                Self::cleanup_stale(&pid_path, &meta_path, &orphan_meta_path, &started_at_path);
                Ok(())
            }
            ProcVerify::Unverifiable(reason) => Err(bad_request(format!(
                "refusing to stop: pid identity cannot be verified: pid={pid} ({reason})"
            ))),
        }
    }

    async fn restart(&self, svc: &Service) -> Result<()> {
        self.stop(svc).await?;
        self.start(svc).await
    }

    async fn status(&self, svc: &Service) -> Result<ServiceStatus> {
        let observed_at = Utc::now();
        let pid_path = self.pid_path(svc)?;
        let meta_path = self.meta_path(svc)?;
        let orphan_meta_path = self.orphan_meta_path(svc)?;
        let started_at_path = self.started_at_path(svc)?;
        let started_at = Self::read_started_at(&started_at_path).ok().flatten();
        let meta = Self::read_meta_with_fallback(&meta_path, &orphan_meta_path);
        let Some(pid) = Self::read_pid(&pid_path)?.or_else(|| meta.as_ref().map(|m| m.pid)) else {
            return Ok(ServiceStatus {
                service_id: svc.id.clone(),
                state: ServiceState::Stopped,
                message: "not running".to_string(),
                provider: self.id(),
                observed_at,
                started_at,
                pid: None,
                exit_code: None,
            });
        };

        if !self.pid_is_alive(pid).await.unwrap_or(false) {
            return match self.verify_dead_leader_group(meta.as_ref()).await {
                ProcVerify::Stale(reason) => {
                    Self::cleanup_stale(&pid_path, &meta_path, &orphan_meta_path, &started_at_path);
                    Ok(ServiceStatus {
                        service_id: svc.id.clone(),
                        state: ServiceState::Stopped,
                        message: format!("stale runtime metadata ({reason})"),
                        provider: self.id(),
                        observed_at,
                        started_at,
                        pid: None,
                        exit_code: None,
                    })
                }
                ProcVerify::Unverifiable(reason) => Ok(ServiceStatus {
                    service_id: svc.id.clone(),
                    state: ServiceState::Unknown,
                    message: reason,
                    provider: self.id(),
                    observed_at,
                    started_at,
                    pid: Some(pid),
                    exit_code: None,
                }),
                ProcVerify::Managed => unreachable!(),
            };
        }

        match Self::verify_pid(svc, pid, meta.as_ref()) {
            ProcVerify::Managed => {
                let meta = meta.as_ref().expect("managed proot process has metadata");
                self.ensure_runtime_monitor(
                    meta.clone(),
                    pid_path.clone(),
                    meta_path.clone(),
                    orphan_meta_path.clone(),
                    started_at_path.clone(),
                    self.stderr_path(svc)?,
                )?;
                Ok(ServiceStatus {
                    service_id: svc.id.clone(),
                    state: ServiceState::Running,
                    message: "running".to_string(),
                    provider: self.id(),
                    observed_at,
                    started_at,
                    pid: Some(pid),
                    exit_code: None,
                })
            }
            ProcVerify::Stale(reason) => {
                Self::cleanup_stale(&pid_path, &meta_path, &orphan_meta_path, &started_at_path);
                Ok(ServiceStatus {
                    service_id: svc.id.clone(),
                    state: ServiceState::Stopped,
                    message: format!("stale pidfile ({reason})"),
                    provider: self.id(),
                    observed_at,
                    started_at,
                    pid: None,
                    exit_code: None,
                })
            }
            ProcVerify::Unverifiable(reason) => Ok(ServiceStatus {
                service_id: svc.id.clone(),
                state: ServiceState::Unknown,
                message: format!("pid identity cannot be verified ({reason})"),
                provider: self.id(),
                observed_at,
                started_at,
                pid: Some(pid),
                exit_code: None,
            }),
        }
    }

    async fn logs(&self, svc: &Service, opts: LogsOptions) -> Result<Vec<LogEntry>> {
        let now = DateTime::<Utc>::from(SystemTime::now());
        let limit = opts.limit;
        let mut out = Vec::new();

        let stdout = fs::read_to_string(self.stdout_path(svc)?).unwrap_or_default();
        for line in Self::slice_log_lines(&stdout, limit) {
            if line.trim().is_empty() {
                continue;
            }
            out.push(LogEntry {
                time: now,
                stream: "stdout".to_string(),
                message: line.to_string(),
            });
        }

        let stderr = fs::read_to_string(self.stderr_path(svc)?).unwrap_or_default();
        for line in Self::slice_log_lines(&stderr, limit) {
            if line.trim().is_empty() {
                continue;
            }
            out.push(LogEntry {
                time: now,
                stream: "stderr".to_string(),
                message: line.to_string(),
            });
        }

        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{ProviderId, ServiceId, ServiceSpec};
    use std::collections::BTreeMap;
    use std::sync::Mutex;

    static ENV_LOCK: Mutex<()> = Mutex::new(());

    fn svc() -> Service {
        Service {
            id: ServiceId("svc1".to_string()),
            spec: ServiceSpec {
                name: "demo".to_string(),
                description: String::new(),
                provider: ProviderId("proot-distro".to_string()),
                command: vec!["echo".to_string(), "hi".to_string()],
                working_dir: String::new(),
                env: BTreeMap::new(),
                runtime: BTreeMap::from_iter([
                    (
                        "distro".to_string(),
                        serde_json::Value::String("ubuntu".to_string()),
                    ),
                    (
                        "proot_distro_path".to_string(),
                        serde_json::Value::String("/bin/proot-distro".to_string()),
                    ),
                ]),
                restart: Default::default(),
                health: vec![],
                ports: vec![],
                enabled: true,
                resident_by_default: false,
                tags: vec![],
            },
            created_at: Utc::now(),
            updated_at: Utc::now(),
            deleted_at: None,
        }
    }

    fn meta(svc: &Service) -> ProcMetaV1 {
        ProcMetaV1 {
            version: 2,
            provider: "proot-distro".to_string(),
            service_id: svc.id.0.clone(),
            boot_id: "boot-a".to_string(),
            pid: 100,
            pgid: 100,
            exe: "/usr/bin/proot".to_string(),
            argv: vec!["proot".to_string()],
            proc_starttime_ticks: 111,
            created_at: Utc::now(),
        }
    }

    #[test]
    fn build_login_command_prefixes_proot_distro_login_and_separator() {
        let p = ProotDistroProvider::new(std::env::temp_dir());
        let svc = svc();
        // This test doesn't assert the executable path (depends on PATH), only args shape.
        let (exe, args) = p
            .build_login_command(&svc)
            .unwrap_or_else(|e| panic!("{e}"));
        assert_eq!(exe, "/bin/proot-distro");
        assert_eq!(args[0], "login");
        assert_eq!(args[2], "--");
        assert!(args.ends_with(&["echo".to_string(), "hi".to_string()]));
    }

    #[test]
    fn proot_distro_exe_for_returns_resolved_path_from_path() {
        let _guard = ENV_LOCK.lock().unwrap();
        let old_path = std::env::var_os("PATH");
        let dir = std::env::temp_dir().join(format!(
            "service-manager-proot-path-test-{}",
            std::process::id()
        ));
        fs::create_dir_all(&dir).unwrap();
        let exe = dir.join("proot-distro");
        fs::write(&exe, b"#!/bin/sh\n").unwrap();

        // Rust 2024 marks environment mutation unsafe because it is process-global.
        // The test lock above keeps this unit test's PATH mutation serialized.
        unsafe {
            std::env::set_var("PATH", &dir);
        }

        let p = ProotDistroProvider::new(std::env::temp_dir());
        let mut svc = svc();
        svc.spec.runtime.remove("proot_distro_path");
        assert_eq!(
            p.proot_distro_exe_for(&svc).unwrap(),
            exe.to_string_lossy().to_string()
        );

        match old_path {
            Some(path) => unsafe {
                std::env::set_var("PATH", path);
            },
            None => unsafe {
                std::env::remove_var("PATH");
            },
        }
        let _ = fs::remove_file(exe);
        let _ = fs::remove_dir(dir);
    }

    #[test]
    fn proot_distro_exe_for_prefers_runtime_override() {
        let _guard = ENV_LOCK.lock().unwrap();
        let p = ProotDistroProvider::new(std::env::temp_dir());
        let svc = svc();
        assert_eq!(p.proot_distro_exe_for(&svc).unwrap(), "/bin/proot-distro");
    }

    #[test]
    fn build_login_command_keeps_root_default_shape_without_user() {
        let p = ProotDistroProvider::new(std::env::temp_dir());
        let svc = svc();
        let (_exe, args) = p
            .build_login_command(&svc)
            .unwrap_or_else(|e| panic!("{e}"));
        assert_eq!(
            args,
            vec![
                "login".to_string(),
                "ubuntu".to_string(),
                "--".to_string(),
                "echo".to_string(),
                "hi".to_string(),
            ]
        );
    }

    #[test]
    fn build_login_command_applies_working_dir_inside_guest() {
        let p = ProotDistroProvider::new(std::env::temp_dir());
        let mut svc = svc();
        svc.spec.working_dir = "/root/app".to_string();
        let (_exe, args) = p
            .build_login_command(&svc)
            .unwrap_or_else(|e| panic!("{e}"));
        assert_eq!(args[3], "sh");
        assert_eq!(args[4], "-lc");
        assert_eq!(args[5], "cd \"$1\" && shift && exec \"$@\"");
        assert_eq!(args[7], "/root/app");
        assert!(args.ends_with(&["echo".to_string(), "hi".to_string()]));
    }

    #[test]
    fn build_login_command_adds_runtime_user_and_keeps_working_dir_inside_guest() {
        let p = ProotDistroProvider::new(std::env::temp_dir());
        let mut svc = svc();
        svc.spec.working_dir = "/home/alice/app".to_string();
        svc.spec.runtime.insert(
            "user".to_string(),
            serde_json::Value::String("alice".to_string()),
        );
        let (_exe, args) = p
            .build_login_command(&svc)
            .unwrap_or_else(|e| panic!("{e}"));
        assert_eq!(args[0], "login");
        assert_eq!(args[1], "ubuntu");
        assert_eq!(args[2], "--user");
        assert_eq!(args[3], "alice");
        assert_eq!(args[4], "--");
        assert_eq!(args[5], "sh");
        assert_eq!(args[6], "-lc");
        assert_eq!(args[7], "cd \"$1\" && shift && exec \"$@\"");
        assert_eq!(args[9], "/home/alice/app");
        assert!(args.ends_with(&["echo".to_string(), "hi".to_string()]));
    }

    #[test]
    fn build_login_command_uses_runtime_home_for_home_and_default_working_dir() {
        let p = ProotDistroProvider::new(std::env::temp_dir());
        let mut svc = svc();
        svc.spec.runtime.insert(
            "user".to_string(),
            serde_json::Value::String("alice".to_string()),
        );
        svc.spec.runtime.insert(
            "home".to_string(),
            serde_json::Value::String("/home/alice".to_string()),
        );
        let (_exe, args) = p
            .build_login_command(&svc)
            .unwrap_or_else(|e| panic!("{e}"));
        assert_eq!(args[2], "--user");
        assert_eq!(args[3], "alice");
        assert_eq!(args[4], "--");
        assert_eq!(args[5], "sh");
        assert_eq!(
            args[7],
            "export HOME=\"$1\" && shift && cd \"$1\" && shift && exec \"$@\""
        );
        assert_eq!(args[9], "/home/alice");
        assert_eq!(args[10], "/home/alice");
        assert!(args.ends_with(&["echo".to_string(), "hi".to_string()]));
    }

    #[test]
    fn proc_stat_starttime_from_str_parses_starttime() {
        let s = "123 (weird comm) R 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 424242";
        assert_eq!(
            ProotDistroProvider::proc_stat_starttime_from_str(s),
            Some(424242)
        );
    }

    #[test]
    fn verify_pid_with_obs_refuses_on_starttime_mismatch() {
        let svc = svc();
        let meta = meta(&svc);

        match ProotDistroProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(222),
            Some(100),
            Some("/usr/bin/proot".to_string()),
            Some(vec!["renamed".to_string()]),
        ) {
            ProcVerify::Stale(reason) => assert!(reason.contains("starttime")),
            other => panic!("expected Stale, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_requires_observed_starttime() {
        let svc = svc();
        let meta = meta(&svc);

        match ProotDistroProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            None,
            Some(100),
            Some("/usr/bin/proot".to_string()),
            Some(vec!["different".to_string()]),
        ) {
            ProcVerify::Unverifiable(reason) => assert!(reason.contains("starttime")),
            other => panic!("expected Unverifiable, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_accepts_observed_runtime_cmdline() {
        let svc = svc();
        let runtime_argv = vec![
            "/data/data/com.termux/files/usr/bin/proot".to_string(),
            "--rootfs=/data/data/com.termux/files/usr/var/lib/proot-distro/containers/ubuntu/rootfs".to_string(),
            "/bin/bash".to_string(),
            "-c".to_string(),
            "echo hi".to_string(),
        ];

        let mut meta = meta(&svc);
        meta.argv = runtime_argv.clone();

        match ProotDistroProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(111),
            Some(100),
            Some("/usr/bin/proot".to_string()),
            Some(runtime_argv),
        ) {
            ProcVerify::Managed => {}
            other => panic!("expected Managed, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_accepts_guest_process_title_change() {
        let svc = svc();
        let meta = meta(&svc);

        match ProotDistroProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(111),
            Some(100),
            Some("/usr/bin/proot".to_string()),
            Some(vec!["/bin/other".to_string(), "echo hi".to_string()]),
        ) {
            ProcVerify::Managed => {}
            other => panic!("expected Managed, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_refuses_changed_proot_process_group() {
        let svc = svc();
        let meta = meta(&svc);

        match ProotDistroProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(111),
            Some(200),
            Some("/usr/bin/proot".to_string()),
            Some(vec!["proot".to_string()]),
        ) {
            ProcVerify::Unverifiable(reason) => assert!(reason.contains("process group changed")),
            other => panic!("expected Unverifiable, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_rejects_executable_change() {
        let svc = svc();
        let meta = meta(&svc);
        match ProotDistroProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(111),
            Some(100),
            Some("/usr/bin/other".to_string()),
            Some(vec!["renamed proot".to_string()]),
        ) {
            ProcVerify::Unverifiable(reason) => assert!(reason.contains("executable")),
            other => panic!("expected Unverifiable, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_rejects_cross_boot_metadata() {
        let svc = svc();
        let meta = meta(&svc);
        match ProotDistroProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-b".to_string()),
            Some(111),
            Some(100),
            Some("/usr/bin/proot".to_string()),
            Some(vec!["renamed proot".to_string()]),
        ) {
            ProcVerify::Stale(reason) => assert!(reason.contains("boot_id")),
            other => panic!("expected Stale, got {other:?}"),
        }
    }

    #[test]
    fn build_login_command_preserves_injected_command_env_and_health() {
        use crate::model::{DurationDef, HealthCheck, HealthCheckType};

        let p = ProotDistroProvider::new(std::env::temp_dir());
        let mut input = svc();
        input.spec.command = vec![
            "/root/.local/bin/aionui-web".to_string(),
            "start".to_string(),
            "--port".to_string(),
            "25809".to_string(),
        ];
        input
            .spec
            .env
            .insert("AIONUI_PORT".to_string(), "25809".to_string());
        input.spec.health = vec![HealthCheck {
            ty: HealthCheckType::Http,
            interval: DurationDef(Duration::from_secs(5)),
            timeout: DurationDef(Duration::from_secs(2)),
            url: "http://127.0.0.1:25809/".to_string(),
            address: String::new(),
        }];
        let original = input.clone();

        let (_exe, args) = p.build_login_command(&input).unwrap();

        assert!(args.ends_with(&original.spec.command));
        assert_eq!(input.spec.env, original.spec.env);
        assert_eq!(input.spec.health, original.spec.health);
    }

    #[test]
    fn service_runtime_metadata_paths_are_isolated() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-proot-isolation-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let provider = ProotDistroProvider::new(data_dir.clone());
        let first = svc();
        let mut second = svc();
        second.id = ServiceId("svc2".to_string());

        let first_meta = provider.meta_path(&first).unwrap();
        let second_meta = provider.meta_path(&second).unwrap();
        assert_ne!(first_meta, second_meta);
        fs::create_dir_all(first_meta.parent().unwrap()).unwrap();
        fs::create_dir_all(second_meta.parent().unwrap()).unwrap();
        fs::write(&first_meta, br#"{"service_id":"svc1"}"#).unwrap();
        fs::write(&second_meta, br#"{"service_id":"svc2"}"#).unwrap();
        assert!(fs::read_to_string(first_meta).unwrap().contains("svc1"));
        assert!(fs::read_to_string(second_meta).unwrap().contains("svc2"));

        let _ = fs::remove_dir_all(data_dir);
    }

    fn write_fake_proot_distro(dir: &Path) -> PathBuf {
        use std::os::unix::fs::PermissionsExt;

        fs::create_dir_all(dir).unwrap();
        let path = dir.join("proot-distro");
        fs::write(
            &path,
            br#"#!/bin/bash
if [ -n "$FAKE_PID_FILE" ]; then
  printf '%s\n' "$$" > "$FAKE_PID_FILE"
fi
exec -a proot /bin/bash -c 'trap "exit 0" TERM INT HUP; while :; do sleep 1; done' --rootfs=/tmp/installed-rootfs/ubuntu echo hi
"#,
        )
        .unwrap();
        let mut permissions = fs::metadata(&path).unwrap().permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(&path, permissions).unwrap();
        path
    }

    #[tokio::test]
    async fn fake_proot_runtime_lifecycle_recovers_and_stops() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-proot-lifecycle-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let fake = write_fake_proot_distro(&data_dir.join("bin"));
        let mut service = svc();
        service.spec.runtime.insert(
            "proot_distro_path".to_string(),
            serde_json::Value::String(fake.to_string_lossy().to_string()),
        );
        let provider = ProotDistroProvider::new(data_dir.clone());

        provider.start(&service).await.unwrap();
        assert_eq!(
            provider.status(&service).await.unwrap().state,
            ServiceState::Running
        );

        let meta_path = provider.meta_path(&service).unwrap();
        let meta = ProotDistroProvider::read_meta(&meta_path).unwrap();
        let monitor_key = ProotDistroProvider::monitor_key(&meta_path, &meta);
        let previous_monitor = ProotDistroProvider::monitor_registry()
            .lock()
            .unwrap()
            .remove(&monitor_key)
            .expect("initial proot monitor");
        previous_monitor.abort();
        tokio::task::yield_now().await;

        let recovered = ProotDistroProvider::new(data_dir.clone());
        assert_eq!(
            recovered.status(&service).await.unwrap().state,
            ServiceState::Running
        );
        assert!(
            ProotDistroProvider::monitor_registry()
                .lock()
                .unwrap()
                .get(&monitor_key)
                .is_some_and(|handle| !handle.is_finished())
        );
        recovered.stop(&service).await.unwrap();
        assert_eq!(
            recovered.status(&service).await.unwrap().state,
            ServiceState::Stopped
        );

        let _ = fs::remove_dir_all(data_dir);
    }

    #[tokio::test]
    async fn exited_proot_leader_with_live_group_is_orphan_and_blocks_start() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-proot-orphan-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let provider = ProotDistroProvider::new(data_dir.clone());
        let service = svc();
        provider.ensure_dirs(&service).unwrap();
        let release = data_dir.join("release-leader");

        let mut command = std::process::Command::new("sh");
        command.args([
            "-c",
            &format!(
                "sleep 30 & while [ ! -f {} ]; do sleep 0.05; done",
                release.to_string_lossy()
            ),
        ]);
        command.process_group(0);
        let mut child = command.spawn().unwrap();
        let pid = child.id();
        let boot_id = ProotDistroProvider::proc_boot_id().unwrap();
        let starttime = ProotDistroProvider::proc_starttime_ticks(pid).unwrap();
        let pgid = ProotDistroProvider::proc_parent_and_pgrp(pid).unwrap().1;
        let exe = ProotDistroProvider::proc_exe(pid).unwrap();
        let meta = ProcMetaV1 {
            version: 2,
            provider: "proot-distro".to_string(),
            service_id: service.id.0.clone(),
            boot_id,
            pid,
            pgid,
            exe,
            argv: vec!["proot".to_string()],
            proc_starttime_ticks: starttime,
            created_at: Utc::now(),
        };
        ProotDistroProvider::write_meta(&provider.meta_path(&service).unwrap(), &meta).unwrap();
        ProotDistroProvider::write_pid(&provider.pid_path(&service).unwrap(), pid).unwrap();
        ProotDistroProvider::write_started_at(
            &provider.started_at_path(&service).unwrap(),
            Utc::now(),
        )
        .unwrap();
        fs::write(&release, b"release\n").unwrap();
        let _ = tokio::task::spawn_blocking(move || child.wait()).await;

        let status = provider.status(&service).await.unwrap();
        assert_eq!(status.state, ServiceState::Unknown);
        assert!(status.message.contains("orphan"));
        assert!(
            provider
                .start(&service)
                .await
                .unwrap_err()
                .to_string()
                .contains("refusing to start")
        );
        assert!(provider.meta_path(&service).unwrap().exists());

        provider.terminate_process_group(meta.pgid).await.unwrap();
        ProotDistroProvider::cleanup_stale(
            &provider.pid_path(&service).unwrap(),
            &provider.meta_path(&service).unwrap(),
            &provider.orphan_meta_path(&service).unwrap(),
            &provider.started_at_path(&service).unwrap(),
        );
        let _ = fs::remove_dir_all(data_dir);
    }

    #[tokio::test]
    async fn proot_persistence_failure_rolls_back_spawned_group() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-proot-persist-failure-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let fake = write_fake_proot_distro(&data_dir.join("bin"));
        let marker = data_dir.join("runtime-pid");
        let mut service = svc();
        service.spec.runtime.insert(
            "proot_distro_path".to_string(),
            serde_json::Value::String(fake.to_string_lossy().to_string()),
        );
        service.spec.env.insert(
            "FAKE_PID_FILE".to_string(),
            marker.to_string_lossy().to_string(),
        );
        let provider = ProotDistroProvider::new(data_dir.clone());
        provider.ensure_dirs(&service).unwrap();
        fs::create_dir(provider.started_at_path(&service).unwrap()).unwrap();

        let error = provider.start(&service).await.unwrap_err().to_string();
        assert!(error.contains("rolled back"));
        let pid: u32 = fs::read_to_string(marker).unwrap().trim().parse().unwrap();
        assert!(!provider.pid_is_alive(pid).await.unwrap());
        assert!(!provider.process_group_is_alive(pid as i32).await.unwrap());
        assert!(!provider.meta_path(&service).unwrap().is_file());
        assert!(!provider.pid_path(&service).unwrap().exists());

        let _ = fs::remove_dir_all(data_dir);
    }
}
