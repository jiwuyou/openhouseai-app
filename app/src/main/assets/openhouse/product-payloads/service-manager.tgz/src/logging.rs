use std::{
    fs::{self, File, OpenOptions},
    io::{self, Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::{Arc, Mutex, MutexGuard},
};

use serde::{Deserialize, Serialize};
use tracing_subscriber::fmt::MakeWriter;

use crate::error::{AppError, Result};

pub const DEFAULT_MAX_BYTES: u64 = 16 * 1024 * 1024;
pub const DEFAULT_RETAIN_FILES: usize = 2;
const MAX_RETAIN_FILES: usize = 32;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LoggingConfig {
    #[serde(default)]
    pub path: String,
    #[serde(default = "default_max_bytes")]
    pub max_bytes: u64,
    #[serde(default = "default_retain_files")]
    pub retain_files: usize,
}

impl LoggingConfig {
    pub fn validate(&self) -> Result<()> {
        if self.path.trim().is_empty() {
            return Err(AppError::BadRequest(
                "logging.path must not be empty".to_string(),
            ));
        }
        if self.max_bytes == 0 {
            return Err(AppError::BadRequest(
                "logging.max_bytes must be greater than zero".to_string(),
            ));
        }
        if self.retain_files > MAX_RETAIN_FILES {
            return Err(AppError::BadRequest(format!(
                "logging.retain_files must not exceed {MAX_RETAIN_FILES}"
            )));
        }
        Ok(())
    }
}

impl Default for LoggingConfig {
    fn default() -> Self {
        Self {
            path: String::new(),
            max_bytes: DEFAULT_MAX_BYTES,
            retain_files: DEFAULT_RETAIN_FILES,
        }
    }
}

const fn default_max_bytes() -> u64 {
    DEFAULT_MAX_BYTES
}

const fn default_retain_files() -> usize {
    DEFAULT_RETAIN_FILES
}

pub fn init(config: &LoggingConfig, log_level: &str) -> Result<()> {
    config.validate()?;
    let writer = RotatingFileMakeWriter::new(config)?;
    let filter = if log_level.trim().is_empty() {
        "info"
    } else {
        log_level
    };
    tracing_subscriber::fmt()
        .with_ansi(false)
        .with_env_filter(tracing_subscriber::EnvFilter::new(filter))
        .with_writer(writer)
        .try_init()
        .map_err(|error| AppError::BadRequest(format!("initialize logging: {error}")))
}

#[derive(Clone)]
struct RotatingFileMakeWriter {
    inner: Arc<Mutex<RotatingFile>>,
}

impl RotatingFileMakeWriter {
    fn new(config: &LoggingConfig) -> io::Result<Self> {
        Ok(Self {
            inner: Arc::new(Mutex::new(RotatingFile::open(
                PathBuf::from(&config.path),
                config.max_bytes,
                config.retain_files,
            )?)),
        })
    }
}

struct RotatingFileGuard<'a> {
    inner: MutexGuard<'a, RotatingFile>,
}

impl Write for RotatingFileGuard<'_> {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.inner.write(buf)
    }

    fn flush(&mut self) -> io::Result<()> {
        self.inner.flush()
    }
}

impl<'a> MakeWriter<'a> for RotatingFileMakeWriter {
    type Writer = RotatingFileGuard<'a>;

    fn make_writer(&'a self) -> Self::Writer {
        let inner = self
            .inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        RotatingFileGuard { inner }
    }
}

struct RotatingFile {
    path: PathBuf,
    max_bytes: u64,
    retain_files: usize,
    _lock_file: File,
    file: Option<File>,
    current_bytes: u64,
}

impl RotatingFile {
    fn open(path: PathBuf, max_bytes: u64, retain_files: usize) -> io::Result<Self> {
        let path = canonical_log_path(&path)?;
        reject_symlink(&path)?;
        reject_symlink(&lock_path(&path))?;
        for index in 1..=retain_files {
            reject_symlink(&rotated_path(&path, index))?;
        }

        let lock_file = acquire_lock(&path)?;

        remove_unretained_files(&path, retain_files)?;
        for index in 1..=retain_files {
            let rotated = rotated_path(&path, index);
            bound_file_tail(&rotated, max_bytes)?;
            set_mode_if_exists(&rotated, 0o600)?;
        }

        if fs::metadata(&path).is_ok_and(|metadata| metadata.len() > max_bytes) {
            shift_rotated_files(&path, retain_files)?;
            if retain_files > 0 {
                copy_tail_atomic(&path, &rotated_path(&path, 1), max_bytes)?;
            }
            let mut options = OpenOptions::new();
            options.create(true).write(true).truncate(true);
            no_follow(&mut options);
            options.open(&path)?;
        }

        let file = open_append_600(&path)?;
        let current_bytes = file.metadata()?.len();
        Ok(Self {
            path,
            max_bytes,
            retain_files,
            _lock_file: lock_file,
            file: Some(file),
            current_bytes,
        })
    }

    fn rotate(&mut self) -> io::Result<()> {
        if let Some(mut file) = self.file.take() {
            file.flush()?;
        }
        shift_rotated_files(&self.path, self.retain_files)?;
        if self.retain_files == 0 {
            let _ = fs::remove_file(&self.path);
        } else if self.path.exists() {
            fs::rename(&self.path, rotated_path(&self.path, 1))?;
            set_mode_if_exists(&rotated_path(&self.path, 1), 0o600)?;
        }
        self.file = Some(open_append_600(&self.path)?);
        self.current_bytes = 0;
        Ok(())
    }
}

impl Write for RotatingFile {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        if buf.is_empty() {
            return Ok(0);
        }

        let buf_len = u64::try_from(buf.len()).unwrap_or(u64::MAX);
        if self.current_bytes > 0 && self.current_bytes.saturating_add(buf_len) > self.max_bytes {
            self.rotate()?;
        }

        let included = if buf_len > self.max_bytes {
            let max = usize::try_from(self.max_bytes).unwrap_or(usize::MAX);
            &buf[buf.len().saturating_sub(max)..]
        } else {
            buf
        };
        self.file
            .as_mut()
            .expect("rotating log file must be open")
            .write_all(included)?;
        self.current_bytes = self
            .current_bytes
            .saturating_add(u64::try_from(included.len()).unwrap_or(u64::MAX));
        Ok(buf.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        self.file
            .as_mut()
            .expect("rotating log file must be open")
            .flush()
    }
}

fn open_append_600(path: &Path) -> io::Result<File> {
    reject_symlink(path)?;
    let mut options = OpenOptions::new();
    options.create(true).append(true);
    no_follow(&mut options);
    let file = options.open(path)?;
    set_mode(path, 0o600)?;
    Ok(file)
}

fn acquire_lock(path: &Path) -> io::Result<File> {
    let lock_path = lock_path(path);
    reject_symlink(&lock_path)?;
    let mut options = OpenOptions::new();
    options.create(true).read(true).write(true).truncate(false);
    no_follow(&mut options);
    let file = options.open(&lock_path)?;
    set_mode(&lock_path, 0o600)?;
    lock_exclusive_nonblocking(&file).map_err(|error| {
        if error.kind() == io::ErrorKind::WouldBlock {
            io::Error::new(
                io::ErrorKind::WouldBlock,
                format!(
                    "formal log is already owned by another service-manager process: {}",
                    path.display()
                ),
            )
        } else {
            error
        }
    })?;
    Ok(file)
}

#[cfg(unix)]
fn lock_exclusive_nonblocking(file: &File) -> io::Result<()> {
    use std::os::unix::io::AsRawFd;

    let result = unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) };
    if result == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

#[cfg(not(unix))]
fn lock_exclusive_nonblocking(_file: &File) -> io::Result<()> {
    Ok(())
}

fn shift_rotated_files(path: &Path, retain_files: usize) -> io::Result<()> {
    if retain_files == 0 {
        return Ok(());
    }
    let _ = fs::remove_file(rotated_path(path, retain_files));
    for index in (1..retain_files).rev() {
        let source = rotated_path(path, index);
        if source.exists() {
            fs::rename(source, rotated_path(path, index + 1))?;
        }
    }
    Ok(())
}

fn remove_unretained_files(path: &Path, retain_files: usize) -> io::Result<()> {
    let Some(parent) = path.parent() else {
        return Ok(());
    };
    let Some(name) = path.file_name().and_then(|name| name.to_str()) else {
        return Ok(());
    };
    let prefix = format!("{name}.");
    for entry in fs::read_dir(parent)? {
        let entry = entry?;
        let file_name = entry.file_name();
        let Some(file_name) = file_name.to_str() else {
            continue;
        };
        let Some(suffix) = file_name.strip_prefix(&prefix) else {
            continue;
        };
        let Ok(index) = suffix.parse::<usize>() else {
            continue;
        };
        if index == 0 || index > retain_files {
            let _ = fs::remove_file(entry.path());
        }
    }
    Ok(())
}

fn bound_file_tail(path: &Path, max_bytes: u64) -> io::Result<()> {
    let Ok(metadata) = fs::metadata(path) else {
        return Ok(());
    };
    if metadata.len() <= max_bytes {
        return Ok(());
    }
    copy_tail_atomic(path, path, max_bytes)
}

fn copy_tail_atomic(source: &Path, destination: &Path, max_bytes: u64) -> io::Result<()> {
    reject_symlink(source)?;
    reject_symlink(destination)?;
    let mut input_options = OpenOptions::new();
    input_options.read(true);
    no_follow(&mut input_options);
    let mut input = input_options.open(source)?;
    let size = input.metadata()?.len();
    input.seek(SeekFrom::Start(size.saturating_sub(max_bytes)))?;

    let temp = temporary_path(destination);
    reject_symlink(&temp)?;
    let mut output_options = OpenOptions::new();
    output_options.create(true).write(true).truncate(true);
    no_follow(&mut output_options);
    let mut output = output_options.open(&temp)?;
    set_mode(&temp, 0o600)?;
    io::copy(&mut input.take(max_bytes), &mut output)?;
    output.flush()?;
    drop(output);
    if destination.exists() {
        fs::remove_file(destination)?;
    }
    fs::rename(&temp, destination)?;
    set_mode(destination, 0o600)
}

fn temporary_path(path: &Path) -> PathBuf {
    let mut value = path.as_os_str().to_os_string();
    value.push(format!(".tmp.{}", std::process::id()));
    PathBuf::from(value)
}

fn canonical_log_path(path: &Path) -> io::Result<PathBuf> {
    let file_name = path.file_name().ok_or_else(|| {
        io::Error::new(
            io::ErrorKind::InvalidInput,
            format!("logging path has no file name: {}", path.display()),
        )
    })?;
    let parent = path
        .parent()
        .filter(|parent| !parent.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."));
    let parent_existed = parent.exists();
    fs::create_dir_all(parent)?;
    if !parent_existed {
        set_mode(parent, 0o700)?;
    }
    Ok(fs::canonicalize(parent)?.join(file_name))
}

fn reject_symlink(path: &Path) -> io::Result<()> {
    match fs::symlink_metadata(path) {
        Ok(metadata) if metadata.file_type().is_symlink() => Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            format!("refusing symlink for managed log path: {}", path.display()),
        )),
        Ok(_) => Ok(()),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error),
    }
}

#[cfg(unix)]
fn no_follow(options: &mut OpenOptions) {
    use std::os::unix::fs::OpenOptionsExt;

    options.custom_flags(libc::O_NOFOLLOW);
}

#[cfg(not(unix))]
fn no_follow(_options: &mut OpenOptions) {}

fn lock_path(path: &Path) -> PathBuf {
    let mut value = path.as_os_str().to_os_string();
    value.push(".lock");
    PathBuf::from(value)
}

fn rotated_path(path: &Path, index: usize) -> PathBuf {
    let mut value = path.as_os_str().to_os_string();
    value.push(format!(".{index}"));
    PathBuf::from(value)
}

#[cfg(unix)]
fn set_mode(path: &Path, mode: u32) -> io::Result<()> {
    use std::os::unix::fs::PermissionsExt;

    fs::set_permissions(path, fs::Permissions::from_mode(mode))
}

#[cfg(not(unix))]
fn set_mode(_path: &Path, _mode: u32) -> io::Result<()> {
    Ok(())
}

fn set_mode_if_exists(path: &Path, mode: u32) -> io::Result<()> {
    match set_mode(path, mode) {
        Ok(()) => Ok(()),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error),
    }
}

#[cfg(test)]
mod tests {
    use std::{
        fs::{self, File},
        io::{Seek, SeekFrom, Write},
        time::SystemTime,
    };

    use super::{RotatingFile, rotated_path};

    fn test_dir(name: &str) -> std::path::PathBuf {
        let nonce = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "service-manager-logging-{name}-{}-{nonce}",
            std::process::id()
        ));
        fs::create_dir_all(&path).unwrap();
        path
    }

    #[test]
    fn rotates_at_the_size_limit_and_bounds_all_retained_files() {
        let dir = test_dir("rotate");
        let path = dir.join("service-manager.log");
        let mut writer = RotatingFile::open(path.clone(), 32, 2).unwrap();

        writer.write_all(b"first-record-1234567890\n").unwrap();
        writer.write_all(b"second-record-123456789\n").unwrap();
        writer.write_all(b"third-record-1234567890\n").unwrap();
        writer.flush().unwrap();

        assert!(fs::metadata(&path).unwrap().len() <= 32);
        assert!(fs::metadata(rotated_path(&path, 1)).unwrap().len() <= 32);
        assert!(fs::metadata(rotated_path(&path, 2)).unwrap().len() <= 32);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn startup_preserves_only_the_tail_of_an_oversized_log() {
        let dir = test_dir("startup-tail");
        let path = dir.join("service-manager.log");
        let mut old = File::create(&path).unwrap();
        old.set_len(4096).unwrap();
        old.seek(SeekFrom::End(-9)).unwrap();
        old.write_all(b"TAIL-MARK").unwrap();
        drop(old);

        let _writer = RotatingFile::open(path.clone(), 64, 2).unwrap();

        assert_eq!(fs::metadata(&path).unwrap().len(), 0);
        let retained = fs::read(rotated_path(&path, 1)).unwrap();
        assert!(retained.len() <= 64);
        assert!(retained.ends_with(b"TAIL-MARK"));
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn startup_bounds_retained_logs_and_removes_unretained_generations() {
        let dir = test_dir("retained-tail");
        let path = dir.join("service-manager.log");
        let retained = rotated_path(&path, 1);
        fs::write(&retained, vec![b'x'; 4096]).unwrap();
        fs::write(rotated_path(&path, 3), b"obsolete").unwrap();

        let _writer = RotatingFile::open(path.clone(), 64, 2).unwrap();

        assert_eq!(fs::metadata(retained).unwrap().len(), 64);
        assert!(!rotated_path(&path, 3).exists());
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn a_single_oversized_record_keeps_only_its_tail() {
        let dir = test_dir("single-record");
        let path = dir.join("service-manager.log");
        let mut writer = RotatingFile::open(path.clone(), 16, 1).unwrap();
        writer.write_all(b"0123456789abcdefghijklmnop").unwrap();
        writer.flush().unwrap();

        assert_eq!(fs::read(&path).unwrap(), b"abcdefghijklmnop");
        fs::remove_dir_all(dir).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn log_files_are_private() {
        use std::os::unix::fs::PermissionsExt;

        let dir = test_dir("permissions");
        let path = dir.join("service-manager.log");
        let _writer = RotatingFile::open(path.clone(), 32, 1).unwrap();
        assert_eq!(
            fs::metadata(&path).unwrap().permissions().mode() & 0o777,
            0o600
        );
        fs::remove_dir_all(dir).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn rejects_a_second_writer_for_the_same_formal_log() {
        let dir = test_dir("exclusive-lock");
        let path = dir.join("service-manager.log");
        let _first = RotatingFile::open(path.clone(), 32, 1).unwrap();
        let error = match RotatingFile::open(path, 32, 1) {
            Ok(_) => panic!("second writer unexpectedly acquired the formal log"),
            Err(error) => error,
        };
        assert_eq!(error.kind(), std::io::ErrorKind::WouldBlock);
        fs::remove_dir_all(dir).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn rejects_symlink_final_component_aliases_without_truncating_their_target() {
        use std::os::unix::fs::symlink;

        let dir = test_dir("final-symlink");
        let target = dir.join("target.log");
        fs::write(&target, vec![b'x'; 4096]).unwrap();
        let first_alias = dir.join("service-manager.log");
        let second_alias = dir.join("service-manager-alias.log");
        symlink(&target, &first_alias).unwrap();
        symlink(&target, &second_alias).unwrap();

        for alias in [first_alias, second_alias] {
            let error = match RotatingFile::open(alias, 64, 2) {
                Ok(_) => panic!("symlink final component unexpectedly accepted"),
                Err(error) => error,
            };

            assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
        }
        assert_eq!(fs::metadata(&target).unwrap().len(), 4096);
        assert_eq!(fs::read(&target).unwrap(), vec![b'x'; 4096]);
        fs::remove_dir_all(dir).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn parent_symlink_aliases_share_the_same_process_lock() {
        use std::os::unix::fs::symlink;

        let dir = test_dir("parent-alias");
        let real = dir.join("real");
        fs::create_dir(&real).unwrap();
        let first_alias = dir.join("first");
        let second_alias = dir.join("second");
        symlink(&real, &first_alias).unwrap();
        symlink(&real, &second_alias).unwrap();

        let _first = RotatingFile::open(first_alias.join("service-manager.log"), 64, 2).unwrap();
        let error = match RotatingFile::open(second_alias.join("service-manager.log"), 64, 2) {
            Ok(_) => panic!("parent symlink alias bypassed the process lock"),
            Err(error) => error,
        };

        assert_eq!(error.kind(), std::io::ErrorKind::WouldBlock);
        fs::remove_dir_all(dir).unwrap();
    }
}
