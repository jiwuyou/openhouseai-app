use std::{
    collections::BTreeMap,
    env, fs,
    future::Future,
    io::{self, Read, Write},
    net::{IpAddr, Ipv4Addr, Ipv6Addr, TcpStream, ToSocketAddrs},
    path::{Path, PathBuf},
    process::Command,
    sync::{Arc, Mutex, RwLock},
    time::{Duration, Instant},
};

#[cfg(any(target_os = "linux", target_os = "android"))]
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};

#[path = "repair_hook.rs"]
mod repair_hook;

use chrono::{DateTime, SecondsFormat, Utc};
use repair_hook::run_repair_hook;
use serde::{Deserialize, Serialize};
use tokio::{
    net::TcpListener,
    sync::{Mutex as AsyncMutex, Notify},
};
use tracing::{error, info, warn};

use crate::{
    api,
    error::{AppError, Result},
    logging::{self, LoggingConfig},
    model::{
        Action, AuditEvent, Capability, DetectResult, GroupActionFailure, GroupActionResult,
        GroupActionSkip, HealthCheck, HealthCheckType, LogsOptions, PortLease, PortPoolSpec,
        Provider, ProviderId, ProviderInfo, Service, ServiceEndpoint, ServiceGroup, ServiceId,
        ServicePortSpec, ServiceSpec, ServiceState, ServiceStatus,
    },
    openhouse_registry,
    ports::PortManager,
    providers,
    residency::{ResidencyPolicy, ResidencyStore},
    runtime_endpoints::{RUNTIME_ENDPOINT_SNAPSHOT_TTL, RuntimeEndpointSnapshotPublisher},
    service_registry,
    store::JsonStore,
};

pub const DEFAULT_LISTEN_ADDR: &str = "127.0.0.1:20087";
pub const ENV_AUTH_TOKEN: &str = "SERVICE_MANAGER_TOKEN";
pub const ENV_SERVICE_REGISTRY_DIR: &str = "OPENHOUSEAI_SERVICE_MANAGER_SERVICES_DIR";
const GROUP_TAG_PREFIX: &str = "group:";
const SHUTDOWN_GRACE_PERIOD: Duration = Duration::from_secs(5);
const RESIDENCY_RECONCILE_INTERVAL: Duration = Duration::from_secs(15);
const RUNTIME_ENDPOINT_REVALIDATE_INTERVAL: Duration = Duration::from_secs(30);

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct StoreConfig {
    #[serde(rename = "type", default)]
    pub ty: String,
    #[serde(default)]
    pub path: String,
}

impl Default for StoreConfig {
    fn default() -> Self {
        Self {
            ty: "json".to_string(),
            path: String::new(),
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Config {
    #[serde(default)]
    pub listen_addr: String,
    #[serde(default)]
    pub data_dir: String,
    #[serde(default)]
    pub service_registry_dir: String,
    #[serde(default)]
    pub openhouse_registry_source_dir: String,
    #[serde(default)]
    pub openhouse_registry_target_dir: String,
    #[serde(default)]
    pub auth_token: String,
    #[serde(default)]
    pub log_level: String,
    #[serde(default)]
    pub logging: LoggingConfig,
    #[serde(default)]
    pub store: StoreConfig,
    #[serde(default)]
    pub port_pools: Vec<PortPoolSpec>,
    #[serde(default)]
    pub port_state_path: String,
}

pub struct LoadedConfig {
    pub config: Config,
    pub path: PathBuf,
}

#[derive(Clone)]
pub struct ProviderRegistry {
    inner: Arc<RwLock<BTreeMap<String, Arc<dyn Provider>>>>,
}

impl ProviderRegistry {
    pub fn new() -> Self {
        Self {
            inner: Arc::new(RwLock::new(BTreeMap::new())),
        }
    }

    #[allow(dead_code)]
    pub fn add(&self, p: Arc<dyn Provider>) -> Result<()> {
        let id = p.id();
        if id.0.trim().is_empty() {
            return Err(AppError::BadRequest("provider id is empty".to_string()));
        }
        let mut m = self.inner.write().expect("provider registry lock poisoned");
        if m.contains_key(&id.0) {
            return Err(AppError::BadRequest(format!(
                "provider already registered: {:?}",
                id.0
            )));
        }
        m.insert(id.0.clone(), p);
        Ok(())
    }

    pub fn get(&self, id: &ProviderId) -> Option<Arc<dyn Provider>> {
        let m = self.inner.read().expect("provider registry lock poisoned");
        m.get(&id.0).cloned()
    }

    pub fn list(&self) -> Vec<Arc<dyn Provider>> {
        let m = self.inner.read().expect("provider registry lock poisoned");
        m.values().cloned().collect()
    }
}

impl Default for ProviderRegistry {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Clone)]
pub struct Engine {
    store: Arc<JsonStore>,
    registry: ProviderRegistry,
    ports: Arc<PortManager>,
    service_locks: Arc<Mutex<BTreeMap<String, Arc<AsyncMutex<()>>>>>,
    endpoint_states: Arc<RwLock<BTreeMap<String, EndpointAvailability>>>,
    residency: Arc<ResidencyStore>,
    residency_notify: Arc<Notify>,
    residency_backoff: Arc<Mutex<BTreeMap<String, ResidencyBackoff>>>,
    procfs_root: PathBuf,
    runtime_endpoint_snapshot: Option<Arc<RuntimeEndpointSnapshotPublisher>>,
    runtime_endpoint_notify: Arc<Notify>,
    now: fn() -> DateTime<Utc>,
}

#[derive(Clone, Debug)]
struct ResidencyBackoff {
    failures: u32,
    retry_after: Instant,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum EndpointAvailability {
    Starting,
    Healthy,
    Unhealthy,
    Stopped,
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EndpointResolution {
    pub service_id: ServiceId,
    pub status: EndpointAvailability,
    pub generation: u64,
    pub endpoints: Vec<ServiceEndpoint>,
}

impl Engine {
    #[cfg(test)]
    pub fn new(store: Arc<JsonStore>, registry: ProviderRegistry, ports: Arc<PortManager>) -> Self {
        Self::new_with_residency(store, registry, ports, Arc::new(ResidencyStore::memory()))
    }

    #[allow(dead_code)]
    pub fn new_with_residency(
        store: Arc<JsonStore>,
        registry: ProviderRegistry,
        ports: Arc<PortManager>,
        residency: Arc<ResidencyStore>,
    ) -> Self {
        let procfs_root = env::var_os("SERVICE_MANAGER_PROCFS_ROOT")
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from("/proc"));
        Self::new_with_procfs_root_and_residency(store, registry, ports, procfs_root, residency)
    }

    #[cfg(test)]
    pub(crate) fn new_with_procfs_root(
        store: Arc<JsonStore>,
        registry: ProviderRegistry,
        ports: Arc<PortManager>,
        procfs_root: PathBuf,
    ) -> Self {
        Self::new_with_procfs_root_and_residency(
            store,
            registry,
            ports,
            procfs_root,
            Arc::new(ResidencyStore::memory()),
        )
    }

    #[cfg(test)]
    pub(crate) fn new_with_runtime_endpoint_snapshot(
        store: Arc<JsonStore>,
        registry: ProviderRegistry,
        ports: Arc<PortManager>,
        procfs_root: PathBuf,
        snapshot: Arc<RuntimeEndpointSnapshotPublisher>,
    ) -> Self {
        Self::new_with_procfs_root_and_residency_and_snapshot(
            store,
            registry,
            ports,
            procfs_root,
            Arc::new(ResidencyStore::memory()),
            Some(snapshot),
        )
    }

    #[allow(dead_code)]
    fn new_with_procfs_root_and_residency(
        store: Arc<JsonStore>,
        registry: ProviderRegistry,
        ports: Arc<PortManager>,
        procfs_root: PathBuf,
        residency: Arc<ResidencyStore>,
    ) -> Self {
        Self::new_with_procfs_root_and_residency_and_snapshot(
            store,
            registry,
            ports,
            procfs_root,
            residency,
            None,
        )
    }

    fn new_with_procfs_root_and_residency_and_snapshot(
        store: Arc<JsonStore>,
        registry: ProviderRegistry,
        ports: Arc<PortManager>,
        procfs_root: PathBuf,
        residency: Arc<ResidencyStore>,
        runtime_endpoint_snapshot: Option<Arc<RuntimeEndpointSnapshotPublisher>>,
    ) -> Self {
        Self {
            store,
            registry,
            ports,
            service_locks: Arc::new(Mutex::new(BTreeMap::new())),
            endpoint_states: Arc::new(RwLock::new(BTreeMap::new())),
            residency,
            residency_notify: Arc::new(Notify::new()),
            residency_backoff: Arc::new(Mutex::new(BTreeMap::new())),
            procfs_root,
            runtime_endpoint_snapshot,
            runtime_endpoint_notify: Arc::new(Notify::new()),
            now: || Utc::now(),
        }
    }

    fn service_lock(&self, id: &ServiceId) -> Arc<AsyncMutex<()>> {
        let mut locks = self
            .service_locks
            .lock()
            .expect("service lock registry poisoned");
        locks
            .entry(id.0.clone())
            .or_insert_with(|| Arc::new(AsyncMutex::new(())))
            .clone()
    }

    #[cfg(test)]
    pub(crate) fn test_service_lock(&self, id: &ServiceId) -> Arc<AsyncMutex<()>> {
        self.service_lock(id)
    }

    fn set_endpoint_state(&self, id: &ServiceId, state: EndpointAvailability) {
        let changed = self
            .endpoint_states
            .write()
            .expect("endpoint state registry poisoned")
            .insert(id.0.clone(), state)
            != Some(state);
        if changed {
            self.notify_runtime_endpoint_snapshot();
        }
    }

    fn notify_runtime_endpoint_snapshot(&self) {
        if self.runtime_endpoint_snapshot.is_some() {
            self.runtime_endpoint_notify.notify_one();
        }
    }

    fn allocate_ports(&self, id: &ServiceId, specs: &[ServicePortSpec]) -> Result<Vec<PortLease>> {
        let generation = self.ports.generation();
        let result = self.ports.allocate(id, specs);
        if result.is_ok() && self.ports.generation() != generation {
            self.notify_runtime_endpoint_snapshot();
        }
        result
    }

    fn publish_ports(&self, id: &ServiceId) -> Result<()> {
        let generation = self.ports.generation();
        let result = self.ports.publish(id);
        if result.is_ok() && self.ports.generation() != generation {
            self.notify_runtime_endpoint_snapshot();
        }
        result
    }

    fn unpublish_ports(&self, id: &ServiceId) -> Result<()> {
        let generation = self.ports.generation();
        let result = self.ports.unpublish(id);
        if result.is_ok() && self.ports.generation() != generation {
            self.notify_runtime_endpoint_snapshot();
        }
        result
    }

    fn release_ports(&self, id: &ServiceId) -> Result<()> {
        let generation = self.ports.generation();
        let result = self.ports.release(id);
        if result.is_ok() && self.ports.generation() != generation {
            self.notify_runtime_endpoint_snapshot();
        }
        result
    }

    fn mark_ports_orphan(&self, id: &ServiceId, reason: &str) -> Result<()> {
        let generation = self.ports.generation();
        let result = self.ports.mark_orphan(id, reason);
        if result.is_ok() && self.ports.generation() != generation {
            self.notify_runtime_endpoint_snapshot();
        }
        result
    }

    fn endpoint_state(&self, id: &ServiceId) -> EndpointAvailability {
        self.endpoint_states
            .read()
            .expect("endpoint state registry poisoned")
            .get(&id.0)
            .copied()
            .unwrap_or(EndpointAvailability::Stopped)
    }

    fn initialize_runtime_endpoint_snapshot(&self) {
        let Some(publisher) = &self.runtime_endpoint_snapshot else {
            return;
        };
        match publisher.write_initializing(self.ports.generation(), (self.now)()) {
            Ok(snapshot) => info!(
                path = %publisher.path().display(),
                manager_instance_id = %snapshot.manager_instance_id,
                snapshot_revision = snapshot.snapshot_revision,
                "initialized empty runtime endpoint snapshot"
            ),
            Err(error) => warn!(
                path = %publisher.path().display(),
                "could not initialize runtime endpoint snapshot; service lifecycle remains active: {error}"
            ),
        }
    }

    pub fn spawn_runtime_endpoint_snapshot_writer(self: &Arc<Self>) {
        if self.runtime_endpoint_snapshot.is_none() {
            return;
        }
        let engine = Arc::clone(self);
        tokio::spawn(async move {
            loop {
                engine.refresh_runtime_endpoint_snapshot_once().await;
                tokio::select! {
                    _ = tokio::time::sleep(RUNTIME_ENDPOINT_REVALIDATE_INTERVAL) => {}
                    _ = engine.runtime_endpoint_notify.notified() => {}
                }
            }
        });
    }

    async fn refresh_runtime_endpoint_snapshot_once(&self) {
        let Some(publisher) = &self.runtime_endpoint_snapshot else {
            return;
        };
        let services = match self.store.list_services() {
            Ok(services) => services,
            Err(error) => {
                warn!("cannot list services for runtime endpoint snapshot: {error}");
                return;
            }
        };
        let mut endpoints = Vec::new();
        for service in services {
            match self
                .revalidate_runtime_endpoint_for_snapshot(&service.id)
                .await
            {
                Ok(mut verified) => endpoints.append(&mut verified),
                Err(error) => warn!(
                    service_id = %service.id,
                    "runtime endpoint snapshot revalidation failed: {error}"
                ),
            }
        }

        // Do not hold a global lifecycle/process lock while probing. Instead, every service probe
        // is checked against the current lease generation before inclusion. A final global port
        // generation check makes a concurrent mutation fail closed for this snapshot; the
        // mutation notification immediately coalesces another writer pass.
        let generation_before_filter = self.ports.generation();
        endpoints.retain(|endpoint| self.runtime_endpoint_is_current(endpoint));
        let mut port_state_generation = self.ports.generation();
        if port_state_generation != generation_before_filter {
            endpoints.clear();
            self.notify_runtime_endpoint_snapshot();
            port_state_generation = self.ports.generation();
        }

        match publisher.write_ready(port_state_generation, (self.now)(), endpoints) {
            Ok(snapshot) => info!(
                path = %publisher.path().display(),
                snapshot_revision = snapshot.snapshot_revision,
                endpoint_count = snapshot.endpoints.len(),
                ttl_seconds = RUNTIME_ENDPOINT_SNAPSHOT_TTL.as_secs(),
                "published runtime endpoint snapshot"
            ),
            Err(error) => warn!(
                path = %publisher.path().display(),
                "could not publish runtime endpoint snapshot; service lifecycle remains unchanged: {error}"
            ),
        }
    }

    async fn revalidate_runtime_endpoint_for_snapshot(
        &self,
        id: &ServiceId,
    ) -> Result<Vec<ServiceEndpoint>> {
        let service_lock = self.service_lock(id);
        let (service, leases, runtime_service, provider) = {
            let Ok(_guard) = service_lock.try_lock() else {
                return Ok(Vec::new());
            };
            let service = self.store.get_service(id)?;
            let leases = self.ports.leases(id)?;
            if leases.is_empty() || !leases.iter().any(|lease| lease.endpoint.is_some()) {
                return Ok(Vec::new());
            }
            let runtime_service = materialize_service(&service, &leases)?;
            let provider = self
                .registry
                .get(&service.spec.provider)
                .ok_or_else(|| AppError::ProviderNotFound(service.spec.provider.0.clone()))?;
            (service, leases, runtime_service, provider)
        };

        // Provider status, health probes, and process/socket ownership inspection can be slow on
        // Android. They intentionally run without a service lifecycle lock.
        let status_result = provider.status(&runtime_service).await.map(|mut status| {
            normalize_status(&runtime_service, &mut status, (self.now)());
            status
        });
        let (verified, availability) = match status_result {
            Ok(status) if status.state == ServiceState::Running => {
                let verification = probe_all_health(&runtime_service)
                    .await
                    .and_then(|_| self.verify_endpoint_ownership(&status, &leases, true));
                (
                    verification.is_ok(),
                    if verification.is_ok() {
                        EndpointAvailability::Healthy
                    } else {
                        EndpointAvailability::Unhealthy
                    },
                )
            }
            Ok(status) => (
                false,
                if status.state == ServiceState::Stopped {
                    EndpointAvailability::Stopped
                } else {
                    EndpointAvailability::Unhealthy
                },
            ),
            Err(_) => (false, EndpointAvailability::Unhealthy),
        };

        // A concurrent start/stop/update wins. Reacquire with try_lock and compare both the
        // service spec and the exact lease generations captured before the probe.
        let Ok(_guard) = service_lock.try_lock() else {
            return Ok(Vec::new());
        };
        let current_service = match self.store.get_service(id) {
            Ok(service) => service,
            Err(AppError::NotFound) => return Ok(Vec::new()),
            Err(error) => return Err(error),
        };
        let current_leases = self.ports.leases(id)?;
        if current_service != service || current_leases != leases {
            return Ok(Vec::new());
        }

        if !verified {
            if let Err(error) = self.unpublish_ports(id) {
                warn!(service_id = %id, "could not unpublish failed runtime endpoint: {error}");
            }
            self.set_endpoint_state(id, availability);
            return Ok(Vec::new());
        }

        if let Err(error) = self.publish_ports(id) {
            self.set_endpoint_state(id, EndpointAvailability::Unhealthy);
            warn!(service_id = %id, "could not mark verified runtime endpoint published: {error}");
            return Ok(Vec::new());
        }
        let published = self.ports.endpoints(id)?;
        let current_leases = self.ports.leases(id)?;
        if !published_matches_leases(&published, &current_leases) {
            if let Err(error) = self.unpublish_ports(id) {
                warn!(service_id = %id, "could not remove inconsistent runtime endpoint publication: {error}");
            }
            self.set_endpoint_state(id, EndpointAvailability::Unhealthy);
            return Ok(Vec::new());
        }
        self.set_endpoint_state(id, EndpointAvailability::Healthy);
        Ok(published)
    }

    fn runtime_endpoint_is_current(&self, endpoint: &ServiceEndpoint) -> bool {
        let current_endpoint = self
            .ports
            .endpoint(&endpoint.service_id, &endpoint.name)
            .ok()
            .flatten();
        let current_lease = self.ports.lease(&endpoint.service_id, &endpoint.name).ok();
        current_endpoint.as_ref() == Some(endpoint)
            && current_lease.is_some_and(|lease| {
                lease.lifecycle == crate::model::PortLeaseLifecycle::Published
                    && lease.generation == endpoint.generation
                    && lease.allocated_port == endpoint.port
                    && lease.host == endpoint.host
                    && lease.protocol == endpoint.protocol
                    && lease.orphan_reason.is_none()
            })
    }

    fn mark_orphan(&self, id: &ServiceId, reason: &str) -> Result<()> {
        self.unpublish_ports(id)?;
        self.mark_ports_orphan(id, reason)?;
        self.set_endpoint_state(id, EndpointAvailability::Unhealthy);
        Ok(())
    }

    #[allow(dead_code)]
    pub fn registry(&self) -> &ProviderRegistry {
        &self.registry
    }

    pub fn list_services(&self) -> Result<Vec<Service>> {
        self.store.list_services()
    }

    pub fn get_service(&self, id: &ServiceId) -> Result<Service> {
        self.store.get_service(id)
    }

    pub fn list_residency(&self) -> Vec<ResidencyPolicy> {
        self.residency.list()
    }

    pub fn get_residency(&self, id: &ServiceId) -> Result<ResidencyPolicy> {
        self.residency.get(&id.0).ok_or(AppError::NotFound)
    }

    pub async fn set_residency(&self, id: &ServiceId, resident: bool) -> Result<ResidencyPolicy> {
        let service_lock = self.service_lock(id);
        let _guard = service_lock.lock().await;
        self.store.get_service(id)?;
        let policy = self.residency.put(&id.0, resident, false)?;
        self.residency_backoff
            .lock()
            .expect("residency backoff mutex poisoned")
            .remove(&id.0);
        self.residency_notify.notify_one();
        Ok(policy)
    }

    pub fn delete_orphan_residency(&self, id: &ServiceId) -> Result<()> {
        if self.store.get_service(id).is_ok() {
            return Err(AppError::BadRequest(
                "residency policy can only be deleted after its service is removed".to_string(),
            ));
        }
        if !self.residency.delete(&id.0)? {
            return Err(AppError::NotFound);
        }
        self.residency_backoff
            .lock()
            .expect("residency backoff mutex poisoned")
            .remove(&id.0);
        Ok(())
    }

    fn seed_residency(&self, svc: &Service) -> Result<()> {
        self.residency
            .seed_once(&svc.id.0, svc.spec.resident_by_default)?;
        Ok(())
    }

    pub fn list_groups(&self) -> Result<Vec<ServiceGroup>> {
        let mut groups: BTreeMap<String, Vec<Service>> = BTreeMap::new();
        for svc in self.store.list_services()? {
            for group in service_groups(&svc) {
                groups.entry(group).or_default().push(svc.clone());
            }
        }

        Ok(groups
            .into_iter()
            .map(|(name, services)| ServiceGroup {
                name,
                service_ids: services.iter().map(|svc| svc.id.clone()).collect(),
                services,
            })
            .collect())
    }

    pub async fn group_action(&self, group: &str, action: Action) -> Result<GroupActionResult> {
        let group = group.trim();
        if group.is_empty() {
            return Err(AppError::BadRequest("group name is required".to_string()));
        }
        if !matches!(action, Action::Start | Action::Stop | Action::Restart) {
            return Err(AppError::BadRequest(
                "group action must be start, stop, or restart".to_string(),
            ));
        }

        let Some(svc_group) = self.list_groups()?.into_iter().find(|g| g.name == group) else {
            return Err(AppError::NotFound);
        };

        let mut result = GroupActionResult {
            group: group.to_string(),
            action,
            total: svc_group.services.len(),
            succeeded: Vec::new(),
            skipped: Vec::new(),
            failed: Vec::new(),
        };

        for svc in svc_group.services {
            let required = match action {
                Action::Start => Capability::Start,
                Action::Stop => Capability::Stop,
                Action::Restart => Capability::Restart,
                _ => unreachable!("validated group action"),
            };
            let Some(provider) = self.registry.get(&svc.spec.provider) else {
                result.failed.push(GroupActionFailure {
                    service_id: svc.id,
                    message: format!("provider not found: {:?}", svc.spec.provider.0),
                });
                continue;
            };
            if !provider.capabilities().contains(&required) {
                result.skipped.push(GroupActionSkip {
                    service_id: svc.id,
                    reason: "provider does not support this action".to_string(),
                });
                continue;
            }

            let id = svc.id.clone();
            let outcome = match action {
                Action::Start => self.start(&id).await,
                Action::Stop => self.stop(&id).await,
                Action::Restart => self.restart(&id).await,
                _ => unreachable!("validated group action"),
            };
            match outcome {
                Ok(()) => result.succeeded.push(id),
                Err(e) => result.failed.push(GroupActionFailure {
                    service_id: id,
                    message: e.to_string(),
                }),
            }
        }

        Ok(result)
    }

    pub async fn create_service(&self, mut spec: ServiceSpec) -> Result<Service> {
        validate_service_spec(&mut spec)?;
        if self.registry.get(&spec.provider).is_none() {
            return Err(AppError::ProviderNotFound(spec.provider.0.clone()));
        }

        let now = (self.now)();
        let svc = Service {
            id: ServiceId::new(new_id(16)?),
            spec,
            created_at: now,
            updated_at: now,
            deleted_at: None,
        };
        self.store.create_service(svc.clone())?;
        self.seed_residency(&svc)?;

        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: now,
            action: Action::Create,
            service_id: Some(svc.id.clone()),
            provider: Some(svc.spec.provider.clone()),
            actor: "api".to_string(),
            details: String::new(),
        });

        self.notify_runtime_endpoint_snapshot();

        Ok(svc)
    }

    pub fn upsert_registered_service(
        &self,
        id: ServiceId,
        mut spec: ServiceSpec,
    ) -> Result<Service> {
        validate_service_spec(&mut spec)?;
        if self.registry.get(&spec.provider).is_none() {
            return Err(AppError::ProviderNotFound(spec.provider.0.clone()));
        }

        let id = ServiceId(validate_registry_service_id(id.0)?);
        let service_lock = self.service_lock(&id);
        let _guard = service_lock.try_lock().map_err(|_| {
            AppError::BadRequest(format!(
                "service {} is busy; retry registry apply after the lifecycle operation finishes",
                id
            ))
        })?;
        let now = (self.now)();
        let (created_at, ports_changed) = match self.store.get_service(&id) {
            Ok(existing) => {
                if existing.spec.provider != spec.provider {
                    return Err(AppError::BadRequest(format!(
                        "provider cannot be changed for registered service {:?}",
                        id.0
                    )));
                }
                (existing.created_at, existing.spec.ports != spec.ports)
            }
            Err(AppError::NotFound) => (now, false),
            Err(e) => return Err(e),
        };
        if ports_changed && self.ports.has_leases(&id)? {
            return Err(AppError::BadRequest(format!(
                "runtime registry upsert cannot change ports for active service {}; use the async service update API",
                id
            )));
        }

        let svc = Service {
            id: id.clone(),
            spec,
            created_at,
            updated_at: now,
            deleted_at: None,
        };
        self.store.upsert_service(svc.clone())?;
        self.seed_residency(&svc)?;

        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: now,
            action: Action::Register,
            service_id: Some(id),
            provider: Some(svc.spec.provider.clone()),
            actor: "registry".to_string(),
            details: "loaded from services.d".to_string(),
        });

        self.notify_runtime_endpoint_snapshot();

        Ok(svc)
    }

    pub fn export_store_snapshot(&self) -> Result<Vec<u8>> {
        self.store.export()
    }

    pub fn restore_store_snapshot(&self, snapshot: &[u8]) -> Result<()> {
        let result = self.store.import(snapshot);
        if result.is_ok() {
            self.notify_runtime_endpoint_snapshot();
        }
        result
    }

    pub async fn update_service(&self, id: &ServiceId, mut spec: ServiceSpec) -> Result<Service> {
        validate_service_spec(&mut spec)?;
        let service_lock = self.service_lock(id);
        let _guard = service_lock.lock().await;
        let existing = self.store.get_service(id)?;
        if existing.spec.provider != spec.provider {
            return Err(AppError::BadRequest(
                "provider cannot be changed for an existing service".to_string(),
            ));
        }
        let p = self
            .registry
            .get(&spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(spec.provider.0.clone()))?;

        let ports_changed = existing.spec.ports != spec.ports;
        if ports_changed {
            let old_leases = self.ports.leases(id)?;
            let old_runtime_svc = materialize_service(&existing, &old_leases)?;
            let old_status = p.status(&old_runtime_svc).await;
            let must_stop = !old_leases.is_empty()
                || matches!(
                    old_status.as_ref().map(|status| status.state),
                    Ok(ServiceState::Running | ServiceState::Starting | ServiceState::Stopping)
                );
            if must_stop {
                self.unpublish_ports(id)?;
                if let Err(error) = p.stop(&old_runtime_svc).await {
                    let reason = format!(
                        "update could not stop the previous instance before changing ports: {error}"
                    );
                    self.mark_orphan(id, &reason)?;
                    return Err(AppError::BadRequest(reason));
                }
            } else if let Err(error) = old_status {
                return Err(AppError::BadRequest(format!(
                    "cannot verify service state before changing ports: {error}"
                )));
            }
            self.release_ports(id)?;
            self.set_endpoint_state(id, EndpointAvailability::Stopped);
        }

        let now = (self.now)();
        let mut updated = existing.clone();
        updated.spec = spec;
        updated.updated_at = now;
        self.store.update_service(updated.clone())?;

        if let Err(e) = p.register(&updated).await {
            // Best-effort rollback of stored spec.
            let _ = self.store.update_service(existing);
            return Err(e);
        }

        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: now,
            action: Action::Update,
            service_id: Some(updated.id.clone()),
            provider: Some(updated.spec.provider.clone()),
            actor: "api".to_string(),
            details: String::new(),
        });

        self.notify_runtime_endpoint_snapshot();

        Ok(updated)
    }

    pub async fn delete_service(&self, id: &ServiceId) -> Result<()> {
        let svc = self.store.get_service(id)?;
        let now = (self.now)();

        let service_lock = self.service_lock(id);
        let _guard = service_lock.lock().await;

        if let Some(p) = self.registry.get(&svc.spec.provider) {
            p.unregister(&svc).await?;
        }

        self.unpublish_ports(id)?;
        self.release_ports(id)?;
        self.set_endpoint_state(id, EndpointAvailability::Stopped);

        self.store.delete_service(id)?;
        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: now,
            action: Action::Delete,
            service_id: Some(id.clone()),
            provider: Some(svc.spec.provider),
            actor: "api".to_string(),
            details: String::new(),
        });
        self.notify_runtime_endpoint_snapshot();
        Ok(())
    }

    pub async fn list_providers(&self) -> Result<Vec<ProviderInfo>> {
        let ps = self.registry.list();
        let mut out = Vec::with_capacity(ps.len());
        for p in ps {
            let mut info = ProviderInfo {
                id: p.id(),
                display_name: p.display_name(),
                description: p.description(),
                capabilities: p.capabilities(),
                detected: false,
                detect_error: String::new(),
                detect_details: String::new(),
            };
            match p.detect().await {
                Ok(DetectResult { detected, details }) => {
                    info.detected = detected;
                    info.detect_details = details;
                }
                Err(e) => {
                    info.detected = false;
                    info.detect_error = e.to_string();
                }
            }
            out.push(info);
        }
        Ok(out)
    }

    pub async fn start(&self, id: &ServiceId) -> Result<()> {
        let service_lock = self.service_lock(id);
        let _guard = service_lock.lock().await;
        let svc = self.store.get_service(id)?;
        // A direct start is user intent to resume. Persist it before attempting provider work so
        // a failed start does not leave a stale user suspension behind.
        self.residency.set_suspended(&id.0, false)?;
        self.start_locked(id, &svc, "api").await?;
        self.residency_backoff
            .lock()
            .expect("residency backoff mutex poisoned")
            .remove(&id.0);

        Ok(())
    }

    async fn start_locked(&self, id: &ServiceId, svc: &Service, actor: &str) -> Result<()> {
        let provider = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;
        self.revalidate_endpoints(id).await?;
        self.launch_with_retries(id, svc, provider.as_ref(), false, "start")
            .await?;
        self.residency.set_last_error(&id.0, None)?;
        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: (self.now)(),
            action: Action::Start,
            service_id: Some(id.clone()),
            provider: Some(svc.spec.provider.clone()),
            actor: actor.to_string(),
            details: String::new(),
        });
        Ok(())
    }

    pub async fn stop(&self, id: &ServiceId) -> Result<()> {
        let service_lock = self.service_lock(id);
        let _guard = service_lock.lock().await;
        let svc = self.store.get_service(id)?;
        let p = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;
        // Persist stop intent while holding the lifecycle lock. A queued reconcile must observe
        // this suspension before it can decide whether to start.
        self.residency.set_suspended(&id.0, true)?;
        let leases = self.ports.leases(id)?;
        if leases.is_empty()
            && let Ok(status) = p.status(&svc).await
            && status.state == ServiceState::Stopped
        {
            self.unpublish_ports(id)?;
            self.release_ports(id)?;
            self.set_endpoint_state(id, EndpointAvailability::Stopped);
            let _ = self.store.append_audit_event(AuditEvent {
                id: new_id(16)?,
                time: (self.now)(),
                action: Action::Stop,
                service_id: Some(id.clone()),
                provider: Some(svc.spec.provider),
                actor: "api".to_string(),
                details: "already stopped".to_string(),
            });
            return Ok(());
        }
        let runtime_svc = match materialize_service(&svc, &leases) {
            Ok(service) => service,
            Err(error) => {
                let reason = format!("stop could not materialize the managed instance: {error}");
                self.mark_orphan(id, &reason)?;
                return Err(AppError::BadRequest(reason));
            }
        };

        self.unpublish_ports(id)?;
        if let Err(error) = p.stop(&runtime_svc).await {
            let reason = format!("stop failed; lease retained as orphan evidence: {error}");
            self.mark_orphan(id, &reason)?;
            return Err(AppError::BadRequest(reason));
        }
        self.release_ports(id)?;
        self.set_endpoint_state(id, EndpointAvailability::Stopped);

        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: (self.now)(),
            action: Action::Stop,
            service_id: Some(id.clone()),
            provider: Some(svc.spec.provider),
            actor: "api".to_string(),
            details: String::new(),
        });
        Ok(())
    }

    pub async fn restart(&self, id: &ServiceId) -> Result<()> {
        let service_lock = self.service_lock(id);
        let _guard = service_lock.lock().await;
        let svc = self.store.get_service(id)?;
        self.residency.set_suspended(&id.0, false)?;
        let p = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;
        self.stop_for_replacement(id, &svc, p.as_ref(), "restart")
            .await?;
        self.launch_with_retries(id, &svc, p.as_ref(), true, "restart")
            .await?;
        self.residency_backoff
            .lock()
            .expect("residency backoff mutex poisoned")
            .remove(&id.0);

        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: (self.now)(),
            action: Action::Restart,
            service_id: Some(id.clone()),
            provider: Some(svc.spec.provider),
            actor: "api".to_string(),
            details: String::new(),
        });
        Ok(())
    }

    pub async fn repair(&self, id: &ServiceId) -> Result<()> {
        let service_lock = self.service_lock(id);
        let _guard = service_lock.lock().await;
        let svc = self.store.get_service(id)?;
        let p = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;

        let details = if svc.spec.repair_hook()?.is_some() {
            let leases = self.ports.leases(id)?;
            let runtime_svc = materialize_service(&svc, &leases)?;
            run_repair_hook(&runtime_svc).await?;
            "repair hook".to_string()
        } else {
            self.stop_for_replacement(id, &svc, p.as_ref(), "repair")
                .await?;
            self.launch_with_retries(id, &svc, p.as_ref(), true, "repair")
                .await?;
            "managed stop + start".to_string()
        };

        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: (self.now)(),
            action: Action::Repair,
            service_id: Some(id.clone()),
            provider: Some(svc.spec.provider),
            actor: "api".to_string(),
            details,
        });
        Ok(())
    }

    pub async fn register(&self, id: &ServiceId) -> Result<()> {
        let svc = self.store.get_service(id)?;
        let p = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;

        p.register(&svc).await?;

        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: (self.now)(),
            action: Action::Register,
            service_id: Some(id.clone()),
            provider: Some(svc.spec.provider),
            actor: "api".to_string(),
            details: String::new(),
        });
        Ok(())
    }

    pub async fn unregister(&self, id: &ServiceId) -> Result<()> {
        let svc = self.store.get_service(id)?;
        let p = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;

        p.unregister(&svc).await?;

        let _ = self.store.append_audit_event(AuditEvent {
            id: new_id(16)?,
            time: (self.now)(),
            action: Action::Unregister,
            service_id: Some(id.clone()),
            provider: Some(svc.spec.provider),
            actor: "api".to_string(),
            details: String::new(),
        });
        Ok(())
    }

    pub async fn status(&self, id: &ServiceId) -> Result<ServiceStatus> {
        let svc = self.store.get_service(id)?;
        let p = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;
        let leases = self.ports.leases(id)?;
        if leases.is_empty() {
            let mut stopped = p.status(&svc).await?;
            normalize_status(&svc, &mut stopped, (self.now)());
            if stopped.state == ServiceState::Stopped {
                self.set_endpoint_state(id, EndpointAvailability::Stopped);
                return Ok(stopped);
            }
        }
        let runtime_svc = materialize_service(&svc, &leases)?;
        let mut st = p.status(&runtime_svc).await?;
        normalize_status(&svc, &mut st, (self.now)());
        if st.state == ServiceState::Running && !svc.spec.health.is_empty() {
            if self.endpoint_state(id) == EndpointAvailability::Starting {
                st.state = ServiceState::Starting;
                st.message =
                    "starting: health and endpoint ownership checks have not passed".to_string();
            } else {
                let verification = probe_all_health(&runtime_svc)
                    .await
                    .and_then(|_| self.verify_endpoint_ownership(&st, &leases, true));
                if let Err(error) = verification {
                    let _ = self.unpublish_ports(id);
                    self.set_endpoint_state(id, EndpointAvailability::Unhealthy);
                    st.state = ServiceState::Failed;
                    st.message = format!("unhealthy: {error}");
                } else {
                    self.set_endpoint_state(id, EndpointAvailability::Healthy);
                }
            }
        }
        Ok(st)
    }

    pub fn spawn_residency_reconciler(self: &Arc<Self>) {
        let engine = Arc::clone(self);
        tokio::spawn(async move {
            loop {
                if let Err(error) = engine.reconcile_residency_once().await {
                    warn!("residency reconcile failed: {error}");
                }
                tokio::select! {
                    _ = tokio::time::sleep(RESIDENCY_RECONCILE_INTERVAL) => {}
                    _ = engine.residency_notify.notified() => {}
                }
            }
        });
    }

    pub async fn reconcile_residency_once(&self) -> Result<()> {
        for policy in self.residency.list() {
            if !policy.resident || policy.suspended {
                continue;
            }
            let id = ServiceId::new(policy.service_id.clone());
            if self.store.get_service(&id).is_err() || !self.residency_retry_due(&id.0) {
                continue;
            }
            let needs_start = match self.status(&id).await {
                Ok(status) => matches!(status.state, ServiceState::Stopped | ServiceState::Failed),
                Err(error) => {
                    warn!("cannot inspect resident service {}: {error}", id.0);
                    true
                }
            };
            if !needs_start {
                self.residency_backoff
                    .lock()
                    .expect("residency backoff mutex poisoned")
                    .remove(&id.0);
                continue;
            }
            let service_lock = self.service_lock(&id);
            let _guard = service_lock.lock().await;
            let Some(latest) = self.residency.get(&id.0) else {
                continue;
            };
            if !latest.resident || latest.suspended {
                continue;
            }
            let svc = match self.store.get_service(&id) {
                Ok(service) => service,
                Err(_) => continue,
            };
            let still_needs_start = match self.status(&id).await {
                Ok(status) => matches!(status.state, ServiceState::Stopped | ServiceState::Failed),
                Err(_) => true,
            };
            if !still_needs_start {
                continue;
            }
            if let Err(error) = self.start_locked(&id, &svc, "residency").await {
                let _ = self
                    .residency
                    .set_last_error(&id.0, Some(error.to_string()));
                let delay = self.record_residency_failure(&id.0);
                warn!(
                    "resident service {} start failed; retry in {:?}: {error}",
                    id.0, delay
                );
            }
        }
        Ok(())
    }

    fn residency_retry_due(&self, id: &str) -> bool {
        self.residency_backoff
            .lock()
            .expect("residency backoff mutex poisoned")
            .get(id)
            .is_none_or(|state| Instant::now() >= state.retry_after)
    }

    fn record_residency_failure(&self, id: &str) -> Duration {
        let mut states = self
            .residency_backoff
            .lock()
            .expect("residency backoff mutex poisoned");
        let failures = states
            .get(id)
            .map_or(1, |state| state.failures.saturating_add(1));
        let seconds = 5_u64.saturating_mul(1_u64 << failures.min(6)).min(300);
        let delay = Duration::from_secs(seconds);
        states.insert(
            id.to_string(),
            ResidencyBackoff {
                failures,
                retry_after: Instant::now() + delay,
            },
        );
        delay
    }

    pub async fn endpoints(&self, id: &ServiceId) -> Result<EndpointResolution> {
        self.revalidate_endpoints(id).await?;
        let endpoints = self.ports.endpoints(id)?;
        Ok(EndpointResolution {
            service_id: id.clone(),
            status: self.endpoint_state(id),
            generation: self.ports.generation(),
            endpoints,
        })
    }

    #[allow(dead_code)]
    pub async fn endpoint(&self, id: &ServiceId, name: &str) -> Result<ServiceEndpoint> {
        let name = name.trim();
        if name.is_empty() {
            return Err(AppError::BadRequest(
                "endpoint name is required".to_string(),
            ));
        }
        let resolution = self.endpoints(id).await?;
        resolution
            .endpoints
            .into_iter()
            .find(|endpoint| endpoint.name == name)
            .ok_or(AppError::NotFound)
    }

    pub async fn port_state(&self) -> Result<serde_json::Value> {
        for svc in self.store.list_services()? {
            if self.ports.has_leases(&svc.id)? {
                let _ = self.revalidate_endpoints(&svc.id).await;
            }
        }
        self.ports.snapshot()
    }

    async fn revalidate_endpoints(&self, id: &ServiceId) -> Result<()> {
        let svc = self.store.get_service(id)?;
        if !self.ports.has_leases(id)? {
            return Ok(());
        }
        let p = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;
        let leases = self.ports.leases(id)?;
        let runtime_svc = materialize_service(&svc, &leases)?;
        let status = match p.status(&runtime_svc).await {
            Ok(status) => status,
            Err(error) => {
                self.unpublish_ports(id)?;
                self.set_endpoint_state(id, EndpointAvailability::Unhealthy);
                return Err(error);
            }
        };
        let verification = if status.state == ServiceState::Running {
            probe_all_health(&runtime_svc)
                .await
                .and_then(|_| self.verify_endpoint_ownership(&status, &leases, true))
        } else {
            Err(AppError::BadRequest(format!(
                "provider state is {:?}",
                status.state
            )))
        };
        if verification.is_err() {
            self.unpublish_ports(id)?;
            self.set_endpoint_state(
                id,
                if status.state == ServiceState::Running {
                    EndpointAvailability::Unhealthy
                } else {
                    EndpointAvailability::Stopped
                },
            );
            return Ok(());
        }
        let existing = self.ports.endpoints(id)?;
        if !published_matches_leases(&existing, &leases) {
            self.publish_ports(id)?;
        }
        self.set_endpoint_state(id, EndpointAvailability::Healthy);
        Ok(())
    }

    async fn wait_for_publishable(
        &self,
        provider: &dyn Provider,
        svc: &Service,
        leases: &[PortLease],
    ) -> Result<ServiceStatus> {
        let deadline = Instant::now() + startup_health_timeout(svc);
        loop {
            let last_error = match provider.status(svc).await {
                Ok(status) if status.state == ServiceState::Running => {
                    match probe_all_health(svc)
                        .await
                        .and_then(|_| self.verify_endpoint_ownership(&status, leases, true))
                    {
                        Ok(()) => return Ok(status),
                        Err(error) => error.to_string(),
                    }
                }
                Ok(status) => format!("provider state is {:?}", status.state),
                Err(error) => error.to_string(),
            };
            if Instant::now() >= deadline {
                return Err(AppError::BadRequest(format!(
                    "service {} is unhealthy: {}",
                    svc.id, last_error
                )));
            }
            tokio::time::sleep(health_poll_interval(svc)).await;
        }
    }

    fn verify_endpoint_ownership(
        &self,
        status: &ServiceStatus,
        leases: &[PortLease],
        health_checks_passed: bool,
    ) -> Result<()> {
        let endpoint_leases: Vec<&PortLease> = leases
            .iter()
            .filter(|lease| lease.endpoint.is_some())
            .collect();
        if endpoint_leases.is_empty() {
            return Ok(());
        }
        if status.state != ServiceState::Running {
            return Err(AppError::BadRequest(format!(
                "cannot verify endpoint owner: provider state is {:?}",
                status.state
            )));
        }
        let pid = status.pid.ok_or_else(|| {
            AppError::BadRequest(
                "cannot verify endpoint owner: provider status did not report pid".to_string(),
            )
        })?;
        let current_leases = self.ports.leases(&status.service_id)?;
        let fallback_context = EndpointOwnershipFallbackContext {
            platform: current_endpoint_ownership_platform(),
            state: status.state,
            pid: status.pid,
            provider_identity_verified: provider_status_has_verified_identity(status),
            leases_currently_managed: leases_are_current_manager_allocations(
                &status.service_id,
                leases,
                &current_leases,
            ),
            health_checks_passed,
        };
        match verify_proc_socket_ownership(&self.procfs_root, pid, &endpoint_leases) {
            Ok(()) => Ok(()),
            Err(failure) if android_constrained_fallback_allowed(&failure, fallback_context) => {
                warn!(
                    service_id = %status.service_id,
                    pid,
                    reason = %failure,
                    "Android endpoint ownership introspection is unavailable; accepting constrained fallback"
                );
                Ok(())
            }
            Err(failure) => Err(AppError::BadRequest(failure.to_string())),
        }
    }

    async fn stop_for_replacement(
        &self,
        id: &ServiceId,
        svc: &Service,
        provider: &dyn Provider,
        context: &str,
    ) -> Result<()> {
        let leases = self.ports.leases(id)?;
        let runtime_svc = match materialize_service(svc, &leases) {
            Ok(service) => service,
            Err(error) => {
                let reason = format!(
                    "{context} could not materialize the previous instance; lease retained as orphan evidence: {error}"
                );
                self.mark_orphan(id, &reason)?;
                return Err(AppError::BadRequest(reason));
            }
        };
        self.unpublish_ports(id)?;
        if let Err(error) = provider.stop(&runtime_svc).await {
            let reason = format!(
                "{context} could not stop the previous instance; lease retained as orphan evidence: {error}"
            );
            self.mark_orphan(id, &reason)?;
            return Err(AppError::BadRequest(reason));
        }
        Ok(())
    }

    async fn launch_with_retries(
        &self,
        id: &ServiceId,
        svc: &Service,
        provider: &dyn Provider,
        force_start: bool,
        context: &str,
    ) -> Result<()> {
        let max_attempts = if svc.spec.ports.iter().any(|port| port.dynamic) {
            3
        } else {
            1
        };

        for attempt in 1..=max_attempts {
            let leases = self.allocate_ports(id, &svc.spec.ports).map_err(|error| {
                AppError::BadRequest(format!(
                    "{context} could not allocate ports on attempt {attempt}: {error}"
                ))
            })?;
            let runtime_svc = match materialize_service(svc, &leases) {
                Ok(service) => service,
                Err(error) => {
                    self.unpublish_ports(id)?;
                    self.release_ports(id)?;
                    self.set_endpoint_state(id, EndpointAvailability::Unhealthy);
                    return Err(error);
                }
            };
            self.set_endpoint_state(id, EndpointAvailability::Starting);

            if let Err(error) = provider.register(&runtime_svc).await {
                self.unpublish_ports(id)?;
                self.release_ports(id)?;
                self.set_endpoint_state(id, EndpointAvailability::Unhealthy);
                return Err(AppError::BadRequest(format!(
                    "{context} registration failed on attempt {attempt}: {error}"
                )));
            }

            let launch_error = if force_start {
                provider.start(&runtime_svc).await.err()
            } else {
                match provider.status(&runtime_svc).await {
                    Ok(status) if status.state == ServiceState::Running => None,
                    Ok(_) => provider.start(&runtime_svc).await.err(),
                    Err(error) => Some(error),
                }
            };
            let attempt_error = match launch_error {
                Some(error) => Some(AppError::BadRequest(format!(
                    "provider launch failed: {error}"
                ))),
                None => self
                    .wait_for_publishable(provider, &runtime_svc, &leases)
                    .await
                    .err(),
            };

            if let Some(error) = attempt_error {
                let original = error.to_string();
                self.cleanup_failed_attempt(id, provider, &runtime_svc, context, &original)
                    .await?;
                if attempt < max_attempts {
                    continue;
                }
                return Err(AppError::BadRequest(format!(
                    "{context} failed after {attempt} attempt(s): {original}; failed instance stopped and lease released"
                )));
            }

            self.publish_ports(id)?;
            self.set_endpoint_state(id, EndpointAvailability::Healthy);
            return Ok(());
        }
        Err(AppError::Internal)
    }

    async fn cleanup_failed_attempt(
        &self,
        id: &ServiceId,
        provider: &dyn Provider,
        runtime_svc: &Service,
        context: &str,
        original: &str,
    ) -> Result<()> {
        self.unpublish_ports(id)?;
        if let Err(stop_error) = provider.stop(runtime_svc).await {
            let reason = format!(
                "{context} failed: {original}; cleanup stop failed and lease was retained as orphan evidence: {stop_error}"
            );
            self.mark_orphan(id, &reason)?;
            return Err(AppError::BadRequest(reason));
        }
        self.release_ports(id)?;
        self.set_endpoint_state(id, EndpointAvailability::Unhealthy);
        Ok(())
    }

    pub async fn logs(
        &self,
        id: &ServiceId,
        opts: LogsOptions,
    ) -> Result<Vec<crate::model::LogEntry>> {
        let svc = self.store.get_service(id)?;
        let p = self
            .registry
            .get(&svc.spec.provider)
            .ok_or_else(|| AppError::ProviderNotFound(svc.spec.provider.0.clone()))?;
        p.logs(&svc, opts).await
    }

    pub fn list_audit_events(&self, limit: Option<usize>) -> Result<Vec<AuditEvent>> {
        self.store.list_audit_events(limit)
    }

    pub fn export(&self) -> Result<Vec<u8>> {
        self.store.export()
    }

    pub fn import(&self, data: &[u8]) -> Result<()> {
        self.store.import(data)
    }
}

fn materialize_service(svc: &Service, leases: &[PortLease]) -> Result<Service> {
    let mut runtime = svc.clone();
    let mut values = BTreeMap::new();

    for lease in leases {
        if lease.service_id != svc.id {
            return Err(AppError::BadRequest(format!(
                "port lease {} belongs to service {}, not {}",
                lease.port_name, lease.service_id, svc.id
            )));
        }
        let value = lease.allocated_port.to_string();
        values.insert(lease.port_name.clone(), value.clone());
        runtime
            .spec
            .env
            .insert(canonical_port_env(&lease.port_name), value.clone());
        if !lease.env_var.trim().is_empty() {
            runtime.spec.env.insert(lease.env_var.clone(), value);
        }
    }

    for arg in &mut runtime.spec.command {
        *arg = replace_port_templates(arg, &values);
    }
    for value in runtime.spec.env.values_mut() {
        *value = replace_port_templates(value, &values);
    }
    runtime.spec.working_dir = replace_port_templates(&runtime.spec.working_dir, &values);
    for health in &mut runtime.spec.health {
        health.url = replace_port_templates(&health.url, &values);
        health.address = replace_port_templates(&health.address, &values);
    }
    for value in runtime.spec.runtime.values_mut() {
        replace_json_templates(value, &values);
    }
    if runtime
        .spec
        .command
        .iter()
        .any(|value| contains_port_template(value))
        || runtime
            .spec
            .env
            .values()
            .any(|value| contains_port_template(value))
        || contains_port_template(&runtime.spec.working_dir)
        || runtime.spec.health.iter().any(|health| {
            contains_port_template(&health.url) || contains_port_template(&health.address)
        })
        || runtime
            .spec
            .runtime
            .values()
            .any(contains_json_port_template)
    {
        return Err(AppError::BadRequest(format!(
            "service {} contains an unresolved {{port:name}} template",
            svc.id
        )));
    }
    Ok(runtime)
}

fn normalize_status(svc: &Service, status: &mut ServiceStatus, now: DateTime<Utc>) {
    if status.service_id.0.trim().is_empty() {
        status.service_id = svc.id.clone();
    }
    if status.provider.0.trim().is_empty() {
        status.provider = svc.spec.provider.clone();
    }
    if status.observed_at.timestamp() == 0 && status.observed_at.timestamp_subsec_nanos() == 0 {
        status.observed_at = now;
    }
}

fn published_matches_leases(endpoints: &[ServiceEndpoint], leases: &[PortLease]) -> bool {
    let published_leases: Vec<&PortLease> = leases
        .iter()
        .filter(|lease| lease.endpoint.is_some())
        .collect();
    endpoints.len() == published_leases.len()
        && published_leases.iter().all(|lease| {
            endpoints.iter().any(|endpoint| {
                endpoint.service_id == lease.service_id
                    && endpoint.name == lease.port_name
                    && endpoint.host == lease.host
                    && endpoint.port == lease.allocated_port
                    && endpoint.protocol == lease.protocol
            })
        })
}

fn canonical_port_env(name: &str) -> String {
    let suffix: String = name
        .chars()
        .map(|ch| {
            if ch.is_ascii_alphanumeric() {
                ch.to_ascii_uppercase()
            } else {
                '_'
            }
        })
        .collect();
    format!("SERVICE_MANAGER_PORT_{suffix}")
}

fn replace_port_templates(input: &str, values: &BTreeMap<String, String>) -> String {
    let mut output = input.to_string();
    for (name, value) in values {
        output = output.replace(&format!("{{{{port:{name}}}}}"), value);
    }
    output
}

fn replace_json_templates(value: &mut serde_json::Value, values: &BTreeMap<String, String>) {
    match value {
        serde_json::Value::String(text) => *text = replace_port_templates(text, values),
        serde_json::Value::Array(items) => {
            for item in items {
                replace_json_templates(item, values);
            }
        }
        serde_json::Value::Object(items) => {
            for item in items.values_mut() {
                replace_json_templates(item, values);
            }
        }
        serde_json::Value::Null | serde_json::Value::Bool(_) | serde_json::Value::Number(_) => {}
    }
}

fn contains_port_template(value: &str) -> bool {
    value.contains("{{port:")
}

fn contains_json_port_template(value: &serde_json::Value) -> bool {
    match value {
        serde_json::Value::String(text) => contains_port_template(text),
        serde_json::Value::Array(items) => items.iter().any(contains_json_port_template),
        serde_json::Value::Object(items) => items.values().any(contains_json_port_template),
        serde_json::Value::Null | serde_json::Value::Bool(_) | serde_json::Value::Number(_) => {
            false
        }
    }
}

fn validate_service_spec(spec: &mut ServiceSpec) -> Result<()> {
    spec.validate()?;
    if spec.ports.iter().any(|port| port.endpoint.is_some()) && spec.health.is_empty() {
        return Err(AppError::BadRequest(
            "services with published endpoints must declare at least one health check".to_string(),
        ));
    }
    Ok(())
}

fn startup_health_timeout(svc: &Service) -> Duration {
    let explicit_timeout = svc
        .spec
        .health
        .iter()
        .map(|check| check.timeout.0)
        .filter(|timeout| !timeout.is_zero())
        .max();
    explicit_timeout
        .map(|timeout| (timeout * 5).clamp(Duration::from_secs(1), Duration::from_secs(30)))
        .unwrap_or_else(|| Duration::from_secs(30))
}

fn health_poll_interval(svc: &Service) -> Duration {
    svc.spec
        .health
        .iter()
        .map(|check| check.interval.0)
        .filter(|interval| !interval.is_zero())
        .min()
        .unwrap_or_else(|| Duration::from_millis(250))
        .min(Duration::from_secs(2))
}

async fn probe_all_health(svc: &Service) -> Result<()> {
    for check in &svc.spec.health {
        probe_health(check).await?;
    }
    Ok(())
}

async fn probe_health(check: &HealthCheck) -> Result<()> {
    let check = check.clone();
    tokio::task::spawn_blocking(move || probe_health_blocking(&check))
        .await
        .map_err(|_| AppError::Internal)?
}

fn probe_health_blocking(check: &HealthCheck) -> Result<()> {
    let timeout = if check.timeout.0.is_zero() {
        Duration::from_secs(2)
    } else {
        check.timeout.0
    };
    match check.ty {
        HealthCheckType::Tcp => connect_tcp(&check.address, timeout).map(|_| ()),
        HealthCheckType::Http => probe_http(&check.url, timeout),
    }
}

fn connect_tcp(address: &str, timeout: Duration) -> Result<TcpStream> {
    let addresses = address
        .to_socket_addrs()
        .map_err(|e| AppError::BadRequest(format!("resolve health address {address:?}: {e}")))?;
    let mut last_error = None;
    for address in addresses {
        match TcpStream::connect_timeout(&address, timeout) {
            Ok(stream) => return Ok(stream),
            Err(error) => last_error = Some(error),
        }
    }
    Err(AppError::BadRequest(format!(
        "tcp health check failed for {address:?}: {}",
        last_error
            .map(|error| error.to_string())
            .unwrap_or_else(|| "no resolved addresses".to_string())
    )))
}

fn probe_http(url: &str, timeout: Duration) -> Result<()> {
    let raw = url.strip_prefix("http://").ok_or_else(|| {
        AppError::BadRequest("http health checks require an http:// URL".to_string())
    })?;
    let (authority, path) = raw
        .split_once('/')
        .map(|(authority, path)| (authority, format!("/{path}")))
        .unwrap_or((raw, "/".to_string()));
    let address = if authority.contains(':') {
        authority.to_string()
    } else {
        format!("{authority}:80")
    };
    let mut stream = connect_tcp(&address, timeout)?;
    stream.set_read_timeout(Some(timeout))?;
    stream.set_write_timeout(Some(timeout))?;
    write!(
        stream,
        "GET {path} HTTP/1.1\r\nHost: {authority}\r\nConnection: close\r\n\r\n"
    )?;
    let mut response = [0u8; 64];
    let read = stream.read(&mut response)?;
    let first_line = String::from_utf8_lossy(&response[..read]);
    let status = first_line
        .split_whitespace()
        .nth(1)
        .and_then(|value| value.parse::<u16>().ok())
        .ok_or_else(|| AppError::BadRequest(format!("invalid HTTP health response from {url}")))?;
    if !(200..400).contains(&status) {
        return Err(AppError::BadRequest(format!(
            "HTTP health check {url} returned {status}"
        )));
    }
    Ok(())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum EndpointOwnershipPlatform {
    Android,
    Strict,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum EndpointOwnershipIntrospectionOperation {
    PidfdOpen,
    PidfdGetfd,
    ReadProcessFdDirectory,
}

impl std::fmt::Display for EndpointOwnershipIntrospectionOperation {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let name = match self {
            Self::PidfdOpen => "pidfd_open",
            Self::PidfdGetfd => "pidfd_getfd",
            Self::ReadProcessFdDirectory => "read process fd directory",
        };
        formatter.write_str(name)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum EndpointOwnershipUnavailableReason {
    SyscallMissing,
    PermissionDenied,
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum EndpointOwnershipFailure {
    IntrospectionUnavailable {
        operation: EndpointOwnershipIntrospectionOperation,
        reason: EndpointOwnershipUnavailableReason,
        errno: i32,
    },
    SocketMismatch(String),
    Other(String),
}

impl std::fmt::Display for EndpointOwnershipFailure {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::IntrospectionUnavailable {
                operation,
                reason,
                errno,
            } => write!(
                formatter,
                "cannot verify endpoint owner: {operation} introspection is unavailable ({reason:?}, os error {errno})"
            ),
            Self::SocketMismatch(message) | Self::Other(message) => formatter.write_str(message),
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct EndpointOwnershipFallbackContext {
    platform: EndpointOwnershipPlatform,
    state: ServiceState,
    pid: Option<u32>,
    provider_identity_verified: bool,
    leases_currently_managed: bool,
    health_checks_passed: bool,
}

fn current_endpoint_ownership_platform() -> EndpointOwnershipPlatform {
    if cfg!(target_os = "android") {
        EndpointOwnershipPlatform::Android
    } else {
        EndpointOwnershipPlatform::Strict
    }
}

fn provider_status_has_verified_identity(status: &ServiceStatus) -> bool {
    matches!(
        status.provider.0.as_str(),
        "process" | "termux-process" | "proot-distro"
    )
}

fn leases_are_current_manager_allocations(
    service_id: &ServiceId,
    leases: &[PortLease],
    current_leases: &[PortLease],
) -> bool {
    !leases.is_empty()
        && current_leases == leases
        && leases.iter().all(|lease| {
            lease.service_id == *service_id
                && matches!(
                    lease.lifecycle,
                    crate::model::PortLeaseLifecycle::Leased
                        | crate::model::PortLeaseLifecycle::Published
                )
                && lease.orphan_reason.is_none()
        })
}

fn android_constrained_fallback_allowed(
    failure: &EndpointOwnershipFailure,
    context: EndpointOwnershipFallbackContext,
) -> bool {
    if context.platform != EndpointOwnershipPlatform::Android
        || context.state != ServiceState::Running
        || context.pid.is_none()
        || !context.provider_identity_verified
        || !context.leases_currently_managed
        || !context.health_checks_passed
    {
        return false;
    }

    match failure {
        EndpointOwnershipFailure::IntrospectionUnavailable {
            operation,
            reason: EndpointOwnershipUnavailableReason::SyscallMissing,
            ..
        } => matches!(
            operation,
            EndpointOwnershipIntrospectionOperation::PidfdOpen
                | EndpointOwnershipIntrospectionOperation::PidfdGetfd
        ),
        EndpointOwnershipFailure::IntrospectionUnavailable {
            operation,
            reason: EndpointOwnershipUnavailableReason::PermissionDenied,
            ..
        } => matches!(
            operation,
            EndpointOwnershipIntrospectionOperation::PidfdOpen
                | EndpointOwnershipIntrospectionOperation::PidfdGetfd
                | EndpointOwnershipIntrospectionOperation::ReadProcessFdDirectory
        ),
        EndpointOwnershipFailure::SocketMismatch(_) | EndpointOwnershipFailure::Other(_) => false,
    }
}

fn classify_endpoint_introspection_error(
    operation: EndpointOwnershipIntrospectionOperation,
    error: &io::Error,
) -> Option<EndpointOwnershipFailure> {
    let errno = error.raw_os_error()?;
    let reason = if errno == libc::ENOSYS {
        EndpointOwnershipUnavailableReason::SyscallMissing
    } else if errno == libc::EPERM || errno == libc::EACCES {
        EndpointOwnershipUnavailableReason::PermissionDenied
    } else {
        return None;
    };
    Some(EndpointOwnershipFailure::IntrospectionUnavailable {
        operation,
        reason,
        errno,
    })
}

fn verify_proc_socket_ownership(
    procfs_root: &Path,
    status_pid: u32,
    leases: &[&PortLease],
) -> std::result::Result<(), EndpointOwnershipFailure> {
    #[cfg(not(any(target_os = "linux", target_os = "android")))]
    {
        let _ = (procfs_root, status_pid, leases);
        return Err(EndpointOwnershipFailure::Other(
            "endpoint owner verification is unsupported on this platform".to_string(),
        ));
    }

    #[cfg(any(target_os = "linux", target_os = "android"))]
    {
        let target_pgrp = read_proc_pgrp(procfs_root, status_pid)
            .map_err(|error| EndpointOwnershipFailure::Other(error.to_string()))?;
        let sockets = process_group_sockets_via_pidfd(procfs_root, target_pgrp)?;
        for lease in leases {
            if !sockets
                .iter()
                .any(|socket| socket_matches_lease(socket, lease))
            {
                return Err(EndpointOwnershipFailure::SocketMismatch(format!(
                    "cannot verify endpoint owner: managed process group {} has no matching {} listener on {}:{}",
                    target_pgrp,
                    protocol_name(lease.protocol),
                    lease.host,
                    lease.allocated_port
                )));
            }
        }
        Ok(())
    }
}

#[cfg(any(target_os = "linux", target_os = "android"))]
#[derive(Clone, Copy, Debug)]
struct ManagedSocket {
    address: IpAddr,
    port: u16,
    socket_type: libc::c_int,
    accepting: bool,
}

fn protocol_name(protocol: crate::model::ServicePortProtocol) -> &'static str {
    match protocol {
        crate::model::ServicePortProtocol::Tcp => "tcp",
        crate::model::ServicePortProtocol::Udp => "udp",
    }
}

#[cfg(any(target_os = "linux", target_os = "android"))]
fn read_proc_pgrp(procfs_root: &Path, pid: u32) -> Result<i64> {
    let stat_path = procfs_root.join(pid.to_string()).join("stat");
    let stat = fs::read_to_string(&stat_path).map_err(|error| {
        AppError::BadRequest(format!(
            "cannot verify endpoint owner: read {}: {error}",
            stat_path.display()
        ))
    })?;
    let close = stat.rfind(')').ok_or_else(|| {
        AppError::BadRequest(format!("invalid proc stat record: {}", stat_path.display()))
    })?;
    let fields: Vec<&str> = stat[close + 1..].split_whitespace().collect();
    fields
        .get(2)
        .ok_or_else(|| {
            AppError::BadRequest(format!("invalid proc stat record: {}", stat_path.display()))
        })?
        .parse::<i64>()
        .map_err(|_| {
            AppError::BadRequest(format!(
                "invalid proc process group: {}",
                stat_path.display()
            ))
        })
}

#[cfg(any(target_os = "linux", target_os = "android"))]
fn process_group_sockets_via_pidfd(
    procfs_root: &Path,
    target_pgrp: i64,
) -> std::result::Result<Vec<ManagedSocket>, EndpointOwnershipFailure> {
    let mut sockets = Vec::new();
    let mut unavailable = None;
    let mut saw_group_member = false;
    let mut saw_successful_introspection = false;
    let entries = fs::read_dir(procfs_root).map_err(|error| {
        EndpointOwnershipFailure::Other(format!(
            "cannot verify endpoint owner: read {}: {error}",
            procfs_root.display()
        ))
    })?;
    for entry in entries.flatten() {
        let Some(pid) = entry
            .file_name()
            .to_str()
            .and_then(|name| name.parse::<u32>().ok())
        else {
            continue;
        };
        if read_proc_pgrp(procfs_root, pid).ok() != Some(target_pgrp) {
            continue;
        }
        saw_group_member = true;
        let pidfd = match pidfd_open(pid) {
            Ok(pidfd) => pidfd,
            Err(error) => {
                if let Some(failure) = classify_endpoint_introspection_error(
                    EndpointOwnershipIntrospectionOperation::PidfdOpen,
                    &error,
                ) {
                    unavailable.get_or_insert(failure);
                    continue;
                }
                return Err(EndpointOwnershipFailure::Other(format!(
                    "cannot verify endpoint owner: pidfd_open({pid}) failed: {error}"
                )));
            }
        };
        let fd_dir = entry.path().join("fd");
        let fds = match fs::read_dir(&fd_dir) {
            Ok(fds) => fds,
            Err(error) => {
                if let Some(failure) = classify_endpoint_introspection_error(
                    EndpointOwnershipIntrospectionOperation::ReadProcessFdDirectory,
                    &error,
                ) {
                    unavailable.get_or_insert(failure);
                    continue;
                }
                return Err(EndpointOwnershipFailure::Other(format!(
                    "cannot verify endpoint owner: read {}: {error}",
                    fd_dir.display()
                )));
            }
        };
        let mut saw_fd = false;
        for fd in fds.flatten() {
            let Some(target_fd) = fd
                .file_name()
                .to_str()
                .and_then(|name| name.parse::<libc::c_int>().ok())
            else {
                continue;
            };
            saw_fd = true;
            match pidfd_getfd(pidfd.as_raw_fd(), target_fd) {
                Ok(duplicated) => {
                    saw_successful_introspection = true;
                    if let Some(socket) = inspect_socket(duplicated.as_raw_fd())
                        .map_err(|error| EndpointOwnershipFailure::Other(error.to_string()))?
                    {
                        sockets.push(socket);
                    }
                }
                Err(error) => {
                    if let Some(failure) = classify_endpoint_introspection_error(
                        EndpointOwnershipIntrospectionOperation::PidfdGetfd,
                        &error,
                    ) {
                        unavailable.get_or_insert(failure);
                        continue;
                    }
                    return Err(EndpointOwnershipFailure::Other(format!(
                        "cannot verify endpoint owner: pidfd_getfd({target_fd}) failed for pid {pid}: {error}"
                    )));
                }
            }
        }
        if !saw_fd {
            saw_successful_introspection = true;
        }
    }
    if sockets.is_empty() {
        if !saw_successful_introspection && let Some(failure) = unavailable {
            return Err(failure);
        }
        let detail = if saw_group_member {
            "no matching socket descriptors were inspectable"
        } else {
            "managed process group no longer has a live member"
        };
        return Err(EndpointOwnershipFailure::SocketMismatch(format!(
            "cannot verify endpoint owner with pidfd for process group {target_pgrp}: {detail}"
        )));
    }
    Ok(sockets)
}

#[cfg(any(target_os = "linux", target_os = "android"))]
fn pidfd_open(pid: u32) -> io::Result<OwnedFd> {
    let fd = unsafe { libc::syscall(libc::SYS_pidfd_open, pid as libc::pid_t, 0) };
    if fd < 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(unsafe { OwnedFd::from_raw_fd(fd as libc::c_int) })
}

#[cfg(any(target_os = "linux", target_os = "android"))]
fn pidfd_getfd(pidfd: libc::c_int, target_fd: libc::c_int) -> io::Result<OwnedFd> {
    let fd = unsafe { libc::syscall(libc::SYS_pidfd_getfd, pidfd, target_fd, 0) };
    if fd < 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(unsafe { OwnedFd::from_raw_fd(fd as libc::c_int) })
}

#[cfg(any(target_os = "linux", target_os = "android"))]
fn inspect_socket(fd: libc::c_int) -> Result<Option<ManagedSocket>> {
    let mut socket_type: libc::c_int = 0;
    let mut option_len = std::mem::size_of::<libc::c_int>() as libc::socklen_t;
    if unsafe {
        libc::getsockopt(
            fd,
            libc::SOL_SOCKET,
            libc::SO_TYPE,
            (&mut socket_type as *mut libc::c_int).cast(),
            &mut option_len,
        )
    } != 0
    {
        let error = io::Error::last_os_error();
        if error.raw_os_error() == Some(libc::ENOTSOCK) {
            return Ok(None);
        }
        return Err(AppError::Io(error));
    }

    let mut storage: libc::sockaddr_storage = unsafe { std::mem::zeroed() };
    let mut address_len = std::mem::size_of::<libc::sockaddr_storage>() as libc::socklen_t;
    if unsafe {
        libc::getsockname(
            fd,
            (&mut storage as *mut libc::sockaddr_storage).cast(),
            &mut address_len,
        )
    } != 0
    {
        return Err(AppError::Io(io::Error::last_os_error()));
    }

    let (address, port) = match storage.ss_family as libc::c_int {
        libc::AF_INET => {
            let address = unsafe {
                &*((&storage as *const libc::sockaddr_storage).cast::<libc::sockaddr_in>())
            };
            (
                IpAddr::V4(Ipv4Addr::from(address.sin_addr.s_addr.to_ne_bytes())),
                u16::from_be(address.sin_port),
            )
        }
        libc::AF_INET6 => {
            let address = unsafe {
                &*((&storage as *const libc::sockaddr_storage).cast::<libc::sockaddr_in6>())
            };
            (
                IpAddr::V6(Ipv6Addr::from(address.sin6_addr.s6_addr)),
                u16::from_be(address.sin6_port),
            )
        }
        _ => return Ok(None),
    };

    let accepting = if socket_type == libc::SOCK_STREAM {
        let mut accepting: libc::c_int = 0;
        let mut accepting_len = std::mem::size_of::<libc::c_int>() as libc::socklen_t;
        if unsafe {
            libc::getsockopt(
                fd,
                libc::SOL_SOCKET,
                libc::SO_ACCEPTCONN,
                (&mut accepting as *mut libc::c_int).cast(),
                &mut accepting_len,
            )
        } != 0
        {
            return Err(AppError::Io(io::Error::last_os_error()));
        }
        accepting != 0
    } else {
        false
    };

    Ok(Some(ManagedSocket {
        address,
        port,
        socket_type,
        accepting,
    }))
}

#[cfg(any(target_os = "linux", target_os = "android"))]
fn socket_matches_lease(socket: &ManagedSocket, lease: &PortLease) -> bool {
    let protocol_matches = match lease.protocol {
        crate::model::ServicePortProtocol::Tcp => {
            socket.socket_type == libc::SOCK_STREAM && socket.accepting
        }
        crate::model::ServicePortProtocol::Udp => {
            socket.socket_type == libc::SOCK_DGRAM && socket.port != 0
        }
    };
    protocol_matches
        && socket.port == lease.allocated_port
        && lease_host_matches_socket(&lease.host, socket.address, lease.allocated_port)
}

#[cfg(any(target_os = "linux", target_os = "android"))]
fn lease_host_matches_socket(host: &str, actual: IpAddr, port: u16) -> bool {
    if actual.is_unspecified() {
        return true;
    }
    let expected: Vec<IpAddr> = if let Ok(address) = host.parse::<IpAddr>() {
        vec![address]
    } else {
        match (host, port).to_socket_addrs() {
            Ok(addresses) => addresses.map(|address| address.ip()).collect(),
            Err(_) => return false,
        }
    };
    expected.into_iter().any(|address| address == actual)
}

#[derive(Clone)]
pub struct AppState {
    pub config: Config,
    pub engine: Arc<Engine>,
}

fn service_groups(svc: &Service) -> Vec<String> {
    svc.spec
        .tags
        .iter()
        .filter_map(|tag| {
            let tag = tag.trim();
            let name = tag.strip_prefix(GROUP_TAG_PREFIX)?.trim();
            if name.is_empty() {
                None
            } else {
                Some(name.to_string())
            }
        })
        .collect()
}

fn validate_registry_service_id(raw: String) -> Result<String> {
    let value = raw.trim().to_string();
    if value.is_empty() {
        return Err(AppError::BadRequest(
            "service registry id is empty".to_string(),
        ));
    }
    let mut chars = value.chars();
    let Some(first) = chars.next() else {
        return Err(AppError::BadRequest(
            "service registry id is empty".to_string(),
        ));
    };
    if !first.is_ascii_alphanumeric() {
        return Err(AppError::BadRequest(format!(
            "invalid service registry id {:?}",
            value
        )));
    }
    let mut len = 1usize;
    for ch in chars {
        len += 1;
        if len > 64 || !(ch.is_ascii_alphanumeric() || matches!(ch, '.' | '_' | '-')) {
            return Err(AppError::BadRequest(format!(
                "invalid service registry id {:?}",
                value
            )));
        }
    }
    Ok(value)
}

pub async fn serve(
    cfg_path: Option<PathBuf>,
    bind: Option<String>,
    log_file: Option<PathBuf>,
) -> Result<()> {
    let (startup_logging, startup_log_level) =
        resolve_startup_logging(cfg_path.as_deref(), log_file.as_deref())?;
    logging::init(&startup_logging, &startup_log_level)?;

    let result = serve_inner(cfg_path, bind, log_file).await;
    if let Err(failure) = &result {
        error!("service-manager serve failed: {failure}");
    }
    result
}

async fn serve_inner(
    cfg_path: Option<PathBuf>,
    bind: Option<String>,
    log_file: Option<PathBuf>,
) -> Result<()> {
    let loaded = load_config(cfg_path)?;
    let mut cfg = loaded.config;
    if let Some(path) = log_file {
        cfg.logging.path = absolutize_path(path)?.to_string_lossy().to_string();
    }
    if let Some(b) = bind
        && !b.trim().is_empty()
    {
        cfg.listen_addr = b;
    }

    if cfg.store.ty.trim().is_empty() {
        cfg.store.ty = "json".to_string();
    }
    if cfg.store.ty != "json" {
        return Err(AppError::BadRequest(format!(
            "unsupported store type {:?}",
            cfg.store.ty
        )));
    }

    let store = Arc::new(JsonStore::open(cfg.store.path.clone())?);
    let ports = Arc::new(PortManager::open(
        cfg.port_state_path.clone(),
        cfg.port_pools.clone(),
    )?);
    let registry = ProviderRegistry::new();
    providers::register_defaults(&registry, PathBuf::from(&cfg.data_dir))?;
    let residency = Arc::new(ResidencyStore::open(
        Path::new(&cfg.data_dir).join("residency.json"),
    )?);
    let runtime_endpoint_snapshot_path = runtime_endpoint_snapshot_path(&cfg);
    let runtime_endpoint_snapshot = Arc::new(RuntimeEndpointSnapshotPublisher::new(
        runtime_endpoint_snapshot_path,
        new_id(16)?,
    )?);
    let procfs_root = env::var_os("SERVICE_MANAGER_PROCFS_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/proc"));
    let engine = Arc::new(Engine::new_with_procfs_root_and_residency_and_snapshot(
        store,
        registry,
        ports,
        procfs_root,
        residency,
        Some(runtime_endpoint_snapshot),
    ));
    let loaded_services =
        service_registry::load_from_dir(&engine, Path::new(&cfg.service_registry_dir))?;
    if loaded_services > 0 {
        info!(
            "loaded {} registered services from {}",
            loaded_services, cfg.service_registry_dir
        );
    }
    for service in engine.list_services()? {
        engine.seed_residency(&service)?;
    }
    let state = AppState {
        config: cfg.clone(),
        engine: Arc::clone(&engine),
    };

    let app = api::router(state.clone());

    let listener = TcpListener::bind(&cfg.listen_addr)
        .await
        .map_err(|e| AppError::BadRequest(format!("bind {}: {e}", cfg.listen_addr)))?;
    // Only an instance that successfully owns the API listener may replace the runtime snapshot.
    // This prevents a failed upgrade/second instance from overwriting the active manager's file.
    engine.initialize_runtime_endpoint_snapshot();
    engine.spawn_residency_reconciler();
    engine.spawn_runtime_endpoint_snapshot_writer();
    info!("listening on {}", cfg.listen_addr);

    let (shutdown_tx, shutdown_rx) = tokio::sync::oneshot::channel();
    let server = async move {
        axum::serve(listener, app)
            .with_graceful_shutdown(async move {
                let _ = shutdown_rx.await;
            })
            .await
    };
    let outcome = run_server_with_shutdown_escalation(
        server,
        shutdown_signal_receiver(),
        move || {
            let _ = shutdown_tx.send(());
        },
        SHUTDOWN_GRACE_PERIOD,
    )
    .await
    .map_err(|e| {
        warn!("server error: {e}");
        AppError::Internal
    })?;
    match shutdown_disposition(outcome) {
        ShutdownDisposition::Return => {}
        ShutdownDisposition::ExitProcess => {
            match outcome {
                ServerShutdownOutcome::Graceful => {
                    info!(
                        "graceful shutdown completed after signal; exiting service-manager process"
                    );
                }
                ServerShutdownOutcome::DeadlineExceeded => {
                    warn!(
                        "graceful shutdown exceeded {:?}; forcing service-manager process exit",
                        SHUTDOWN_GRACE_PERIOD
                    );
                }
                ServerShutdownOutcome::SecondSignal => {
                    warn!("second shutdown signal received; forcing service-manager process exit");
                }
                ServerShutdownOutcome::Completed => unreachable!("natural completion must return"),
            }
            // Exit only the manager. Provider-owned service processes remain independent, while
            // manager monitor tasks cannot hold the Tokio runtime open during an upgrade.
            std::process::exit(0);
        }
    }

    Ok(())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ServerShutdownOutcome {
    Completed,
    Graceful,
    DeadlineExceeded,
    SecondSignal,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ShutdownDisposition {
    Return,
    ExitProcess,
}

fn shutdown_disposition(outcome: ServerShutdownOutcome) -> ShutdownDisposition {
    match outcome {
        ServerShutdownOutcome::Completed => ShutdownDisposition::Return,
        ServerShutdownOutcome::Graceful
        | ServerShutdownOutcome::DeadlineExceeded
        | ServerShutdownOutcome::SecondSignal => ShutdownDisposition::ExitProcess,
    }
}

async fn run_server_with_shutdown_escalation<Server, Trigger, Error>(
    server: Server,
    mut signals: tokio::sync::mpsc::UnboundedReceiver<()>,
    trigger_graceful_shutdown: Trigger,
    grace_period: Duration,
) -> std::result::Result<ServerShutdownOutcome, Error>
where
    Server: Future<Output = std::result::Result<(), Error>>,
    Trigger: FnOnce(),
{
    tokio::pin!(server);
    tokio::select! {
        result = &mut server => {
            result?;
            Ok(ServerShutdownOutcome::Completed)
        }
        Some(()) = signals.recv() => {
            trigger_graceful_shutdown();
            let deadline = tokio::time::sleep(grace_period);
            tokio::pin!(deadline);
            tokio::select! {
                result = &mut server => {
                    result?;
                    Ok(ServerShutdownOutcome::Graceful)
                }
                _ = &mut deadline => Ok(ServerShutdownOutcome::DeadlineExceeded),
                Some(()) = signals.recv() => Ok(ServerShutdownOutcome::SecondSignal),
            }
        }
    }
}

fn shutdown_signal_receiver() -> tokio::sync::mpsc::UnboundedReceiver<()> {
    let (sender, receiver) = tokio::sync::mpsc::unbounded_channel();
    tokio::spawn(async move {
        #[cfg(unix)]
        let mut terminate = {
            use tokio::signal::unix::{SignalKind, signal};
            signal(SignalKind::terminate()).expect("failed to install SIGTERM handler")
        };

        loop {
            #[cfg(unix)]
            tokio::select! {
                result = tokio::signal::ctrl_c() => {
                    result.expect("failed to install Ctrl+C handler");
                }
                _ = terminate.recv() => {}
            }

            #[cfg(not(unix))]
            tokio::signal::ctrl_c()
                .await
                .expect("failed to install Ctrl+C handler");

            if sender.send(()).is_err() {
                break;
            }
        }
    });
    receiver
}

pub fn load_config(path: Option<PathBuf>) -> Result<LoadedConfig> {
    let mut cfg = default_config()?;
    let cfg_path = match path {
        Some(p) => p,
        None => default_config_path()?,
    };

    match fs::read(&cfg_path) {
        Ok(b) => {
            if !b.iter().all(|c| c.is_ascii_whitespace()) {
                let file_cfg: ConfigFile = serde_json::from_slice(&b)?;
                file_cfg.apply(&mut cfg);
            }
        }
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
        Err(e) => return Err(AppError::Io(e)),
    }

    apply_defaults(&mut cfg)?;
    apply_env(&mut cfg);
    ensure_token(&mut cfg, &cfg_path)?;
    ensure_dirs(&cfg)?;
    Ok(LoadedConfig {
        config: cfg,
        path: cfg_path,
    })
}

pub fn default_config() -> Result<Config> {
    let cfg_dir = user_config_dir()?;
    let data_dir = cfg_dir.join("service-manager").join("data");
    let service_registry_dir = cfg_dir
        .join("openhouseai")
        .join("service-manager")
        .join("services.d");
    let openhouse_registry_source_dir = cfg_dir.join("openhouseai");
    Ok(Config {
        listen_addr: DEFAULT_LISTEN_ADDR.to_string(),
        data_dir: data_dir.to_string_lossy().to_string(),
        service_registry_dir: service_registry_dir.to_string_lossy().to_string(),
        openhouse_registry_source_dir: openhouse_registry_source_dir.to_string_lossy().to_string(),
        openhouse_registry_target_dir: openhouse_registry::DEFAULT_TARGET_DIR.to_string(),
        auth_token: String::new(),
        log_level: "info".to_string(),
        logging: LoggingConfig {
            path: data_dir
                .join("logs")
                .join("service-manager.log")
                .to_string_lossy()
                .to_string(),
            ..LoggingConfig::default()
        },
        store: StoreConfig {
            ty: "json".to_string(),
            path: data_dir.join("store.json").to_string_lossy().to_string(),
        },
        port_pools: vec![PortPoolSpec::local_web_default()],
        port_state_path: data_dir.join("ports.json").to_string_lossy().to_string(),
    })
}

pub fn default_config_path() -> Result<PathBuf> {
    let cfg_dir = user_config_dir()?;
    Ok(cfg_dir.join("service-manager").join("config.json"))
}

fn runtime_endpoint_snapshot_path(cfg: &Config) -> PathBuf {
    Path::new(&cfg.openhouse_registry_source_dir)
        .join("runtime")
        .join("endpoints.json")
}

#[derive(Debug, Deserialize)]
struct ConfigFile {
    listen_addr: Option<String>,
    data_dir: Option<String>,
    service_registry_dir: Option<String>,
    openhouse_registry_source_dir: Option<String>,
    openhouse_registry_target_dir: Option<String>,
    auth_token: Option<String>,
    log_level: Option<String>,
    logging: Option<LoggingConfigFile>,
    store: Option<StoreConfigFile>,
    port_pools: Option<Vec<PortPoolSpec>>,
    port_state_path: Option<String>,
}

#[derive(Debug, Deserialize)]
struct StoreConfigFile {
    #[serde(rename = "type")]
    ty: Option<String>,
    path: Option<String>,
}

#[derive(Debug, Deserialize)]
struct LoggingConfigFile {
    path: Option<String>,
    max_bytes: Option<u64>,
    retain_files: Option<usize>,
}

impl ConfigFile {
    fn apply(self, cfg: &mut Config) {
        let derive_port_state_path = self.data_dir.is_some() && self.port_state_path.is_none();
        let derive_logging_path = self.data_dir.is_some()
            && self
                .logging
                .as_ref()
                .and_then(|logging| logging.path.as_ref())
                .is_none();
        if let Some(v) = self.listen_addr {
            cfg.listen_addr = v;
        }
        if let Some(v) = self.data_dir {
            cfg.data_dir = v;
        }
        if let Some(v) = self.service_registry_dir {
            cfg.service_registry_dir = v;
        }
        if let Some(v) = self.openhouse_registry_source_dir {
            cfg.openhouse_registry_source_dir = v;
        }
        if let Some(v) = self.openhouse_registry_target_dir {
            cfg.openhouse_registry_target_dir = v;
        }
        if let Some(v) = self.auth_token {
            cfg.auth_token = v;
        }
        if let Some(v) = self.log_level {
            cfg.log_level = v;
        }
        if let Some(logging) = self.logging {
            if let Some(v) = logging.path {
                cfg.logging.path = v;
            }
            if let Some(v) = logging.max_bytes {
                cfg.logging.max_bytes = v;
            }
            if let Some(v) = logging.retain_files {
                cfg.logging.retain_files = v;
            }
        }
        if derive_logging_path {
            cfg.logging.path.clear();
        }
        if let Some(s) = self.store {
            if let Some(v) = s.ty {
                cfg.store.ty = v;
            }
            if let Some(v) = s.path {
                cfg.store.path = v;
            }
        }
        if let Some(v) = self.port_pools {
            cfg.port_pools = v;
        }
        if let Some(v) = self.port_state_path {
            cfg.port_state_path = v;
        } else if derive_port_state_path {
            cfg.port_state_path.clear();
        }
    }
}

fn apply_defaults(cfg: &mut Config) -> Result<()> {
    if cfg.listen_addr.trim().is_empty() {
        cfg.listen_addr = DEFAULT_LISTEN_ADDR.to_string();
    }
    if cfg.log_level.trim().is_empty() {
        cfg.log_level = "info".to_string();
    }
    if cfg.store.ty.trim().is_empty() {
        cfg.store.ty = "json".to_string();
    }

    if cfg.data_dir.trim().is_empty() {
        cfg.data_dir = default_config()?.data_dir;
    }
    if cfg.logging.path.trim().is_empty() {
        cfg.logging.path = Path::new(&cfg.data_dir)
            .join("logs")
            .join("service-manager.log")
            .to_string_lossy()
            .to_string();
    }
    cfg.logging.validate()?;
    if cfg.service_registry_dir.trim().is_empty() {
        cfg.service_registry_dir = default_config()?.service_registry_dir;
    }
    if cfg.openhouse_registry_source_dir.trim().is_empty() {
        cfg.openhouse_registry_source_dir = default_config()?.openhouse_registry_source_dir;
    }
    if cfg.openhouse_registry_target_dir.trim().is_empty() {
        cfg.openhouse_registry_target_dir = default_config()?.openhouse_registry_target_dir;
    }
    if cfg.store.path.trim().is_empty() {
        cfg.store.path = Path::new(&cfg.data_dir)
            .join("store.json")
            .to_string_lossy()
            .to_string();
    }
    if cfg.port_pools.is_empty() {
        cfg.port_pools.push(PortPoolSpec::local_web_default());
    }
    for pool in &mut cfg.port_pools {
        pool.validate()?;
    }
    if cfg.port_state_path.trim().is_empty() {
        cfg.port_state_path = Path::new(&cfg.data_dir)
            .join("ports.json")
            .to_string_lossy()
            .to_string();
    }
    Ok(())
}

fn apply_env(cfg: &mut Config) {
    if cfg.auth_token.trim().is_empty()
        && let Ok(tok) = env::var(ENV_AUTH_TOKEN)
    {
        let t = tok.trim().to_string();
        if !t.is_empty() {
            cfg.auth_token = t;
        }
    }
    if let Ok(dir) = env::var(ENV_SERVICE_REGISTRY_DIR) {
        let value = dir.trim().to_string();
        if !value.is_empty() {
            cfg.service_registry_dir = value;
        }
    }
    if let Ok(dir) = env::var(openhouse_registry::ENV_SOURCE_DIR) {
        let value = dir.trim().to_string();
        if !value.is_empty() {
            cfg.openhouse_registry_source_dir = value.clone();
            cfg.service_registry_dir = Path::new(&value)
                .join("service-manager")
                .join("services.d")
                .to_string_lossy()
                .to_string();
        }
    }
    if let Ok(dir) = env::var(openhouse_registry::ENV_TARGET_DIR) {
        let value = dir.trim().to_string();
        if !value.is_empty() {
            cfg.openhouse_registry_target_dir = value;
        }
    }
}

fn ensure_dirs(cfg: &Config) -> Result<()> {
    if cfg.data_dir.trim().is_empty() {
        return Err(AppError::BadRequest("config data_dir is empty".to_string()));
    }
    create_dir_all_700(Path::new(&cfg.data_dir))?;
    if !cfg.service_registry_dir.trim().is_empty() {
        create_dir_all_700(Path::new(&cfg.service_registry_dir))?;
    }
    if !cfg.openhouse_registry_source_dir.trim().is_empty() {
        create_dir_all_700(Path::new(&cfg.openhouse_registry_source_dir))?;
    }

    if !cfg.store.path.trim().is_empty()
        && let Some(parent) = Path::new(&cfg.store.path).parent()
    {
        create_dir_all_700(parent)?;
    }
    if !cfg.port_state_path.trim().is_empty()
        && let Some(parent) = Path::new(&cfg.port_state_path).parent()
    {
        create_dir_all_700(parent)?;
    }
    if let Some(parent) = Path::new(&cfg.logging.path).parent() {
        create_dir_all_700(parent)?;
    }
    Ok(())
}

fn resolve_startup_logging(
    cfg_path: Option<&Path>,
    log_file: Option<&Path>,
) -> Result<(LoggingConfig, String)> {
    let mut cfg = default_config()?;
    let path = match cfg_path {
        Some(path) => path.to_path_buf(),
        None => default_config_path()?,
    };
    if let Ok(bytes) = fs::read(path)
        && !bytes.iter().all(|byte| byte.is_ascii_whitespace())
        && let Ok(file_cfg) = serde_json::from_slice::<ConfigFile>(&bytes)
    {
        file_cfg.apply(&mut cfg);
    }
    if cfg.data_dir.trim().is_empty() {
        cfg.data_dir = default_config()?.data_dir;
    }
    if cfg.logging.path.trim().is_empty() {
        cfg.logging.path = Path::new(&cfg.data_dir)
            .join("logs")
            .join("service-manager.log")
            .to_string_lossy()
            .to_string();
    }
    if let Some(path) = log_file {
        cfg.logging.path = absolutize_path(path.to_path_buf())?
            .to_string_lossy()
            .to_string();
    }
    cfg.logging.validate()?;
    Ok((cfg.logging, cfg.log_level))
}

fn ensure_token(cfg: &mut Config, cfg_path: &Path) -> Result<()> {
    if !cfg.auth_token.trim().is_empty() {
        return Ok(());
    }

    let tok = random_token(32)?;
    cfg.auth_token = tok;

    // Best-effort persist.
    if cfg_path.as_os_str().is_empty() {
        return Ok(());
    }
    if let Some(parent) = cfg_path.parent() {
        create_dir_all_700(parent)?;
    }
    write_atomic_json(cfg_path, cfg)?;
    Ok(())
}

pub fn rotate_token(cfg_path: Option<PathBuf>) -> Result<(String, PathBuf)> {
    let mut loaded = load_config(cfg_path)?;
    loaded.config.auth_token = random_token(32)?;
    write_atomic_json(&loaded.path, &loaded.config)?;
    Ok((loaded.config.auth_token, loaded.path))
}

pub fn show_token(cfg_path: Option<PathBuf>) -> Result<(String, PathBuf)> {
    let loaded = load_config(cfg_path)?;
    Ok((loaded.config.auth_token, loaded.path))
}

pub fn config_paths(cfg_path: Option<PathBuf>) -> Result<(PathBuf, String, String)> {
    let loaded = load_config(cfg_path)?;
    Ok((
        loaded.path,
        loaded.config.data_dir,
        loaded.config.store.path,
    ))
}

fn user_config_dir() -> Result<PathBuf> {
    #[cfg(target_os = "windows")]
    {
        if let Some(v) = env::var_os("APPDATA") {
            return Ok(PathBuf::from(v));
        }
        if let Some(v) = env::var_os("USERPROFILE") {
            return Ok(PathBuf::from(v).join("AppData").join("Roaming"));
        }
        return Err(AppError::BadRequest(
            "cannot determine user config dir".to_string(),
        ));
    }

    #[cfg(target_os = "macos")]
    {
        let home =
            env::var_os("HOME").ok_or_else(|| AppError::BadRequest("HOME not set".to_string()))?;
        return Ok(PathBuf::from(home)
            .join("Library")
            .join("Application Support"));
    }

    #[cfg(all(unix, not(target_os = "macos")))]
    {
        if let Some(v) = env::var_os("XDG_CONFIG_HOME") {
            return Ok(PathBuf::from(v));
        }
        let home =
            env::var_os("HOME").ok_or_else(|| AppError::BadRequest("HOME not set".to_string()))?;
        Ok(PathBuf::from(home).join(".config"))
    }
}

fn create_dir_all_700(path: &Path) -> Result<()> {
    fs::create_dir_all(path)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o700));
    }
    Ok(())
}

fn write_atomic_json<T: Serialize>(path: &Path, v: &T) -> Result<()> {
    let b = serde_json::to_vec_pretty(v)?;
    let tmp = tmp_path(path);
    fs::write(&tmp, &b)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = fs::set_permissions(&tmp, fs::Permissions::from_mode(0o600));
    }
    if let Err(e) = fs::rename(&tmp, path) {
        let _ = fs::remove_file(path);
        fs::rename(&tmp, path).map_err(|_| AppError::Io(e))?;
    }
    Ok(())
}

fn tmp_path(path: &Path) -> PathBuf {
    let mut p = path.as_os_str().to_os_string();
    p.push(".tmp");
    PathBuf::from(p)
}

fn random_token(n_bytes: usize) -> Result<String> {
    if n_bytes == 0 {
        return Err(AppError::BadRequest("token bytes must be > 0".to_string()));
    }
    let mut b = vec![0u8; n_bytes];
    getrandom::getrandom(&mut b).map_err(|_| AppError::Internal)?;
    Ok(hex_encode(&b))
}

fn new_id(n_bytes: usize) -> Result<String> {
    // 128-bit random hex string by default (n_bytes=16). Good enough for local use.
    random_token(n_bytes)
}

fn hex_encode(b: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut out = Vec::with_capacity(b.len() * 2);
    for &x in b {
        out.push(HEX[(x >> 4) as usize]);
        out.push(HEX[(x & 0x0f) as usize]);
    }
    String::from_utf8(out).expect("hex is valid utf8")
}

pub fn health_payload() -> serde_json::Value {
    serde_json::json!({
        "ok": true,
        "time": Utc::now().to_rfc3339_opts(SecondsFormat::Nanos, true),
    })
}

pub fn install_service(
    cfg_path: Option<PathBuf>,
    bind: Option<String>,
    log_file: Option<PathBuf>,
) -> Result<()> {
    let cfg_path = cfg_path.map(absolutize_path).transpose()?;
    let loaded = load_config(cfg_path)?;
    let cfg_path = loaded.path;
    let log_file = match log_file {
        Some(path) => absolutize_path(path)?,
        None => PathBuf::from(loaded.config.logging.path),
    };

    let exe = env::current_exe().map_err(AppError::Io)?;
    let bind = bind.and_then(|b| {
        let b = b.trim().to_string();
        (!b.is_empty()).then_some(b)
    });

    // Termux runit.
    if let Some(prefix) = env::var_os("PREFIX") {
        let prefix_path = PathBuf::from(prefix);
        let var_service = prefix_path.join("var").join("service");
        if var_service.is_dir() {
            install_termux_runit(&var_service, &exe, &cfg_path, bind.as_deref(), &log_file)?;
            eprintln!(
                "installed Termux runit service at {}",
                var_service.display()
            );
            return Ok(());
        }
        if prefix_path.to_string_lossy().contains("com.termux") {
            return Err(AppError::BadRequest(format!(
                "Termux runit service directory not found: {}. Install termux-services first, then rerun install-service.",
                var_service.display()
            )));
        }
    }

    // macOS launchd user agent.
    #[cfg(target_os = "macos")]
    {
        install_launchd_user(&exe, &cfg_path, bind.as_deref(), &log_file)?;
        eprintln!("installed launchd agent (user) com.service-manager");
        return Ok(());
    }

    // Linux/systemd user unit (best effort on other UNIXes that have systemctl).
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        install_systemd_user(&exe, &cfg_path, bind.as_deref(), &log_file)?;
        eprintln!("installed systemd user unit service-manager.service");
        return Ok(());
    }

    #[allow(unreachable_code)]
    Err(AppError::BadRequest(
        "install-service is only supported on Termux (runit), Linux systemd user services, or macOS launchd user agents"
            .to_string(),
    ))
}

pub fn uninstall_service(cfg_path: Option<PathBuf>) -> Result<()> {
    let _cfg_path = match cfg_path {
        Some(p) => absolutize_path(p)?,
        None => default_config_path()?,
    };

    // Termux runit.
    if let Some(prefix) = env::var_os("PREFIX") {
        let var_service = PathBuf::from(prefix).join("var").join("service");
        if var_service.is_dir() {
            uninstall_termux_runit(&var_service)?;
            eprintln!(
                "uninstalled Termux runit service at {}",
                var_service.display()
            );
            return Ok(());
        }
    }

    #[cfg(target_os = "macos")]
    {
        uninstall_launchd_user()?;
        eprintln!("uninstalled launchd agent (user) com.service-manager");
        return Ok(());
    }

    #[cfg(all(unix, not(target_os = "macos")))]
    {
        uninstall_systemd_user()?;
        eprintln!("uninstalled systemd user unit service-manager.service");
        return Ok(());
    }

    #[allow(unreachable_code)]
    Err(AppError::BadRequest(format!(
        "uninstall-service is unsupported on this platform (config path was {})",
        _cfg_path.display()
    )))
}

fn absolutize_path(p: PathBuf) -> Result<PathBuf> {
    if p.is_absolute() {
        return Ok(p);
    }
    let cwd = env::current_dir().map_err(AppError::Io)?;
    Ok(cwd.join(p))
}

fn service_args(exe: &Path, cfg_path: &Path, bind: Option<&str>, log_file: &Path) -> Vec<String> {
    let mut args = vec![
        exe.to_string_lossy().to_string(),
        "serve".to_string(),
        "--config".to_string(),
        cfg_path.to_string_lossy().to_string(),
        "--log-file".to_string(),
        log_file.to_string_lossy().to_string(),
    ];
    if let Some(b) = bind {
        args.push("--bind".to_string());
        args.push(b.to_string());
    }
    args
}

fn sh_quote(s: &str) -> String {
    // POSIX shell single-quote escaping: close/open around embedded single quotes.
    if s.is_empty() {
        return "''".to_string();
    }
    let mut out = String::with_capacity(s.len() + 2);
    out.push('\'');
    for ch in s.chars() {
        if ch == '\'' {
            out.push_str("'\"'\"'");
        } else {
            out.push(ch);
        }
    }
    out.push('\'');
    out
}

fn systemd_escape_arg(s: &str) -> String {
    // systemd accepts double-quoted arguments in ExecStart. Escape " and \.
    let needs_quotes = s
        .chars()
        .any(|c| c.is_whitespace() || c == '"' || c == '\\');
    if !needs_quotes {
        return s.to_string();
    }
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for ch in s.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            _ => out.push(ch),
        }
    }
    out.push('"');
    out
}

fn write_text_file(path: &Path, contents: &str) -> Result<()> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = fs::set_permissions(parent, fs::Permissions::from_mode(0o755));
        }
    }
    fs::write(path, contents)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o644));
    }
    Ok(())
}

#[cfg(unix)]
fn write_executable_file(path: &Path, contents: &str) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;

    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
        let _ = fs::set_permissions(parent, fs::Permissions::from_mode(0o755));
    }
    fs::write(path, contents)?;
    let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o755));
    Ok(())
}

fn run_cmd(program: &str, args: &[&str]) -> Result<()> {
    let out = Command::new(program).args(args).output().map_err(|e| {
        if e.kind() == io::ErrorKind::NotFound {
            AppError::BadRequest(format!("{program} not found in PATH"))
        } else {
            AppError::Io(e)
        }
    })?;
    if out.status.success() {
        return Ok(());
    }
    let code = out.status.code().unwrap_or(-1);
    let stderr = String::from_utf8_lossy(&out.stderr).trim().to_string();
    let stdout = String::from_utf8_lossy(&out.stdout).trim().to_string();
    let mut msg = format!("command failed (exit {code}): {program} {}", args.join(" "));
    if !stderr.is_empty() {
        msg.push_str(&format!("\nstderr: {stderr}"));
    }
    if !stdout.is_empty() {
        msg.push_str(&format!("\nstdout: {stdout}"));
    }
    if program == "systemctl"
        && (stderr.contains("Failed to connect to bus")
            || stderr.contains("DBUS_SESSION_BUS_ADDRESS")
            || stderr.contains("XDG_RUNTIME_DIR"))
    {
        msg.push_str(
            "\n\nHint: systemd user services require a working user session bus. Try running from a normal login session, or ensure $XDG_RUNTIME_DIR and $DBUS_SESSION_BUS_ADDRESS are set, or enable lingering (loginctl enable-linger $USER) on headless machines.",
        );
    }
    Err(AppError::BadRequest(msg))
}

fn install_termux_runit(
    var_service_dir: &Path,
    exe: &Path,
    cfg_path: &Path,
    bind: Option<&str>,
    log_file: &Path,
) -> Result<()> {
    let svc_dir = var_service_dir.join("service-manager");
    fs::create_dir_all(&svc_dir)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = fs::set_permissions(&svc_dir, fs::Permissions::from_mode(0o700));
    }

    let run_path = svc_dir.join("run");
    let args = service_args(exe, cfg_path, bind, log_file);
    let script = termux_runit_run_script(&args);
    #[cfg(unix)]
    write_executable_file(&run_path, &script)?;
    #[cfg(not(unix))]
    {
        let _ = (run_path, script);
        return Err(AppError::BadRequest(
            "Termux runit install requires a Unix-like platform".to_string(),
        ));
    }

    // Ensure enabled by default.
    let down_path = svc_dir.join("down");
    let _ = fs::remove_file(down_path);

    // Best-effort start if sv exists.
    let _ = Command::new("sv").args(["up", "service-manager"]).output();

    Ok(())
}

fn uninstall_termux_runit(var_service_dir: &Path) -> Result<()> {
    let svc_dir = var_service_dir.join("service-manager");
    if !svc_dir.exists() {
        return Ok(());
    }

    let _ = Command::new("sv")
        .args(["down", "service-manager"])
        .output();
    // Remove service directory/symlink.
    if svc_dir.is_dir() {
        fs::remove_dir_all(&svc_dir)?;
    } else {
        let _ = fs::remove_file(&svc_dir);
    }
    Ok(())
}

fn termux_runit_run_script(args: &[String]) -> String {
    // termux-services expects an executable `run` that execs the daemon in foreground.
    // Use Termux's canonical shell path in the shebang.
    let mut cmd = String::new();
    for (i, a) in args.iter().enumerate() {
        if i > 0 {
            cmd.push(' ');
        }
        cmd.push_str(&sh_quote(a));
    }
    format!(
        "#!/data/data/com.termux/files/usr/bin/sh\n\
exec 2>&1\n\
exec {cmd} 2>&1\n"
    )
}

#[cfg(all(unix, not(target_os = "macos")))]
fn install_systemd_user(
    exe: &Path,
    cfg_path: &Path,
    bind: Option<&str>,
    log_file: &Path,
) -> Result<()> {
    let home = user_home_dir()?;
    let unit_dir = home.join(".config").join("systemd").join("user");
    let unit_path = unit_dir.join("service-manager.service");
    let unit = systemd_user_unit_contents(exe, cfg_path, bind, log_file);
    write_text_file(&unit_path, &unit)?;

    run_cmd("systemctl", &["--user", "daemon-reload"])?;
    run_cmd(
        "systemctl",
        &["--user", "enable", "--now", "service-manager.service"],
    )?;
    // Kick again in case the unit was already enabled but stopped.
    let _ = run_cmd("systemctl", &["--user", "start", "service-manager.service"]);
    Ok(())
}

#[cfg(all(unix, not(target_os = "macos")))]
fn uninstall_systemd_user() -> Result<()> {
    // Best-effort stop/disable; ignore failures for missing/offline systemd.
    let _ = run_cmd(
        "systemctl",
        &["--user", "disable", "--now", "service-manager.service"],
    );
    let home = user_home_dir()?;
    let unit_path = home
        .join(".config")
        .join("systemd")
        .join("user")
        .join("service-manager.service");
    let _ = fs::remove_file(&unit_path);
    let _ = run_cmd("systemctl", &["--user", "daemon-reload"]);
    Ok(())
}

#[cfg(all(unix, not(target_os = "macos")))]
fn systemd_user_unit_contents(
    exe: &Path,
    cfg_path: &Path,
    bind: Option<&str>,
    log_file: &Path,
) -> String {
    let args = service_args(exe, cfg_path, bind, log_file);
    let exec = args
        .iter()
        .map(|a| systemd_escape_arg(a))
        .collect::<Vec<_>>()
        .join(" ");
    format!(
        "[Unit]\n\
Description=service-manager (local-only service manager)\n\
\n\
[Service]\n\
Type=simple\n\
ExecStart={exec}\n\
Restart=on-failure\n\
RestartSec=3\n\
\n\
[Install]\n\
WantedBy=default.target\n"
    )
}

#[cfg(target_os = "macos")]
fn install_launchd_user(
    exe: &Path,
    cfg_path: &Path,
    bind: Option<&str>,
    log_file: &Path,
) -> Result<()> {
    let home = user_home_dir()?;
    let agents_dir = home.join("Library").join("LaunchAgents");
    let plist_path = agents_dir.join("com.service-manager.plist");
    let plist = launchd_agent_plist_contents(exe, cfg_path, bind, log_file);
    write_text_file(&plist_path, &plist)?;

    let uid = unsafe { libc::geteuid() };
    let domain = format!("gui/{uid}");
    let plist_str = plist_path.to_string_lossy().to_string();

    // bootstrap can error if already loaded; treat that as idempotent.
    match Command::new("launchctl")
        .args(["bootstrap", &domain, &plist_str])
        .output()
    {
        Ok(out) if out.status.success() => {}
        Ok(out) => {
            let stderr = String::from_utf8_lossy(&out.stderr).to_lowercase();
            if !stderr.contains("already") {
                return Err(AppError::BadRequest(format!(
                    "launchctl bootstrap failed: {}",
                    String::from_utf8_lossy(&out.stderr).trim()
                )));
            }
        }
        Err(e) if e.kind() == io::ErrorKind::NotFound => {
            return Err(AppError::BadRequest(
                "launchctl not found in PATH".to_string(),
            ));
        }
        Err(e) => return Err(AppError::Io(e)),
    }

    let target = format!("{domain}/com.service-manager");
    let _ = Command::new("launchctl")
        .args(["kickstart", "-k", &target])
        .output();
    Ok(())
}

#[cfg(target_os = "macos")]
fn uninstall_launchd_user() -> Result<()> {
    let home = user_home_dir()?;
    let plist_path = home
        .join("Library")
        .join("LaunchAgents")
        .join("com.service-manager.plist");
    let uid = unsafe { libc::geteuid() };
    let domain = format!("gui/{uid}");
    let plist_str = plist_path.to_string_lossy().to_string();

    let _ = Command::new("launchctl")
        .args(["bootout", &domain, &plist_str])
        .output();
    let _ = fs::remove_file(&plist_path);
    Ok(())
}

#[cfg(target_os = "macos")]
fn launchd_agent_plist_contents(
    exe: &Path,
    cfg_path: &Path,
    bind: Option<&str>,
    log_file: &Path,
) -> String {
    let args = service_args(exe, cfg_path, bind, log_file);
    let args_xml = args
        .iter()
        .map(|a| format!("      <string>{}</string>\n", xml_escape(a)))
        .collect::<String>();
    format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n\
<plist version=\"1.0\">\n\
  <dict>\n\
    <key>Label</key>\n\
    <string>com.service-manager</string>\n\
    <key>ProgramArguments</key>\n\
    <array>\n\
{args_xml}    </array>\n\
    <key>RunAtLoad</key>\n\
    <true/>\n\
    <key>KeepAlive</key>\n\
    <true/>\n\
  </dict>\n\
</plist>\n"
    )
}

#[cfg(target_os = "macos")]
fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

fn user_home_dir() -> Result<PathBuf> {
    #[cfg(target_os = "windows")]
    {
        if let Some(v) = env::var_os("USERPROFILE") {
            return Ok(PathBuf::from(v));
        }
        return Err(AppError::BadRequest(
            "cannot determine home dir".to_string(),
        ));
    }

    #[cfg(not(target_os = "windows"))]
    {
        let home =
            env::var_os("HOME").ok_or_else(|| AppError::BadRequest("HOME not set".to_string()))?;
        Ok(PathBuf::from(home))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct StaticStatusProvider {
        state: ServiceState,
    }

    #[async_trait::async_trait]
    impl Provider for StaticStatusProvider {
        fn id(&self) -> ProviderId {
            ProviderId::new("static-status")
        }

        fn display_name(&self) -> String {
            "Static status".to_string()
        }

        fn description(&self) -> String {
            "Test provider with a fixed status".to_string()
        }

        fn capabilities(&self) -> Vec<Capability> {
            vec![Capability::Status]
        }

        async fn detect(&self) -> Result<DetectResult> {
            Ok(DetectResult {
                detected: true,
                details: String::new(),
            })
        }

        async fn register(&self, _svc: &Service) -> Result<()> {
            Ok(())
        }

        async fn unregister(&self, _svc: &Service) -> Result<()> {
            Ok(())
        }

        async fn start(&self, _svc: &Service) -> Result<()> {
            Ok(())
        }

        async fn stop(&self, _svc: &Service) -> Result<()> {
            Ok(())
        }

        async fn restart(&self, _svc: &Service) -> Result<()> {
            Ok(())
        }

        async fn status(&self, svc: &Service) -> Result<ServiceStatus> {
            Ok(ServiceStatus {
                service_id: svc.id.clone(),
                state: self.state,
                message: String::new(),
                provider: svc.spec.provider.clone(),
                observed_at: Utc::now(),
                started_at: None,
                pid: None,
                exit_code: None,
            })
        }

        async fn logs(
            &self,
            _svc: &Service,
            _opts: LogsOptions,
        ) -> Result<Vec<crate::model::LogEntry>> {
            Ok(Vec::new())
        }
    }

    struct BlockingStopProvider {
        entered: Arc<Notify>,
        release: Arc<Notify>,
    }

    #[async_trait::async_trait]
    impl Provider for BlockingStopProvider {
        fn id(&self) -> ProviderId {
            ProviderId::new("blocking-stop")
        }

        fn display_name(&self) -> String {
            "Blocking stop".to_string()
        }

        fn description(&self) -> String {
            "Test provider whose stop waits for a gate".to_string()
        }

        fn capabilities(&self) -> Vec<Capability> {
            vec![
                Capability::Register,
                Capability::Unregister,
                Capability::Start,
                Capability::Stop,
                Capability::Restart,
                Capability::Status,
                Capability::Logs,
            ]
        }

        async fn detect(&self) -> Result<DetectResult> {
            Ok(DetectResult {
                detected: true,
                details: String::new(),
            })
        }

        async fn register(&self, _svc: &Service) -> Result<()> {
            Ok(())
        }

        async fn unregister(&self, _svc: &Service) -> Result<()> {
            Ok(())
        }

        async fn start(&self, _svc: &Service) -> Result<()> {
            Ok(())
        }

        async fn stop(&self, _svc: &Service) -> Result<()> {
            self.entered.notify_one();
            self.release.notified().await;
            Ok(())
        }

        async fn restart(&self, svc: &Service) -> Result<()> {
            self.stop(svc).await
        }

        async fn status(&self, svc: &Service) -> Result<ServiceStatus> {
            Ok(ServiceStatus {
                service_id: svc.id.clone(),
                state: ServiceState::Running,
                message: String::new(),
                provider: svc.spec.provider.clone(),
                observed_at: Utc::now(),
                started_at: None,
                pid: None,
                exit_code: None,
            })
        }

        async fn logs(
            &self,
            _svc: &Service,
            _opts: LogsOptions,
        ) -> Result<Vec<crate::model::LogEntry>> {
            Ok(Vec::new())
        }
    }

    fn dynamic_port_test_engine(state: ServiceState) -> Engine {
        use std::time::{SystemTime, UNIX_EPOCH};

        let base = std::env::temp_dir().join(format!(
            "service-manager-server-test-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&base).unwrap();
        let store = Arc::new(JsonStore::open(base.join("store.json")).unwrap());
        let registry = ProviderRegistry::new();
        registry
            .add(Arc::new(StaticStatusProvider { state }))
            .unwrap();
        let ports = Arc::new(PortManager::open(base.join("ports.json"), vec![]).unwrap());
        Engine::new(store, registry, ports)
    }

    #[tokio::test]
    async fn runtime_endpoint_snapshot_starts_empty_and_does_not_copy_unverified_port_state() {
        use crate::runtime_endpoints::{
            RuntimeEndpointSnapshot, RuntimeEndpointSnapshotPublisher, RuntimeEndpointSnapshotState,
        };
        use std::time::{SystemTime, UNIX_EPOCH};

        let base = std::env::temp_dir().join(format!(
            "service-manager-runtime-snapshot-test-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&base).unwrap();
        let store = Arc::new(JsonStore::open(base.join("store.json")).unwrap());
        let registry = ProviderRegistry::new();
        let stale_key = "stale-service\u{0}web";
        let now = Utc::now();
        fs::write(
            base.join("ports.json"),
            serde_json::to_vec(&serde_json::json!({
                "version": 2,
                "generation": 2,
                "leases": {
                    stale_key: {
                        "serviceId": "stale-service",
                        "portName": "web",
                        "host": "127.0.0.1",
                        "preferredPort": 30141,
                        "allocatedPort": 30141,
                        "dynamic": true,
                        "pool": "local-web",
                        "protocol": "tcp",
                        "envVar": "PORT",
                        "endpoint": {"scheme": "http", "path": "/"},
                        "conflict": null,
                        "lifecycle": "published",
                        "orphanReason": null,
                        "generation": 2,
                        "allocatedAt": now
                    }
                },
                "endpoints": {
                    stale_key: {
                        "serviceId": "stale-service",
                        "name": "web",
                        "host": "127.0.0.1",
                        "port": 30141,
                        "protocol": "tcp",
                        "url": "http://127.0.0.1:30141/",
                        "generation": 2,
                        "publishedAt": now
                    }
                },
                "orphans": {}
            }))
            .unwrap(),
        )
        .unwrap();
        let ports = Arc::new(PortManager::open(base.join("ports.json"), vec![]).unwrap());
        assert_eq!(ports.list_endpoints().len(), 1);

        let snapshot_path = base.join("openhouseai/runtime/endpoints.json");
        let publisher = Arc::new(
            RuntimeEndpointSnapshotPublisher::new(&snapshot_path, "manager-test").unwrap(),
        );
        let engine = Engine::new_with_runtime_endpoint_snapshot(
            store,
            registry,
            ports,
            PathBuf::from("/proc"),
            publisher,
        );

        engine.initialize_runtime_endpoint_snapshot();
        let initializing: RuntimeEndpointSnapshot =
            serde_json::from_slice(&fs::read(&snapshot_path).unwrap()).unwrap();
        assert_eq!(
            initializing.state,
            RuntimeEndpointSnapshotState::Initializing
        );
        assert!(initializing.endpoints.is_empty());

        engine.refresh_runtime_endpoint_snapshot_once().await;
        let ready: RuntimeEndpointSnapshot =
            serde_json::from_slice(&fs::read(&snapshot_path).unwrap()).unwrap();
        assert_eq!(ready.state, RuntimeEndpointSnapshotState::Ready);
        assert_eq!(ready.snapshot_revision, 2);
        assert!(
            ready.endpoints.is_empty(),
            "persisted ports.json endpoints must not bypass this manager instance's verification"
        );
        assert_eq!(ready.port_state_generation, engine.ports.generation());
        let _ = fs::remove_dir_all(base);
    }

    #[tokio::test]
    async fn no_op_port_mutations_do_not_notify_runtime_snapshot_writer() {
        use crate::runtime_endpoints::RuntimeEndpointSnapshotPublisher;
        use std::time::{SystemTime, UNIX_EPOCH};

        let base = std::env::temp_dir().join(format!(
            "service-manager-runtime-notify-test-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&base).unwrap();
        let store = Arc::new(JsonStore::open(base.join("store.json")).unwrap());
        let registry = ProviderRegistry::new();
        let ports = Arc::new(PortManager::open(base.join("ports.json"), vec![]).unwrap());
        let publisher = Arc::new(
            RuntimeEndpointSnapshotPublisher::new(
                base.join("openhouseai/runtime/endpoints.json"),
                "manager-test",
            )
            .unwrap(),
        );
        let engine = Engine::new_with_runtime_endpoint_snapshot(
            store,
            registry,
            ports,
            PathBuf::from("/proc"),
            publisher,
        );
        let service_id = ServiceId::new("runtime-notify-test");
        let specs = dynamic_port_test_spec().ports;

        engine.allocate_ports(&service_id, &specs).unwrap();
        engine.runtime_endpoint_notify.notified().await;
        engine.allocate_ports(&service_id, &specs).unwrap();
        assert!(
            tokio::time::timeout(
                Duration::from_millis(25),
                engine.runtime_endpoint_notify.notified()
            )
            .await
            .is_err()
        );

        engine.publish_ports(&service_id).unwrap();
        engine.runtime_endpoint_notify.notified().await;
        engine.publish_ports(&service_id).unwrap();
        assert!(
            tokio::time::timeout(
                Duration::from_millis(25),
                engine.runtime_endpoint_notify.notified()
            )
            .await
            .is_err()
        );

        engine.unpublish_ports(&service_id).unwrap();
        engine.runtime_endpoint_notify.notified().await;
        engine.unpublish_ports(&service_id).unwrap();
        assert!(
            tokio::time::timeout(
                Duration::from_millis(25),
                engine.runtime_endpoint_notify.notified()
            )
            .await
            .is_err()
        );

        engine.release_ports(&service_id).unwrap();
        engine.runtime_endpoint_notify.notified().await;
        engine.release_ports(&service_id).unwrap();
        engine
            .mark_ports_orphan(&service_id, "already released")
            .unwrap();
        assert!(
            tokio::time::timeout(
                Duration::from_millis(25),
                engine.runtime_endpoint_notify.notified()
            )
            .await
            .is_err()
        );

        let _ = fs::remove_dir_all(base);
    }

    #[tokio::test]
    async fn stop_removes_published_endpoint_before_provider_stop_finishes() {
        use crate::runtime_endpoints::RuntimeEndpointSnapshotPublisher;
        use std::time::{SystemTime, UNIX_EPOCH};

        let base = std::env::temp_dir().join(format!(
            "service-manager-stop-publication-test-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&base).unwrap();
        let service_id = ServiceId::new("blocking-stop-service");
        let now = Utc::now();
        let key = "blocking-stop-service\u{0}web";
        fs::write(
            base.join("ports.json"),
            serde_json::to_vec(&serde_json::json!({
                "version": 2,
                "generation": 2,
                "leases": {
                    key: {
                        "serviceId": service_id,
                        "portName": "web",
                        "host": "127.0.0.1",
                        "preferredPort": 30142,
                        "allocatedPort": 30142,
                        "dynamic": true,
                        "pool": "local-web",
                        "protocol": "tcp",
                        "envVar": "PORT",
                        "endpoint": {"scheme": "http", "path": "/"},
                        "conflict": null,
                        "lifecycle": "published",
                        "orphanReason": null,
                        "generation": 2,
                        "allocatedAt": now
                    }
                },
                "endpoints": {
                    key: {
                        "serviceId": service_id,
                        "name": "web",
                        "host": "127.0.0.1",
                        "port": 30142,
                        "protocol": "tcp",
                        "url": "http://127.0.0.1:30142/",
                        "generation": 2,
                        "publishedAt": now
                    }
                },
                "orphans": {}
            }))
            .unwrap(),
        )
        .unwrap();
        let store = Arc::new(JsonStore::open(base.join("store.json")).unwrap());
        let spec: ServiceSpec = serde_json::from_value(serde_json::json!({
            "name": "blocking-stop-service",
            "provider": "blocking-stop",
            "command": ["true"],
            "ports": [{
                "name": "web",
                "preferred": 30142,
                "dynamic": true,
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }]
        }))
        .unwrap();
        store
            .create_service(Service {
                id: service_id.clone(),
                spec,
                created_at: now,
                updated_at: now,
                deleted_at: None,
            })
            .unwrap();
        let entered = Arc::new(Notify::new());
        let release = Arc::new(Notify::new());
        let registry = ProviderRegistry::new();
        registry
            .add(Arc::new(BlockingStopProvider {
                entered: Arc::clone(&entered),
                release: Arc::clone(&release),
            }))
            .unwrap();
        let ports = Arc::new(PortManager::open(base.join("ports.json"), vec![]).unwrap());
        let publisher = Arc::new(
            RuntimeEndpointSnapshotPublisher::new(
                base.join("runtime/endpoints.json"),
                "manager-test",
            )
            .unwrap(),
        );
        let engine = Arc::new(Engine::new_with_runtime_endpoint_snapshot(
            store,
            registry,
            ports,
            PathBuf::from("/proc"),
            publisher,
        ));
        let task_engine = Arc::clone(&engine);
        let task = tokio::spawn(async move { task_engine.stop(&service_id).await });
        tokio::time::timeout(Duration::from_secs(1), entered.notified())
            .await
            .unwrap();
        assert!(engine.ports.list_endpoints().is_empty());
        release.notify_one();
        task.await.unwrap().unwrap();
        let _ = fs::remove_dir_all(base);
    }

    #[test]
    fn runtime_endpoint_snapshot_path_is_derived_from_openhouse_registry_source() {
        let mut config = default_config().unwrap();
        config.openhouse_registry_source_dir = "/tmp/openhouse-registry-source".to_string();
        assert_eq!(
            runtime_endpoint_snapshot_path(&config),
            PathBuf::from("/tmp/openhouse-registry-source/runtime/endpoints.json")
        );
    }

    #[test]
    fn logging_path_is_derived_when_data_dir_changes() {
        let mut config = default_config().unwrap();
        let file: ConfigFile = serde_json::from_value(serde_json::json!({
            "data_dir": "/tmp/service-manager-custom-data"
        }))
        .unwrap();
        file.apply(&mut config);
        apply_defaults(&mut config).unwrap();

        assert_eq!(
            config.logging.path,
            "/tmp/service-manager-custom-data/logs/service-manager.log"
        );
        assert_eq!(config.logging.max_bytes, logging::DEFAULT_MAX_BYTES);
        assert_eq!(config.logging.retain_files, logging::DEFAULT_RETAIN_FILES);
    }

    #[test]
    fn explicit_logging_config_is_preserved() {
        let mut config = default_config().unwrap();
        let file: ConfigFile = serde_json::from_value(serde_json::json!({
            "data_dir": "/tmp/service-manager-custom-data",
            "logging": {
                "path": "/tmp/openhouse/service-manager.log",
                "max_bytes": 4096,
                "retain_files": 1
            }
        }))
        .unwrap();
        file.apply(&mut config);
        apply_defaults(&mut config).unwrap();

        assert_eq!(config.logging.path, "/tmp/openhouse/service-manager.log");
        assert_eq!(config.logging.max_bytes, 4096);
        assert_eq!(config.logging.retain_files, 1);
    }

    fn dynamic_port_test_spec() -> ServiceSpec {
        serde_json::from_value(serde_json::json!({
            "name": "dynamic-status-test",
            "provider": "static-status",
            "command": ["demo", "--port={{port:web}}"],
            "health": [{
                "type": "http",
                "url": "http://127.0.0.1:{{port:web}}/health"
            }],
            "ports": [{
                "name": "web",
                "preferred": 30141,
                "dynamic": true,
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }]
        }))
        .unwrap()
    }

    #[tokio::test]
    async fn shutdown_deadline_drops_a_stuck_server_future() {
        use std::sync::atomic::{AtomicBool, Ordering};

        struct DropFlag(Arc<AtomicBool>);
        impl Drop for DropFlag {
            fn drop(&mut self) {
                self.0.store(true, Ordering::SeqCst);
            }
        }

        let dropped = Arc::new(AtomicBool::new(false));
        let server_dropped = dropped.clone();
        let server = async move {
            let _drop_flag = DropFlag(server_dropped);
            std::future::pending::<std::result::Result<(), ()>>().await
        };
        let graceful_triggered = Arc::new(AtomicBool::new(false));
        let trigger_flag = graceful_triggered.clone();
        let (signal_tx, signal_rx) = tokio::sync::mpsc::unbounded_channel();
        signal_tx.send(()).unwrap();
        let outcome = run_server_with_shutdown_escalation(
            server,
            signal_rx,
            move || trigger_flag.store(true, Ordering::SeqCst),
            Duration::from_millis(10),
        )
        .await
        .unwrap();

        assert_eq!(outcome, ServerShutdownOutcome::DeadlineExceeded);
        assert_eq!(
            shutdown_disposition(outcome),
            ShutdownDisposition::ExitProcess
        );
        assert!(graceful_triggered.load(Ordering::SeqCst));
        assert!(dropped.load(Ordering::SeqCst));
    }

    #[tokio::test]
    async fn second_shutdown_signal_escalates_before_deadline() {
        let (signal_tx, signal_rx) = tokio::sync::mpsc::unbounded_channel();
        signal_tx.send(()).unwrap();
        signal_tx.send(()).unwrap();
        let outcome = run_server_with_shutdown_escalation(
            std::future::pending::<std::result::Result<(), ()>>(),
            signal_rx,
            || {},
            Duration::from_secs(5),
        )
        .await
        .unwrap();

        assert_eq!(outcome, ServerShutdownOutcome::SecondSignal);
        assert_eq!(
            shutdown_disposition(outcome),
            ShutdownDisposition::ExitProcess
        );
    }

    #[tokio::test]
    async fn server_can_finish_during_grace_period() {
        let (grace_tx, grace_rx) = tokio::sync::oneshot::channel();
        let server = async move {
            let _ = grace_rx.await;
            Ok::<(), ()>(())
        };
        let (signal_tx, signal_rx) = tokio::sync::mpsc::unbounded_channel();
        signal_tx.send(()).unwrap();
        let outcome = run_server_with_shutdown_escalation(
            server,
            signal_rx,
            move || {
                let _ = grace_tx.send(());
            },
            Duration::from_secs(5),
        )
        .await
        .unwrap();

        assert_eq!(outcome, ServerShutdownOutcome::Graceful);
        assert_eq!(
            shutdown_disposition(outcome),
            ShutdownDisposition::ExitProcess
        );
    }

    #[tokio::test]
    async fn naturally_completed_server_returns_without_process_exit() {
        let (_signal_tx, signal_rx) = tokio::sync::mpsc::unbounded_channel();
        let outcome = run_server_with_shutdown_escalation(
            async { Ok::<(), ()>(()) },
            signal_rx,
            || panic!("natural completion must not trigger graceful shutdown"),
            Duration::from_secs(5),
        )
        .await
        .unwrap();

        assert_eq!(outcome, ServerShutdownOutcome::Completed);
        assert_eq!(shutdown_disposition(outcome), ShutdownDisposition::Return);
    }

    #[cfg(any(target_os = "linux", target_os = "android"))]
    #[test]
    fn socket_matching_checks_protocol_host_and_port() {
        let lease = PortLease {
            service_id: ServiceId::new("demo"),
            port_name: "web".to_string(),
            host: "127.0.0.1".to_string(),
            preferred_port: 30141,
            allocated_port: 30142,
            dynamic: true,
            pool: "local-web".to_string(),
            protocol: crate::model::ServicePortProtocol::Tcp,
            env_var: "PORT".to_string(),
            endpoint: None,
            conflict: None,
            lifecycle: crate::model::PortLeaseLifecycle::Leased,
            orphan_reason: None,
            generation: 1,
            allocated_at: Utc::now(),
        };
        let good = ManagedSocket {
            address: "127.0.0.1".parse().unwrap(),
            port: 30142,
            socket_type: libc::SOCK_STREAM,
            accepting: true,
        };
        assert!(socket_matches_lease(&good, &lease));
        assert!(!socket_matches_lease(
            &ManagedSocket {
                port: 30143,
                ..good
            },
            &lease
        ));
        assert!(!socket_matches_lease(
            &ManagedSocket {
                address: "127.0.0.2".parse().unwrap(),
                ..good
            },
            &lease
        ));
        assert!(!socket_matches_lease(
            &ManagedSocket {
                socket_type: libc::SOCK_DGRAM,
                accepting: false,
                ..good
            },
            &lease
        ));
    }

    fn valid_android_fallback_context() -> EndpointOwnershipFallbackContext {
        EndpointOwnershipFallbackContext {
            platform: EndpointOwnershipPlatform::Android,
            state: ServiceState::Running,
            pid: Some(4242),
            provider_identity_verified: true,
            leases_currently_managed: true,
            health_checks_passed: true,
        }
    }

    fn fallback_test_lease(
        lifecycle: crate::model::PortLeaseLifecycle,
        orphan_reason: Option<&str>,
    ) -> PortLease {
        PortLease {
            service_id: ServiceId::new("aionui-web"),
            port_name: "web".to_string(),
            host: "127.0.0.1".to_string(),
            preferred_port: 25808,
            allocated_port: 25808,
            dynamic: true,
            pool: "local-web".to_string(),
            protocol: crate::model::ServicePortProtocol::Tcp,
            env_var: "PORT".to_string(),
            endpoint: Some(crate::model::ServiceEndpointSpec {
                scheme: "http".to_string(),
                path: "/".to_string(),
            }),
            conflict: None,
            lifecycle,
            orphan_reason: orphan_reason.map(str::to_string),
            generation: 1,
            allocated_at: Utc::now(),
        }
    }

    #[test]
    fn published_manager_lease_allows_android_background_revalidation_fallback() {
        let leases = vec![fallback_test_lease(
            crate::model::PortLeaseLifecycle::Published,
            None,
        )];
        let managed =
            leases_are_current_manager_allocations(&ServiceId::new("aionui-web"), &leases, &leases);
        assert!(managed);

        let failure = EndpointOwnershipFailure::IntrospectionUnavailable {
            operation: EndpointOwnershipIntrospectionOperation::PidfdGetfd,
            reason: EndpointOwnershipUnavailableReason::SyscallMissing,
            errno: libc::ENOSYS,
        };
        let mut context = valid_android_fallback_context();
        context.leases_currently_managed = managed;
        assert!(android_constrained_fallback_allowed(&failure, context));
    }

    #[test]
    fn current_manager_lease_policy_rejects_orphaned_or_reason_marked_leases() {
        let leased = vec![fallback_test_lease(
            crate::model::PortLeaseLifecycle::Leased,
            None,
        )];
        assert!(leases_are_current_manager_allocations(
            &ServiceId::new("aionui-web"),
            &leased,
            &leased,
        ));

        let orphaned = vec![fallback_test_lease(
            crate::model::PortLeaseLifecycle::Orphaned,
            Some("owner lost"),
        )];
        assert!(!leases_are_current_manager_allocations(
            &ServiceId::new("aionui-web"),
            &orphaned,
            &orphaned,
        ));

        let reason_marked = vec![fallback_test_lease(
            crate::model::PortLeaseLifecycle::Published,
            Some("stale owner evidence"),
        )];
        assert!(!leases_are_current_manager_allocations(
            &ServiceId::new("aionui-web"),
            &reason_marked,
            &reason_marked,
        ));
    }

    #[test]
    fn android_fallback_allows_pidfd_enosys_when_all_constraints_pass() {
        let failure = classify_endpoint_introspection_error(
            EndpointOwnershipIntrospectionOperation::PidfdGetfd,
            &io::Error::from_raw_os_error(libc::ENOSYS),
        )
        .unwrap();

        assert!(android_constrained_fallback_allowed(
            &failure,
            valid_android_fallback_context()
        ));
        let mut strict = valid_android_fallback_context();
        strict.platform = EndpointOwnershipPlatform::Strict;
        assert!(!android_constrained_fallback_allowed(&failure, strict));
    }

    #[test]
    fn permission_fallback_is_android_only_and_requires_constrained_introspection_operation() {
        for errno in [libc::EPERM, libc::EACCES] {
            let failure = classify_endpoint_introspection_error(
                EndpointOwnershipIntrospectionOperation::PidfdGetfd,
                &io::Error::from_raw_os_error(errno),
            )
            .unwrap();
            assert!(android_constrained_fallback_allowed(
                &failure,
                valid_android_fallback_context()
            ));

            let mut strict = valid_android_fallback_context();
            strict.platform = EndpointOwnershipPlatform::Strict;
            assert!(!android_constrained_fallback_allowed(&failure, strict));
        }
    }

    #[test]
    fn android_fallback_rejects_explicit_socket_mismatch() {
        let failure = EndpointOwnershipFailure::SocketMismatch(
            "managed process group has no matching listener".to_string(),
        );

        assert!(!android_constrained_fallback_allowed(
            &failure,
            valid_android_fallback_context()
        ));
    }

    #[test]
    fn android_fallback_rejects_missing_pid() {
        let failure = EndpointOwnershipFailure::IntrospectionUnavailable {
            operation: EndpointOwnershipIntrospectionOperation::PidfdOpen,
            reason: EndpointOwnershipUnavailableReason::SyscallMissing,
            errno: libc::ENOSYS,
        };
        let mut context = valid_android_fallback_context();
        context.pid = None;

        assert!(!android_constrained_fallback_allowed(&failure, context));
    }

    #[test]
    fn android_fallback_rejects_non_running_provider_status() {
        let failure = EndpointOwnershipFailure::IntrospectionUnavailable {
            operation: EndpointOwnershipIntrospectionOperation::PidfdGetfd,
            reason: EndpointOwnershipUnavailableReason::PermissionDenied,
            errno: libc::EACCES,
        };
        let mut context = valid_android_fallback_context();
        context.state = ServiceState::Starting;

        assert!(!android_constrained_fallback_allowed(&failure, context));
    }

    #[test]
    fn android_fallback_requires_verified_identity_current_lease_and_completed_health() {
        let failure = EndpointOwnershipFailure::IntrospectionUnavailable {
            operation: EndpointOwnershipIntrospectionOperation::PidfdGetfd,
            reason: EndpointOwnershipUnavailableReason::SyscallMissing,
            errno: libc::ENOSYS,
        };

        let mut context = valid_android_fallback_context();
        context.provider_identity_verified = false;
        assert!(!android_constrained_fallback_allowed(&failure, context));

        let mut context = valid_android_fallback_context();
        context.leases_currently_managed = false;
        assert!(!android_constrained_fallback_allowed(&failure, context));

        let mut context = valid_android_fallback_context();
        context.health_checks_passed = false;
        assert!(!android_constrained_fallback_allowed(&failure, context));
    }

    #[test]
    fn materializes_allocated_ports_in_command_env_and_health() {
        let spec: ServiceSpec = serde_json::from_value(serde_json::json!({
            "name": "demo",
            "provider": "process",
            "command": ["demo", "--port={{port:web}}"],
            "env": {"PUBLIC_URL": "http://127.0.0.1:{{port:web}}"},
            "health": [{
                "type": "http",
                "url": "http://127.0.0.1:{{port:web}}/health"
            }],
            "ports": [{
                "name": "web",
                "preferred": 30141,
                "dynamic": true,
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }]
        }))
        .unwrap();
        let service = Service {
            id: ServiceId::new("demo"),
            spec,
            created_at: Utc::now(),
            updated_at: Utc::now(),
            deleted_at: None,
        };
        let declaration = &service.spec.ports[0];
        let lease = PortLease {
            service_id: service.id.clone(),
            port_name: declaration.name.clone(),
            host: declaration.host.clone(),
            preferred_port: declaration.preferred,
            allocated_port: 30142,
            dynamic: declaration.dynamic,
            pool: declaration.pool.clone(),
            protocol: declaration.protocol,
            env_var: declaration.env_var.clone(),
            endpoint: declaration.endpoint.clone(),
            conflict: None,
            lifecycle: crate::model::PortLeaseLifecycle::Leased,
            orphan_reason: None,
            generation: 1,
            allocated_at: Utc::now(),
        };

        let runtime = materialize_service(&service, &[lease]).unwrap();
        assert_eq!(runtime.spec.command[1], "--port=30142");
        assert_eq!(runtime.spec.env["PORT"], "30142");
        assert_eq!(runtime.spec.env["SERVICE_MANAGER_PORT_WEB"], "30142");
        assert_eq!(runtime.spec.env["PUBLIC_URL"], "http://127.0.0.1:30142");
        assert_eq!(runtime.spec.health[0].url, "http://127.0.0.1:30142/health");
    }

    #[tokio::test]
    async fn stopped_dynamic_service_without_leases_reports_status_and_empty_endpoints() {
        let engine = dynamic_port_test_engine(ServiceState::Stopped);
        let service = engine
            .create_service(dynamic_port_test_spec())
            .await
            .unwrap();

        let status = engine.status(&service.id).await.unwrap();
        assert_eq!(status.state, ServiceState::Stopped);

        let endpoints = engine.endpoints(&service.id).await.unwrap();
        assert_eq!(endpoints.status, EndpointAvailability::Stopped);
        assert!(endpoints.endpoints.is_empty());
    }

    #[tokio::test]
    async fn stopping_stopped_dynamic_service_without_leases_is_idempotent() {
        let engine = dynamic_port_test_engine(ServiceState::Stopped);
        let service = engine
            .create_service(dynamic_port_test_spec())
            .await
            .unwrap();

        engine.stop(&service.id).await.unwrap();

        let status = engine.status(&service.id).await.unwrap();
        assert_eq!(status.state, ServiceState::Stopped);
        assert!(engine.ports.leases(&service.id).unwrap().is_empty());
    }

    #[tokio::test]
    async fn stop_api_returns_no_content_for_stopped_dynamic_service_without_leases() {
        use axum::{
            body::Body,
            http::{Request, StatusCode, header::AUTHORIZATION},
        };
        use tower::ServiceExt;

        let engine = Arc::new(dynamic_port_test_engine(ServiceState::Stopped));
        let service = engine
            .create_service(dynamic_port_test_spec())
            .await
            .unwrap();
        let token = "stopped-dynamic-test-token";
        let app = api::router(AppState {
            config: Config {
                listen_addr: "127.0.0.1:0".to_string(),
                data_dir: String::new(),
                service_registry_dir: String::new(),
                openhouse_registry_source_dir: String::new(),
                openhouse_registry_target_dir: String::new(),
                auth_token: token.to_string(),
                log_level: "info".to_string(),
                logging: LoggingConfig::default(),
                store: StoreConfig::default(),
                port_pools: Vec::new(),
                port_state_path: String::new(),
            },
            engine: engine.clone(),
        });

        let response = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{}/stop", service.id))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();

        assert_eq!(response.status(), StatusCode::NO_CONTENT);
        assert_eq!(
            engine.status(&service.id).await.unwrap().state,
            ServiceState::Stopped
        );
    }

    #[tokio::test]
    async fn running_dynamic_service_without_leases_still_requires_materialization() {
        let engine = dynamic_port_test_engine(ServiceState::Running);
        let service = engine
            .create_service(dynamic_port_test_spec())
            .await
            .unwrap();

        let error = engine.status(&service.id).await.unwrap_err();
        assert!(
            error
                .to_string()
                .contains("unresolved {port:name} template")
        );
    }

    #[cfg(all(unix, not(target_os = "macos")))]
    #[test]
    fn generates_systemd_user_unit() {
        let exe = Path::new("/opt/bin/service-manager");
        let cfg = Path::new("/home/alice/.config/service-manager/config.json");
        let log = Path::new("/home/alice/.local/state/service-manager/service-manager.log");
        let unit = systemd_user_unit_contents(exe, cfg, Some("127.0.0.1:9999"), log);
        assert!(unit.contains("WantedBy=default.target"));
        assert!(unit.contains("/opt/bin/service-manager"));
        assert!(unit.contains("serve"));
        assert!(unit.contains("--config"));
        assert!(unit.contains("/home/alice/.config/service-manager/config.json"));
        assert!(unit.contains("--bind"));
        assert!(unit.contains("127.0.0.1:9999"));
        assert!(unit.contains("--log-file"));
        assert!(unit.contains("/home/alice/.local/state/service-manager/service-manager.log"));
    }

    #[test]
    fn generates_termux_runit_script() {
        let args = vec![
            "/data/data/com.termux/files/usr/bin/service-manager".to_string(),
            "serve".to_string(),
            "--config".to_string(),
            "/data/data/com.termux/files/home/.config/service-manager/config.json".to_string(),
            "--log-file".to_string(),
            "/data/data/com.termux/files/home/.smallphoneai/logs/service-manager.log".to_string(),
        ];
        let script = termux_runit_run_script(&args);
        assert!(script.starts_with("#!/data/data/com.termux/files/usr/bin/sh\n"));
        assert!(script.contains("exec "));
        assert!(script.contains("serve"));
        assert!(script.contains("--config"));
        assert!(script.contains("--log-file"));
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn generates_launchd_plist() {
        let exe = Path::new("/usr/local/bin/service-manager");
        let cfg = Path::new("/Users/alice/Library/Application Support/service-manager/config.json");
        let log = Path::new("/Users/alice/Library/Logs/service-manager.log");
        let plist = launchd_agent_plist_contents(exe, cfg, None, log);
        assert!(plist.contains("<string>com.service-manager</string>"));
        assert!(plist.contains("/usr/local/bin/service-manager"));
        assert!(plist.contains("serve"));
        assert!(plist.contains("--config"));
        assert!(plist.contains("--log-file"));
    }
}
