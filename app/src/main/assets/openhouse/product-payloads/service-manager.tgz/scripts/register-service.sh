#!/data/data/com.termux/files/usr/bin/env bash
set -euo pipefail

openhouse_config="${HOME}/.config/openhouseai/service-manager/config.json"

if [[ -f "${openhouse_config}" ]]; then
  cat <<'EOF'
service-manager is the control plane for OpenHouse services.

The OpenHouse canonical config already exists. Every OpenHouse caller and the
daemon must use this same file so they share one listen address and token.

Next steps:
  - Run: service-manager serve --config "$HOME/.config/openhouseai/service-manager/config.json" --bind 127.0.0.1:20087
  - Retrieve a token: service-manager token show --config "$HOME/.config/openhouseai/service-manager/config.json"

Do not start a bare `service-manager serve` instance in this environment. That
uses the standalone default config and can create a second daemon with a
different token.
EOF
else
  cat <<'EOF'
service-manager is a local service control plane.

No OpenHouse canonical config was found, so the standalone default config is
appropriate. Other services can register themselves using its management token.

Next steps:
  - Run: service-manager serve --bind 127.0.0.1:20087
  - Retrieve a token: service-manager token show
EOF
fi
