#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

PI_AGENT_DIR="${PI_CODING_AGENT_DIR:-/root/.pi}"
export PATH="/root/.npm-global/bin:/root/.local/node/bin:/root/.local/bin:$PATH"

command -v node >/dev/null 2>&1 || die "node is missing"
node -e '
const [major, minor] = process.versions.node.split(".").map(Number);
process.exit(major > 22 || (major === 22 && minor >= 19) ? 0 : 1);
' >/dev/null 2>&1 || die "Node >= 22.19 is required. Found: $(node -v 2>/dev/null || printf unknown)"

command -v pi >/dev/null 2>&1 || die "pi CLI is missing"
PI_CODING_AGENT_DIR="$PI_AGENT_DIR" pi --help >/dev/null 2>&1 || die "pi CLI failed to start"

[ -x /root/.local/bin/openhouse-pi-agent-sentinel ] || die "openhouse-pi-agent-sentinel is missing"
[ -f "$PI_AGENT_DIR/extensions/multi-platform-search.ts" ] || die "$PI_AGENT_DIR/extensions/multi-platform-search.ts is missing"
[ -f "$PI_AGENT_DIR/agent/extensions/multi-platform-search.ts" ] || die "$PI_AGENT_DIR/agent/extensions/multi-platform-search.ts is missing"

log "ok: pi-agent runtime is installed"
