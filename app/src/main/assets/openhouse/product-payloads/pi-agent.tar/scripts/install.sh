#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

SCRIPT_DIR=$(CDPATH= cd "$(dirname "$0")" && pwd)
ROOT_DIR=$(CDPATH= cd "$SCRIPT_DIR/.." && pwd)
PI_AGENT_DIR="${PI_CODING_AGENT_DIR:-/root/.pi}"
GLOBAL_PREFIX="${NPM_CONFIG_PREFIX:-/root/.npm-global}"
LOCAL_BIN="/root/.local/bin"

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"
}

node_version_ok() {
  node -e '
const [major, minor] = process.versions.node.split(".").map(Number);
process.exit(major > 22 || (major === 22 && minor >= 19) ? 0 : 1);
' >/dev/null 2>&1
}

install_pi_cli() {
  mkdir -p "$GLOBAL_PREFIX/bin"
  npm config set prefix "$GLOBAL_PREFIX" >/dev/null
  npm config set registry "${NPM_REGISTRY:-https://registry.npmjs.org/}" >/dev/null

  set -- "$ROOT_DIR"/packages/*.tgz
  if [ "$#" -gt 0 ] && [ -f "$1" ]; then
    package_names=""
    for pkg in "$@"; do
      package_names="$package_names $(basename "$pkg")"
    done
    log "install: pi CLI from bundled npm packages:$package_names"
    npm install -g --ignore-scripts "$@"
  else
    version="${OPENHOUSE_PI_AGENT_VERSION:-0.80.3}"
    warn "Bundled pi package is missing; falling back to npm registry @earendil-works/pi-coding-agent@$version"
    npm install -g --ignore-scripts "@earendil-works/pi-coding-agent@$version"
  fi
}

sync_extensions() {
  mkdir -p "$PI_AGENT_DIR/extensions" "$PI_AGENT_DIR/agent/extensions"
  if [ -d "$ROOT_DIR/extensions" ]; then
    for file in "$ROOT_DIR/extensions"/*.ts "$ROOT_DIR/extensions"/*.js; do
      [ -f "$file" ] || continue
      cp "$file" "$PI_AGENT_DIR/extensions/$(basename "$file")"
      cp "$file" "$PI_AGENT_DIR/agent/extensions/$(basename "$file")"
    done
  fi
}

install_wrappers() {
  mkdir -p "$LOCAL_BIN"
  install -m 755 "$ROOT_DIR/bin/openhouse-pi-agent-sentinel" "$LOCAL_BIN/openhouse-pi-agent-sentinel"
}

main() {
  require_cmd node
  require_cmd npm
  node_version_ok || die "Node >= 22.19 is required for pi. Found: $(node -v 2>/dev/null || printf unknown)"

  mkdir -p "$PI_AGENT_DIR" "$PI_AGENT_DIR/extensions" "$PI_AGENT_DIR/agent/extensions" "$HOME/workspace"
  install_pi_cli
  sync_extensions
  install_wrappers

  export PATH="$GLOBAL_PREFIX/bin:/root/.local/node/bin:$LOCAL_BIN:$PATH"
  command -v pi >/dev/null 2>&1 || die "pi CLI was not installed into PATH"
  PI_CODING_AGENT_DIR="$PI_AGENT_DIR" pi --help >/dev/null 2>&1 || die "pi CLI health check failed"
  log "done: pi CLI installed; PI_CODING_AGENT_DIR=$PI_AGENT_DIR"
}

main "$@"
