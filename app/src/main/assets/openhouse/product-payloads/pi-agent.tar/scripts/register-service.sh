#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }

SERVICE_NAME="pi-agent"
SM_URL="${SERVICE_MANAGER_URL:-${SMALLPHONE_SERVICE_MANAGER_URL:-http://127.0.0.1:20087}}"
CONFIG_DIR="${OPENHOUSEAI_CONFIG_DIR:-$HOME/.config/openhouseai}"
SERVICE_DIR="$CONFIG_DIR/service-manager/services.d"
SPEC_PATH="$SERVICE_DIR/$SERVICE_NAME.json"

have() { command -v "$1" >/dev/null 2>&1; }

json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

resolve_token() {
  if [ -n "${SERVICE_MANAGER_TOKEN:-}" ]; then
    printf '%s' "$SERVICE_MANAGER_TOKEN"
    return
  fi
  if [ -n "${SMALLPHONE_SERVICE_MANAGER_TOKEN:-}" ]; then
    printf '%s' "$SMALLPHONE_SERVICE_MANAGER_TOKEN"
    return
  fi
  if have service-manager; then
    service-manager token show 2>/dev/null | tr -d '\r\n' || true
    return
  fi
  printf ''
}

write_spec() {
  mkdir -p "$SERVICE_DIR"
  cat > "$SPEC_PATH" <<EOF
{
  "name": "pi-agent",
  "description": "Pi agent runtime sentinel for OpenHouseAI",
  "provider": "process",
  "command": ["sh", "-lc", "openhouse-pi-agent-sentinel"],
  "working_dir": "/root/workspace",
  "env": {
    "HOME": "/root",
    "PI_CODING_AGENT_DIR": "/root/.pi",
    "PATH": "/root/.npm-global/bin:/root/.local/node/bin:/root/.local/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin:/system/bin:/system/xbin:/data/data/com.termux/files/usr/bin"
  },
  "runtime": {},
  "restart": {
    "mode": "always",
    "max_retries": 0
  },
  "health": [],
  "enabled": true,
  "tags": ["group:local-stack", "openhouseai", "agent", "pi", "openhouse-component:pi-agent"]
}
EOF
}

service_name_to_id() {
  py="$1"
  services_file="$2"
  "$py" - "$SERVICE_NAME" "$services_file" <<'PY'
import json
import sys

name = sys.argv[1]
with open(sys.argv[2], "r", encoding="utf-8") as handle:
    raw = handle.read().strip()
if not raw:
    raise SystemExit(0)
try:
    payload = json.loads(raw)
except Exception:
    raise SystemExit(0)

if isinstance(payload, dict):
    if isinstance(payload.get("services"), list):
        services = payload["services"]
    elif isinstance(payload.get("data"), list):
        services = payload["data"]
    elif isinstance(payload.get("data"), dict) and isinstance(payload["data"].get("services"), list):
        services = payload["data"]["services"]
    else:
        services = []
elif isinstance(payload, list):
    services = payload
else:
    services = []

for svc in services:
    if not isinstance(svc, dict):
        continue
    spec = svc.get("spec")
    if isinstance(spec, dict) and spec.get("name") == name:
        sid = svc.get("id")
        if isinstance(sid, str) and sid:
            sys.stdout.write(sid)
            break
PY
}

duplicate_service_ids() {
  token="$1"
  py="$2"
  work_dir="$(mktemp -d "${TMPDIR:-/tmp}/pi-agent-sm.XXXXXX")" || return 1
  curl_cfg="$work_dir/curl.cfg"
  services_file="$work_dir/services.json"
  printf 'header = "Authorization: Bearer %s"\n' "$token" > "$curl_cfg"
  printf 'header = "Content-Type: application/json"\n' >> "$curl_cfg"

  services_json="$(curl -q -fsS --max-time 5 -K "$curl_cfg" "${SM_URL%/}/api/v1/services" 2>/dev/null || true)"
  printf '%s' "$services_json" > "$services_file"
  "$py" - "$SERVICE_NAME" "$services_file" <<'PY'
import json
import sys

name = sys.argv[1]
with open(sys.argv[2], "r", encoding="utf-8") as handle:
    raw = handle.read().strip()
try:
    services = json.loads(raw) if raw else []
except Exception:
    services = []
if isinstance(services, dict):
    services = services.get("services") or services.get("items") or []
for svc in services if isinstance(services, list) else []:
    if not isinstance(svc, dict):
        continue
    sid = svc.get("id")
    spec = svc.get("spec")
    if isinstance(sid, str) and sid != name and isinstance(spec, dict) and spec.get("name") == name:
        print(sid)
PY

  rm -rf "$work_dir"
}

cleanup_duplicate_services() {
  token="$1"
  py="$2"
  work_dir="$(mktemp -d "${TMPDIR:-/tmp}/pi-agent-sm-clean.XXXXXX")" || return 0
  curl_cfg="$work_dir/curl.cfg"
  printf 'header = "Authorization: Bearer %s"\n' "$token" > "$curl_cfg"
  printf 'header = "Content-Type: application/json"\n' >> "$curl_cfg"

  duplicate_service_ids "$token" "$py" | while IFS= read -r duplicate_id; do
    [ -n "$duplicate_id" ] || continue
    log "service-manager: removing duplicate $SERVICE_NAME service id $duplicate_id"
    curl -q -fsS --max-time 5 -X POST -K "$curl_cfg" "${SM_URL%/}/api/v1/services/$duplicate_id/stop" >/dev/null 2>&1 || true
    curl -q -fsS --max-time 5 -X DELETE -K "$curl_cfg" "${SM_URL%/}/api/v1/services/$duplicate_id" >/dev/null 2>&1 || true
  done

  rm -rf "$work_dir"
}

upsert_service() {
  token="$1"
  py="$2"
  work_dir="$(mktemp -d "${TMPDIR:-/tmp}/pi-agent-sm.XXXXXX")" || return 1
  curl_cfg="$work_dir/curl.cfg"
  apply_payload="$work_dir/registry-apply.json"
  printf 'header = "Authorization: Bearer %s"\n' "$token" > "$curl_cfg"
  printf 'header = "Content-Type: application/json"\n' >> "$curl_cfg"

  "$py" - "$SPEC_PATH" "$SERVICE_NAME" > "$apply_payload" <<'PY'
import json
import sys

spec_path, service_id = sys.argv[1], sys.argv[2]
with open(spec_path, "r", encoding="utf-8") as handle:
    spec = json.load(handle)
json.dump({"services": [{"id": service_id, "service": spec}]}, sys.stdout, ensure_ascii=False)
PY

  log "service-manager: applying $SERVICE_NAME ($SERVICE_NAME)"
  if curl -q -fsS --max-time 10 -X POST -K "$curl_cfg" --data-binary "@$apply_payload" "${SM_URL%/}/api/v1/registry/apply" >/dev/null 2>&1; then
    curl -q -fsS --max-time 5 -X POST -K "$curl_cfg" "${SM_URL%/}/api/v1/services/$SERVICE_NAME/register" >/dev/null 2>&1 || true
    cleanup_duplicate_services "$token" "$py" || true
  else
    warn "service-manager registry apply failed: $SERVICE_NAME"
    return 1
  fi

  rm -rf "$work_dir"
}

main() {
  write_spec
  log "wrote service registry: $SPEC_PATH"

  have curl || {
    warn "curl not found; service registry file will be loaded on next service-manager restart"
    exit 0
  }
  curl -fsS --max-time 2 "${SM_URL%/}/api/v1/health" >/dev/null 2>&1 || {
    warn "service-manager is not reachable at $SM_URL; registry file will be loaded on next restart"
    exit 0
  }

  token="$(resolve_token)"
  [ -n "$token" ] || {
    warn "service-manager token not available; registry file will be loaded on next restart"
    exit 0
  }

  if have python3; then
    py=python3
  elif have python; then
    py=python
  else
    warn "python not found; registry file will be loaded on next service-manager restart"
    exit 0
  fi

  upsert_service "$token" "$py" || warn "service-manager upsert failed: $SERVICE_NAME"
  log "done"
}

main "$@"
