#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }

SERVICE_NAME="pi-agent"
SM_URL="${SERVICE_MANAGER_URL:-${SMALLPHONE_SERVICE_MANAGER_URL:-http://127.0.0.1:20087}}"
CONFIG_DIR="${OPENHOUSEAI_CONFIG_DIR:-$HOME/.config/openhouseai}"
SERVICE_DIR="$CONFIG_DIR/service-manager/services.d"
SPEC_PATH="$SERVICE_DIR/$SERVICE_NAME.json"

have() { command -v "$1" >/dev/null 2>&1; }

openhouse_tmpdir() {
  _openhouse_tmp="${TMPDIR:-}"
  if [ -z "$_openhouse_tmp" ]; then
    if [ -n "${PREFIX:-}" ]; then
      _openhouse_tmp="$PREFIX/tmp"
    else
      _openhouse_tmp="${HOME:-.}/.tmp"
    fi
  fi
  mkdir -p "$_openhouse_tmp"
  printf '%s\n' "$_openhouse_tmp"
}

make_tmp_file() {
  _openhouse_dir="$(openhouse_tmpdir)" || return 1
  mktemp "$_openhouse_dir/$1.XXXXXX"
}

make_tmp_dir() {
  _openhouse_dir="$(openhouse_tmpdir)" || return 1
  mktemp -d "$_openhouse_dir/$1.XXXXXX"
}

json_validate() {
  _openhouse_json="$1"
  if have python3; then
    python3 - "$_openhouse_json" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as handle:
    json.load(handle)
PY
    return $?
  fi
  if have python; then
    python - "$_openhouse_json" <<'PY'
import json
import sys

with open(sys.argv[1], "r", encoding="utf-8") as handle:
    json.load(handle)
PY
    return $?
  fi
  if have node; then
    node - "$_openhouse_json" <<'NODE'
const fs = require("fs");
JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
NODE
    return $?
  fi
  warn "python/node not found; cannot validate JSON: $_openhouse_json"
  return 1
}

atomic_install_json() {
  _openhouse_tmp="$1"
  _openhouse_target="$2"
  if ! json_validate "$_openhouse_tmp"; then
    rm -f "$_openhouse_tmp" >/dev/null 2>&1 || true
    return 1
  fi
  mkdir -p "$(dirname "$_openhouse_target")"
  mv "$_openhouse_tmp" "$_openhouse_target"
}

json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

resolve_token() {
  if [ -n "${SERVICE_MANAGER_TOKEN:-}" ]; then
    printf '%s' "$SERVICE_MANAGER_TOKEN"
    return
  fi
  if [ -n "${SMALLPHONE_SERVICE_MANAGER_TOKEN:-}" ]; then
    printf '%s' "$SMALLPHONE_SERVICE_MANAGER_TOKEN"
    return
  fi
  if have service-manager; then
    service-manager token show 2>/dev/null | tr -d '\r\n' || true
    return
  fi
  printf ''
}

write_spec() {
  _openhouse_spec_tmp="$(make_tmp_file "pi-agent-spec")"
  cat > "$_openhouse_spec_tmp" <<EOF
{
  "name": "pi-agent",
  "description": "Pi agent runtime sentinel for OpenHouseAI",
  "provider": "termux-process",
  "command": [
    "sh",
    "-lc",
    "openhouse-pi-agent-sentinel & child=\$!; trap 'kill -TERM \$child 2>/dev/null; wait \$child 2>/dev/null || true' TERM INT HUP; wait \$child"
  ],
  "working_dir": "/root/workspace",
  "env": {
    "HOME": "/root",
    "PI_CODING_AGENT_DIR": "/root/.pi",
    "PATH": "/root/.npm-global/bin:/root/.local/node/bin:/root/.local/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin:/system/bin:/system/xbin:/data/data/com.termux/files/usr/bin"
  },
  "runtime": {
    "strategy": "termux-process",
    "runtime": "termux",
    "platform": "android-arm64"
  },
  "restart": {
    "mode": "always",
    "max_retries": 0
  },
  "health": [],
  "enabled": true,
  "tags": ["group:local-stack", "openhouseai", "agent", "pi", "openhouse-component:pi-agent"]
}
EOF
  atomic_install_json "$_openhouse_spec_tmp" "$SPEC_PATH"
}

service_name_to_id() {
  py="$1"
  services_file="$2"
  "$py" - "$SERVICE_NAME" "$services_file" <<'PY'
import json
import sys

name = sys.argv[1]
with open(sys.argv[2], "r", encoding="utf-8") as handle:
    raw = handle.read().strip()
if not raw:
    raise SystemExit(0)
try:
    payload = json.loads(raw)
except Exception:
    raise SystemExit(0)

if isinstance(payload, dict):
    if isinstance(payload.get("services"), list):
        services = payload["services"]
    elif isinstance(payload.get("data"), list):
        services = payload["data"]
    elif isinstance(payload.get("data"), dict) and isinstance(payload["data"].get("services"), list):
        services = payload["data"]["services"]
    else:
        services = []
elif isinstance(payload, list):
    services = payload
else:
    services = []

for svc in services:
    if not isinstance(svc, dict):
        continue
    spec = svc.get("spec")
    if isinstance(spec, dict) and spec.get("name") == name:
        sid = svc.get("id")
        if isinstance(sid, str) and sid:
            sys.stdout.write(sid)
            break
PY
}

duplicate_service_ids() {
  token="$1"
  py="$2"
  keep_id="${3:-$SERVICE_NAME}"
  work_dir="$(make_tmp_dir "pi-agent-sm")" || return 1
  curl_cfg="$work_dir/curl.cfg"
  services_file="$work_dir/services.json"
  printf 'header = "Authorization: Bearer %s"\n' "$token" > "$curl_cfg"
  printf 'header = "Content-Type: application/json"\n' >> "$curl_cfg"

  services_json="$(curl -q -fsS --max-time 5 -K "$curl_cfg" "${SM_URL%/}/api/v1/services" 2>/dev/null || true)"
  printf '%s' "$services_json" > "$services_file"
  "$py" - "$SERVICE_NAME" "$keep_id" "$services_file" <<'PY'
import json
import sys

name = sys.argv[1]
keep_id = sys.argv[2]
with open(sys.argv[3], "r", encoding="utf-8") as handle:
    raw = handle.read().strip()
try:
    services = json.loads(raw) if raw else []
except Exception:
    services = []
if isinstance(services, dict):
    services = services.get("services") or services.get("items") or []
for svc in services if isinstance(services, list) else []:
    if not isinstance(svc, dict):
        continue
    sid = svc.get("id")
    spec = svc.get("spec")
    if isinstance(sid, str) and sid != keep_id and isinstance(spec, dict) and spec.get("name") == name:
        print(sid)
PY

  rm -rf "$work_dir"
}

cleanup_duplicate_services() {
  token="$1"
  py="$2"
  keep_id="${3:-$SERVICE_NAME}"
  work_dir="$(make_tmp_dir "pi-agent-sm-clean")" || return 0
  curl_cfg="$work_dir/curl.cfg"
  printf 'header = "Authorization: Bearer %s"\n' "$token" > "$curl_cfg"
  printf 'header = "Content-Type: application/json"\n' >> "$curl_cfg"

  duplicate_service_ids "$token" "$py" "$keep_id" | while IFS= read -r duplicate_id; do
    [ -n "$duplicate_id" ] || continue
    log "service-manager: removing duplicate $SERVICE_NAME service id $duplicate_id"
    curl -q -fsS --max-time 5 -X POST -K "$curl_cfg" "${SM_URL%/}/api/v1/services/$duplicate_id/stop" >/dev/null 2>&1 || true
    curl -q -fsS --max-time 5 -X DELETE -K "$curl_cfg" "${SM_URL%/}/api/v1/services/$duplicate_id" >/dev/null 2>&1 || true
  done

  rm -rf "$work_dir"
}

curl_api() {
  curl_cfg="$1"
  method="$2"
  path="$3"
  body_file="${4:-}"
  out_file="$5"
  err_file="$6"
  status_file="$7"

  if [ -n "$body_file" ]; then
    status="$(curl -q -sS --max-time 10 -o "$out_file" -w '%{http_code}' -X "$method" -K "$curl_cfg" --data-binary "@$body_file" "${SM_URL%/}$path" 2>"$err_file")" || status="000"
  else
    status="$(curl -q -sS --max-time 10 -o "$out_file" -w '%{http_code}' -X "$method" -K "$curl_cfg" "${SM_URL%/}$path" 2>"$err_file")" || status="000"
  fi
  printf '%s' "$status" > "$status_file"
  case "$status" in
    2*) return 0 ;;
    *) return 1 ;;
  esac
}

response_summary() {
  out_file="$1"
  err_file="$2"
  summary="$(tr '\r\n' '  ' < "$out_file" 2>/dev/null | cut -c 1-240 || true)"
  if [ -z "$summary" ]; then
    summary="$(tr '\r\n' '  ' < "$err_file" 2>/dev/null | cut -c 1-240 || true)"
  fi
  [ -n "$summary" ] || summary="empty response"
  printf '%s' "$summary"
}

preferred_existing_service_id() {
  py="$1"
  services_file="$2"
  "$py" - "$SERVICE_NAME" "$services_file" <<'PY'
import json
import sys

name = sys.argv[1]
try:
    payload = json.load(open(sys.argv[2], "r", encoding="utf-8"))
except Exception:
    raise SystemExit(0)
if isinstance(payload, dict):
    services = payload.get("services") or payload.get("items") or payload.get("data") or []
elif isinstance(payload, list):
    services = payload
else:
    services = []
matches = []
for svc in services if isinstance(services, list) else []:
    if not isinstance(svc, dict):
        continue
    sid = svc.get("id")
    spec = svc.get("spec")
    if isinstance(sid, str) and isinstance(spec, dict) and spec.get("name") == name:
        matches.append(sid)
if name in matches:
    sys.stdout.write(name)
elif len(matches) == 1:
    sys.stdout.write(matches[0])
PY
}

register_by_name_or_id() {
  curl_cfg="$1"
  service_id="$2"
  out_file="$3"
  err_file="$4"
  status_file="$5"

  if curl_api "$curl_cfg" POST "/api/v1/services/$SERVICE_NAME/register" "" "$out_file" "$err_file" "$status_file"; then
    return 0
  fi
  [ "$service_id" = "$SERVICE_NAME" ] && return 1
  curl_api "$curl_cfg" POST "/api/v1/services/$service_id/register" "" "$out_file" "$err_file" "$status_file"
}

fallback_upsert_service() {
  token="$1"
  py="$2"
  fallback_curl_cfg="$3"
  fallback_work_dir="$4"
  services_file="$fallback_work_dir/services.json"
  response_file="$fallback_work_dir/services-response.json"
  err_file="$fallback_work_dir/services-response.err"
  status_file="$fallback_work_dir/services-response.status"
  service_id=""

  if curl_api "$fallback_curl_cfg" GET "/api/v1/services" "" "$services_file" "$err_file" "$status_file"; then
    service_id="$(preferred_existing_service_id "$py" "$services_file" || true)"
  else
    warn "service-manager services list failed: HTTP $(cat "$status_file" 2>/dev/null || printf 000) $(response_summary "$services_file" "$err_file")"
  fi

  if [ -n "$service_id" ]; then
    log "service-manager: fallback updating existing $SERVICE_NAME service id $service_id"
    if curl_api "$fallback_curl_cfg" PUT "/api/v1/services/$service_id" "$SPEC_PATH" "$response_file" "$err_file" "$status_file"; then
      cleanup_duplicate_services "$token" "$py" "$service_id" || true
      register_by_name_or_id "$fallback_curl_cfg" "$service_id" "$response_file" "$err_file" "$status_file" || warn "service-manager fallback register failed: HTTP $(cat "$status_file" 2>/dev/null || printf 000) $(response_summary "$response_file" "$err_file")"
      return 0
    fi
    warn "service-manager fallback update failed: HTTP $(cat "$status_file" 2>/dev/null || printf 000) $(response_summary "$response_file" "$err_file")"
    curl -q -fsS --max-time 5 -X POST -K "$fallback_curl_cfg" "${SM_URL%/}/api/v1/services/$service_id/stop" >/dev/null 2>&1 || true
    curl -q -fsS --max-time 5 -X DELETE -K "$fallback_curl_cfg" "${SM_URL%/}/api/v1/services/$service_id" >/dev/null 2>&1 || true
  fi

  cleanup_duplicate_services "$token" "$py" "__openhouse_missing_stable_id__" || true
  warn "service-manager fallback refused to create random id for $SERVICE_NAME. Stable registry file is ready at $SPEC_PATH; restart or repair Termux native service-manager so it reloads services.d/$SERVICE_NAME.json."
  return 1
}

upsert_service() {
  token="$1"
  py="$2"
  work_dir="$(make_tmp_dir "pi-agent-sm")" || return 1
  curl_cfg="$work_dir/curl.cfg"
  apply_payload="$work_dir/registry-apply.json"
  printf 'header = "Authorization: Bearer %s"\n' "$token" > "$curl_cfg"
  printf 'header = "Content-Type: application/json"\n' >> "$curl_cfg"

  "$py" - "$SPEC_PATH" "$SERVICE_NAME" > "$apply_payload" <<'PY'
import json
import sys

spec_path, service_id = sys.argv[1], sys.argv[2]
with open(spec_path, "r", encoding="utf-8") as handle:
    spec = json.load(handle)
json.dump({"services": [{"id": service_id, "service": spec}]}, sys.stdout, ensure_ascii=False)
PY

  apply_response="$work_dir/registry-apply-response.json"
  apply_error="$work_dir/registry-apply-response.err"
  apply_status="$work_dir/registry-apply-response.status"

  log "service-manager: applying $SERVICE_NAME ($SERVICE_NAME)"
  if curl_api "$curl_cfg" POST "/api/v1/registry/apply" "$apply_payload" "$apply_response" "$apply_error" "$apply_status"; then
    curl -q -fsS --max-time 5 -X POST -K "$curl_cfg" "${SM_URL%/}/api/v1/services/$SERVICE_NAME/register" >/dev/null 2>&1 || true
    cleanup_duplicate_services "$token" "$py" "$SERVICE_NAME" || true
  else
    warn "service-manager registry apply failed: $SERVICE_NAME HTTP $(cat "$apply_status" 2>/dev/null || printf 000) $(response_summary "$apply_response" "$apply_error")"
    if fallback_upsert_service "$token" "$py" "$curl_cfg" "$work_dir"; then
      log "service-manager: fallback registered $SERVICE_NAME"
    else
      rm -rf "$work_dir"
      return 1
    fi
  fi

  rm -rf "$work_dir"
}

main() {
  write_spec
  log "wrote service registry: $SPEC_PATH"

  have curl || {
    warn "curl not found; service registry file will be loaded on next service-manager restart"
    exit 0
  }
  curl -fsS --max-time 2 "${SM_URL%/}/api/v1/health" >/dev/null 2>&1 || {
    warn "service-manager is not reachable at $SM_URL; registry file will be loaded on next restart"
    exit 0
  }

  token="$(resolve_token)"
  [ -n "$token" ] || {
    warn "service-manager token not available; registry file will be loaded on next restart"
    exit 0
  }

  if have python3; then
    py=python3
  elif have python; then
    py=python
  else
    warn "python not found; registry file will be loaded on next service-manager restart"
    exit 0
  fi

  if ! upsert_service "$token" "$py"; then
    warn "service-manager upsert failed: $SERVICE_NAME"
    exit 1
  fi
  log "done"
}

main "$@"
