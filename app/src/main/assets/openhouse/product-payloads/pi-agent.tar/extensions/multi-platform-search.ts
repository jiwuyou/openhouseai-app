/**
 * Multi Platform Search Tool
 *
 * API-key-free web search extension intended for lightweight pi setups such as
 * Termux Ubuntu. Bing is the stable default; Chinese engines are best-effort.
 */

import { Type } from "@earendil-works/pi-ai";
import { defineTool, type ExtensionAPI } from "@earendil-works/pi-coding-agent";

type ProviderId = "bing" | "baidu" | "sogou" | "quark";
type ProviderStatus = "ok" | "error";

interface SearchResult {
	title: string;
	url: string;
	snippet?: string;
	source: ProviderId;
}

interface ProviderDetails {
	platform: string;
	label: string;
	status: ProviderStatus;
	requestUrl?: string;
	error?: string;
	results: SearchResult[];
}

interface MultiPlatformSearchDetails {
	query: string;
	platforms: string[];
	maxResults: number;
	searchedAt: string;
	warnings: string[];
	providers: ProviderDetails[];
}

interface SearchProvider {
	id: ProviderId;
	label: string;
	baseUrl: string;
	buildUrl(query: string): string;
	parse(html: string, maxResults: number): SearchResult[];
}

const DEFAULT_PLATFORM: ProviderId = "bing";
const DEFAULT_MAX_RESULTS = 5;
const MAX_RESULTS_LIMIT = 10;
const REQUEST_TIMEOUT_MS = 9000;

const SearchParams = Type.Object({
	query: Type.String({ description: "Search query / 搜索关键词" }),
	platforms: Type.Optional(
		Type.String({
			description:
				"Comma-separated platforms: bing, baidu, sogou, quark, or all. Default: bing. / 用逗号分隔的平台，默认 bing。",
			default: DEFAULT_PLATFORM,
		}),
	),
	maxResults: Type.Optional(
		Type.Number({
			description: "Maximum results per platform, from 1 to 10. / 每个平台最多返回结果数。",
			default: DEFAULT_MAX_RESULTS,
			minimum: 1,
			maximum: MAX_RESULTS_LIMIT,
		}),
	),
});

const PLATFORM_ALIASES: Record<string, ProviderId | "all"> = {
	all: "all",
	bing: "bing",
	"cn.bing": "bing",
	"cn.bing.com": "bing",
	"bing.com": "bing",
	baidu: "baidu",
	"baidu.com": "baidu",
	sogou: "sogou",
	"sogou.com": "sogou",
	quark: "quark",
	"quark.sm.cn": "quark",
	"sm.cn": "quark",
	必应: "bing",
	必應: "bing",
	百度: "baidu",
	搜狗: "sogou",
	夸克: "quark",
	全部: "all",
	所有: "all",
};

const BROWSER_HEADERS = {
	accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
	"accept-language": "zh-CN,zh;q=0.9,en;q=0.7",
	"user-agent": "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
};

const PROVIDERS: Record<ProviderId, SearchProvider> = {
	bing: {
		id: "bing",
		label: "Bing",
		baseUrl: "https://cn.bing.com",
		buildUrl(query) {
			return `https://cn.bing.com/search?q=${encodeURIComponent(query)}&setlang=zh-CN&mkt=zh-CN`;
		},
		parse(html, maxResults) {
			return parseByBlocks(html, {
				source: "bing",
				baseUrl: "https://cn.bing.com",
				blockPattern: /<li\b[^>]*class=["'][^"']*\bb_algo\b[^"']*["'][^>]*>[\s\S]*?<\/li>/gi,
				anchorPattern: /<h2\b[^>]*>[\s\S]*?<a\b([^>]*)>([\s\S]*?)<\/a>[\s\S]*?<\/h2>/i,
				snippetPatterns: [
					/<div\b[^>]*class=["'][^"']*\bb_caption\b[^"']*["'][^>]*>[\s\S]*?<p\b[^>]*>([\s\S]*?)<\/p>/i,
					/<p\b[^>]*>([\s\S]*?)<\/p>/i,
				],
				maxResults,
			});
		},
	},
	baidu: {
		id: "baidu",
		label: "Baidu",
		baseUrl: "https://www.baidu.com",
		buildUrl(query) {
			return `https://www.baidu.com/s?wd=${encodeURIComponent(query)}`;
		},
		parse(html, maxResults) {
			return parseByBlocks(html, {
				source: "baidu",
				baseUrl: "https://www.baidu.com",
				blockPattern:
					/<div\b[^>]*(?:class|tpl)=["'][^"']*(?:result|c-container)[^"']*["'][^>]*>[\s\S]*?(?=<div\b[^>]*(?:class|tpl)=["'][^"']*(?:result|c-container)[^"']*["']|<\/body>|$)/gi,
				anchorPattern: /<h3\b[^>]*>[\s\S]*?<a\b([^>]*)>([\s\S]*?)<\/a>[\s\S]*?<\/h3>/i,
				snippetPatterns: [
					/<span\b[^>]*class=["'][^"']*\bcontent-right\b[^"']*["'][^>]*>([\s\S]*?)<\/span>/i,
					/<div\b[^>]*class=["'][^"']*\bc-abstract\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
					/<div\b[^>]*class=["'][^"']*\bc-span-last\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
				],
				maxResults,
			});
		},
	},
	sogou: {
		id: "sogou",
		label: "Sogou",
		baseUrl: "https://www.sogou.com",
		buildUrl(query) {
			return `https://www.sogou.com/web?query=${encodeURIComponent(query)}`;
		},
		parse(html, maxResults) {
			return parseByBlocks(html, {
				source: "sogou",
				baseUrl: "https://www.sogou.com",
				blockPattern:
					/<div\b[^>]*class=["'][^"']*(?:vrwrap|results|rb)[^"']*["'][^>]*>[\s\S]*?(?=<div\b[^>]*class=["'][^"']*(?:vrwrap|results|rb)[^"']*["']|<\/body>|$)/gi,
				anchorPattern: /<h3\b[^>]*>[\s\S]*?<a\b([^>]*)>([\s\S]*?)<\/a>[\s\S]*?<\/h3>/i,
				snippetPatterns: [
					/<div\b[^>]*class=["'][^"']*\bft\b[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
					/<p\b[^>]*class=["'][^"']*\bstr_info\b[^"']*["'][^>]*>([\s\S]*?)<\/p>/i,
					/<p\b[^>]*>([\s\S]*?)<\/p>/i,
				],
				maxResults,
			});
		},
	},
	quark: {
		id: "quark",
		label: "Quark",
		baseUrl: "https://quark.sm.cn",
		buildUrl(query) {
			return `https://quark.sm.cn/s?q=${encodeURIComponent(query)}`;
		},
		parse(html, maxResults) {
			return parseByBlocks(html, {
				source: "quark",
				baseUrl: "https://quark.sm.cn",
				blockPattern:
					/<(?:div|article)\b[^>]*class=["'][^"']*(?:result|card|item|sc-)[^"']*["'][^>]*>[\s\S]*?(?=<(?:div|article)\b[^>]*class=["'][^"']*(?:result|card|item|sc-)[^"']*["']|<\/body>|$)/gi,
				anchorPattern: /<a\b([^>]*)>([\s\S]*?)<\/a>/i,
				snippetPatterns: [
					/<p\b[^>]*>([\s\S]*?)<\/p>/i,
					/<div\b[^>]*class=["'][^"']*(?:desc|summary|abstract)[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
				],
				maxResults,
			});
		},
	},
};

export async function searchMultiPlatform(
	query: string,
	options: { platforms?: string; maxResults?: number; signal?: AbortSignal } = {},
): Promise<MultiPlatformSearchDetails> {
	const normalizedQuery = normalizeWhitespace(query);
	const maxResults = clampMaxResults(options.maxResults);
	const { providers, warnings } = resolveProviders(options.platforms);
	const searchedAt = new Date().toISOString();

	if (!normalizedQuery) {
		return {
			query: normalizedQuery,
			platforms: providers.map((provider) => provider.id),
			maxResults,
			searchedAt,
			warnings: [...warnings, "query is empty"],
			providers: [],
		};
	}

	const results = await Promise.all(
		providers.map(async (provider): Promise<ProviderDetails> => {
			const requestUrl = provider.buildUrl(normalizedQuery);
			try {
				const html = await fetchText(requestUrl, options.signal);
				return {
					platform: provider.id,
					label: provider.label,
					status: "ok",
					requestUrl,
					results: provider.parse(html, maxResults),
				};
			} catch (error) {
				return {
					platform: provider.id,
					label: provider.label,
					status: "error",
					requestUrl,
					error: errorMessage(error),
					results: [],
				};
			}
		}),
	);

	return {
		query: normalizedQuery,
		platforms: providers.map((provider) => provider.id),
		maxResults,
		searchedAt,
		warnings,
		providers: results,
	};
}

function createSearchTool(name: string, label: string, description: string) {
	return defineTool({
		name,
		label,
		description,
		promptSnippet:
			"Search the public web without an API key using Bing by default; optional platforms: Baidu, Sogou, Quark.",
		promptGuidelines: [
			"Use multi_platform_search when current public web information is needed and no dedicated search API is configured.",
			"Prefer the default Bing platform for reliability. Use platforms='all' only when the user wants broader Chinese web coverage.",
			"Treat Baidu, Sogou, and Quark as best-effort HTML sources; provider errors do not mean the whole search failed.",
		],
		parameters: SearchParams,
		executionMode: "parallel",

		async execute(_toolCallId, params, signal) {
			const details = await searchMultiPlatform(params.query, {
				platforms: params.platforms,
				maxResults: params.maxResults,
				signal,
			});

			return {
				content: [{ type: "text", text: formatSearchResult(details) }],
				details,
			};
		},
	});
}

async function fetchText(url: string, parentSignal?: AbortSignal): Promise<string> {
	const { signal, cleanup } = makeTimeoutSignal(parentSignal, REQUEST_TIMEOUT_MS);
	try {
		const response = await fetch(url, {
			headers: BROWSER_HEADERS,
			redirect: "follow",
			signal,
		});

		if (!response.ok) {
			throw new Error(`HTTP ${response.status} ${response.statusText}`);
		}

		return await response.text();
	} finally {
		cleanup();
	}
}

function makeTimeoutSignal(parentSignal: AbortSignal | undefined, timeoutMs: number) {
	const controller = new AbortController();
	const timeout = setTimeout(() => controller.abort(), timeoutMs);
	const onParentAbort = () => controller.abort();

	if (parentSignal) {
		if (parentSignal.aborted) {
			onParentAbort();
		} else {
			parentSignal.addEventListener("abort", onParentAbort, { once: true });
		}
	}

	return {
		signal: controller.signal,
		cleanup() {
			clearTimeout(timeout);
			parentSignal?.removeEventListener("abort", onParentAbort);
		},
	};
}

function resolveProviders(platforms?: string): { providers: SearchProvider[]; warnings: string[] } {
	const requested = normalizePlatformTokens(platforms);
	const selected: ProviderId[] = [];
	const warnings: string[] = [];

	for (const token of requested) {
		const mapped = PLATFORM_ALIASES[token];
		if (mapped === "all") {
			for (const providerId of Object.keys(PROVIDERS) as ProviderId[]) {
				if (!selected.includes(providerId)) selected.push(providerId);
			}
			continue;
		}
		if (mapped) {
			if (!selected.includes(mapped)) selected.push(mapped);
			continue;
		}
		warnings.push(`unsupported platform ignored: ${token}`);
	}

	if (selected.length === 0) {
		selected.push(DEFAULT_PLATFORM);
		if (requested.length > 0) {
			warnings.push(`no supported platform selected; using ${DEFAULT_PLATFORM}`);
		}
	}

	return {
		providers: selected.map((id) => PROVIDERS[id]),
		warnings,
	};
}

function normalizePlatformTokens(platforms?: string): string[] {
	if (!platforms || !platforms.trim()) return [DEFAULT_PLATFORM];
	return platforms
		.split(/[,，;；|/\s]+/g)
		.map((token) => token.trim().toLowerCase())
		.filter(Boolean);
}

function clampMaxResults(value: number | undefined): number {
	if (!Number.isFinite(value)) return DEFAULT_MAX_RESULTS;
	return Math.max(1, Math.min(MAX_RESULTS_LIMIT, Math.floor(value ?? DEFAULT_MAX_RESULTS)));
}

function parseByBlocks(
	html: string,
	options: {
		source: ProviderId;
		baseUrl: string;
		blockPattern: RegExp;
		anchorPattern: RegExp;
		snippetPatterns: RegExp[];
		maxResults: number;
	},
): SearchResult[] {
	const results: SearchResult[] = [];
	const seenUrls = new Set<string>();
	const searchableHtml = stripIgnoredTags(html);
	const blocks = Array.from(searchableHtml.matchAll(options.blockPattern)).map((match) => match[0]);

	for (const block of blocks) {
		const result = extractResultFromBlock(block, options);
		if (!result || seenUrls.has(result.url)) continue;
		seenUrls.add(result.url);
		results.push(result);
		if (results.length >= options.maxResults) return results;
	}

	for (const result of parseGenericAnchors(searchableHtml, options.source, options.baseUrl, options.maxResults * 4)) {
		if (seenUrls.has(result.url)) continue;
		seenUrls.add(result.url);
		results.push(result);
		if (results.length >= options.maxResults) break;
	}

	return results;
}

function extractResultFromBlock(
	block: string,
	options: {
		source: ProviderId;
		baseUrl: string;
		anchorPattern: RegExp;
		snippetPatterns: RegExp[];
	},
): SearchResult | undefined {
	const anchor = options.anchorPattern.exec(block) ?? /<a\b([^>]*)>([\s\S]*?)<\/a>/i.exec(block);
	if (!anchor) return undefined;

	const href = getHtmlAttribute(anchor[1] ?? "", "href");
	const title = cleanText(anchor[2] ?? "");
	const url = normalizeResultUrl(href, options.baseUrl);
	if (!isLikelyResult(title, url, options.source)) return undefined;

	const snippet = extractSnippet(block, options.snippetPatterns, title);
	return {
		title,
		url,
		snippet,
		source: options.source,
	};
}

function parseGenericAnchors(html: string, source: ProviderId, baseUrl: string, limit: number): SearchResult[] {
	const results: SearchResult[] = [];
	const seenUrls = new Set<string>();
	const anchorPattern = /<a\b([^>]*)>([\s\S]*?)<\/a>/gi;

	for (const match of html.matchAll(anchorPattern)) {
		const href = getHtmlAttribute(match[1] ?? "", "href");
		const title = cleanText(match[2] ?? "");
		const url = normalizeResultUrl(href, baseUrl);
		if (!isLikelyResult(title, url, source) || seenUrls.has(url)) continue;
		seenUrls.add(url);
		results.push({ title, url, source });
		if (results.length >= limit) break;
	}

	return results;
}

function extractSnippet(block: string, patterns: RegExp[], title: string): string | undefined {
	for (const pattern of patterns) {
		const match = pattern.exec(block);
		if (!match) continue;
		const snippet = cleanText(match[1] ?? "");
		if (snippet && snippet !== title && snippet.length > 6) return trimToLength(snippet, 280);
	}
	return undefined;
}

function getHtmlAttribute(attributes: string, name: string): string | undefined {
	const pattern = new RegExp(`${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "i");
	const match = pattern.exec(attributes);
	const value = match?.[1] ?? match?.[2] ?? match?.[3];
	return value ? decodeHtmlEntities(value.trim()) : undefined;
}

function normalizeResultUrl(href: string | undefined, baseUrl: string): string {
	if (!href) return "";
	const decoded = decodeHtmlEntities(href.trim());
	if (!decoded || decoded.startsWith("#") || /^javascript:/i.test(decoded)) return "";

	try {
		const absolute = decoded.startsWith("//") ? `https:${decoded}` : new URL(decoded, baseUrl).toString();
		return unwrapSearchRedirect(absolute);
	} catch {
		return "";
	}
}

function unwrapSearchRedirect(url: string): string {
	try {
		const parsed = new URL(url);
		const redirectParam =
			parsed.searchParams.get("u") ?? parsed.searchParams.get("url") ?? parsed.searchParams.get("target");
		if (!redirectParam) return url;

		const decoded = decodeURIComponent(redirectParam);
		if (/^https?:\/\//i.test(decoded)) return decoded;

		const maybeBingBase64 = decoded.startsWith("a1") ? decoded.slice(2) : decoded;
		if (/^[A-Za-z0-9_-]{12,}={0,2}$/.test(maybeBingBase64)) {
			const plain = atob(maybeBingBase64.replace(/-/g, "+").replace(/_/g, "/"));
			if (/^https?:\/\//i.test(plain)) return plain;
		}
	} catch {
		return url;
	}
	return url;
}

function isLikelyResult(title: string, url: string, source: ProviderId): boolean {
	if (!title || title.length < 2 || !url) return false;
	if (!/^https?:\/\//i.test(url)) return false;
	if (isNavigationTitle(title)) return false;

	try {
		const parsed = new URL(url);
		const host = parsed.hostname.replace(/^www\./, "");
		const ownHosts: Record<ProviderId, string[]> = {
			bing: ["bing.com", "cn.bing.com"],
			baidu: ["baidu.com", "www.baidu.com"],
			sogou: ["sogou.com", "www.sogou.com"],
			quark: ["quark.sm.cn", "sm.cn"],
		};
		const isOwnHost = ownHosts[source].some((ownHost) => host === ownHost || host.endsWith(`.${ownHost}`));
		if (!isOwnHost) return true;
		return isAllowedRedirectPath(source, parsed.pathname);
	} catch {
		return false;
	}
}

function isAllowedRedirectPath(source: ProviderId, pathname: string): boolean {
	if (source === "bing") return pathname.startsWith("/ck/");
	if (source === "baidu") return pathname.startsWith("/link");
	if (source === "sogou") return pathname.startsWith("/link");
	return false;
}

function isNavigationTitle(title: string): boolean {
	const lower = title.toLowerCase();
	const blocked = [
		"images",
		"videos",
		"maps",
		"news",
		"shopping",
		"更多",
		"图片",
		"视频",
		"地图",
		"新闻",
		"登录",
		"设置",
		"下一页",
	];
	return blocked.some((item) => lower === item || title === item);
}

function stripIgnoredTags(html: string): string {
	return html
		.replace(/<script\b[\s\S]*?<\/script>/gi, " ")
		.replace(/<style\b[\s\S]*?<\/style>/gi, " ")
		.replace(/<noscript\b[\s\S]*?<\/noscript>/gi, " ");
}

function cleanText(html: string): string {
	return trimToLength(
		decodeHtmlEntities(
			stripIgnoredTags(html)
				.replace(/<br\s*\/?>/gi, " ")
				.replace(/<\/(?:p|div|li|h\d)>/gi, " ")
				.replace(/<[^>]+>/g, " "),
		),
		360,
	);
}

function decodeHtmlEntities(value: string): string {
	const named: Record<string, string> = {
		amp: "&",
		apos: "'",
		gt: ">",
		lt: "<",
		nbsp: " ",
		quot: '"',
	};

	return value
		.replace(/&#x([0-9a-f]+);/gi, (_match, code) => String.fromCodePoint(Number.parseInt(code, 16)))
		.replace(/&#(\d+);/g, (_match, code) => String.fromCodePoint(Number.parseInt(code, 10)))
		.replace(/&([a-z]+);/gi, (match, name) => named[name.toLowerCase()] ?? match)
		.replace(/\s+/g, " ")
		.trim();
}

function normalizeWhitespace(value: string): string {
	return value.replace(/\s+/g, " ").trim();
}

function trimToLength(value: string, maxLength: number): string {
	const normalized = normalizeWhitespace(value);
	if (normalized.length <= maxLength) return normalized;
	return `${normalized.slice(0, maxLength - 1).trimEnd()}...`;
}

function formatSearchResult(details: MultiPlatformSearchDetails): string {
	if (!details.query) return "请提供要搜索的关键词。";

	const lines = [
		`多平台搜索: ${details.query}`,
		`平台: ${details.platforms.join(", ")}；每个平台最多 ${details.maxResults} 条`,
	];

	if (details.warnings.length > 0) {
		lines.push("", "提示:", ...details.warnings.map((warning) => `- ${warning}`));
	}

	for (const provider of details.providers) {
		lines.push("", `[${provider.label}]`);
		if (provider.status === "error") {
			lines.push(`搜索失败: ${provider.error ?? "unknown error"}`);
			continue;
		}
		if (provider.results.length === 0) {
			lines.push("未获得可解析的搜索结果。");
			continue;
		}

		for (const [index, result] of provider.results.entries()) {
			lines.push(`${index + 1}. ${result.title}`, `   URL: ${result.url}`);
			if (result.snippet) lines.push(`   摘要: ${result.snippet}`);
		}
	}

	const hasUsableResult = details.providers.some((provider) => provider.results.length > 0);
	if (!hasUsableResult) {
		lines.push("", "没有获得可用结果。可稍后重试，或先使用 platforms='bing'。");
	}

	return lines.join("\n");
}

function errorMessage(error: unknown): string {
	if (error instanceof Error) return error.message;
	return String(error);
}

const multiPlatformSearchTool = createSearchTool(
	"multi_platform_search",
	"多平台搜索",
	"Search the public web across multiple platforms. Default platform is Bing; Baidu, Sogou, and Quark are best-effort.",
);

const webSearchTool = createSearchTool(
	"web_search",
	"网页搜索",
	"Alias of multi_platform_search for API-key-free public web search.",
);

const searchWebTool = createSearchTool(
	"search_web",
	"搜索网页",
	"Alias of multi_platform_search for API-key-free public web search.",
);

const searchTool = createSearchTool(
	"search",
	"搜索",
	"Alias of multi_platform_search for API-key-free public web search.",
);

export default function (pi: ExtensionAPI) {
	pi.registerTool(multiPlatformSearchTool);
	pi.registerTool(webSearchTool);
	pi.registerTool(searchWebTool);
	pi.registerTool(searchTool);
}
