#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

export PATH="/root/.npm-global/bin:/root/.local/node/bin:/root/.local/bin:$PATH"

command -v node >/dev/null 2>&1 || die "node is missing"
node -e '
const [major, minor] = process.versions.node.split(".").map(Number);
process.exit(major > 22 || (major === 22 && minor >= 19) ? 0 : 1);
' >/dev/null 2>&1 || die "Node >= 22.19 is required. Found: $(node -v 2>/dev/null || printf unknown)"

command -v npm >/dev/null 2>&1 || die "npm is missing"
[ -x /root/.local/bin/openhouse-pi-web-start ] || die "openhouse-pi-web-start is missing"

global_root="$(npm root -g 2>/dev/null || true)"
pkg_dir=""
for candidate in \
  "$global_root/@agegr/pi-web" \
  "/root/.npm-global/lib/node_modules/@agegr/pi-web" \
  "/usr/local/lib/node_modules/@agegr/pi-web"; do
  if [ -n "$candidate" ] && [ -f "$candidate/package.json" ]; then
    pkg_dir="$candidate"
    break
  fi
done

[ -n "$pkg_dir" ] || die "pi-web package is missing"
[ -d "$pkg_dir/.next" ] || die "pi-web .next build artifacts are missing"
[ -f "$pkg_dir/bin/pi-web.js" ] || die "pi-web CLI entry is missing"

log "ok: pi-web package is installed"
