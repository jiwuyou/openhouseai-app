#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }

SERVICE_NAME="pi-web"
SM_URL="${SERVICE_MANAGER_URL:-${SMALLPHONE_SERVICE_MANAGER_URL:-http://127.0.0.1:20087}}"
PI_WEB_PORT="${PI_WEB_PORT:-30141}"
PI_WEB_HOST="${PI_WEB_HOST:-127.0.0.1}"
PI_WEB_URL="http://${PI_WEB_HOST}:${PI_WEB_PORT}/"
CONFIG_DIR="${OPENHOUSEAI_CONFIG_DIR:-$HOME/.config/openhouseai}"
SERVICE_DIR="$CONFIG_DIR/service-manager/services.d"
COMPONENT_DIR="$CONFIG_DIR/components.d"
SPEC_PATH="$SERVICE_DIR/$SERVICE_NAME.json"
COMPONENT_PATH="$COMPONENT_DIR/pi-web.json"

have() { command -v "$1" >/dev/null 2>&1; }

resolve_token() {
  if [ -n "${SERVICE_MANAGER_TOKEN:-}" ]; then
    printf '%s' "$SERVICE_MANAGER_TOKEN"
    return
  fi
  if [ -n "${SMALLPHONE_SERVICE_MANAGER_TOKEN:-}" ]; then
    printf '%s' "$SMALLPHONE_SERVICE_MANAGER_TOKEN"
    return
  fi
  if have service-manager; then
    service-manager token show 2>/dev/null | tr -d '\r\n' || true
    return
  fi
  printf ''
}

write_spec() {
  mkdir -p "$SERVICE_DIR"
  cat > "$SPEC_PATH" <<EOF
{
  "name": "pi-web",
  "description": "Pi Web main agent workspace for OpenHouseAI",
  "provider": "process",
  "command": ["openhouse-pi-web-start"],
  "working_dir": "/root",
  "env": {
    "HOME": "/root",
    "PORT": "$PI_WEB_PORT",
    "PI_WEB_PORT": "$PI_WEB_PORT",
    "PI_WEB_HOST": "$PI_WEB_HOST",
    "PI_CODING_AGENT_DIR": "/root/.pi",
    "PATH": "/root/.npm-global/bin:/root/.local/node/bin:/root/.local/bin:/usr/local/bin:/usr/local/sbin:/usr/sbin:/usr/bin:/sbin:/bin:/system/bin:/system/xbin:/data/data/com.termux/files/usr/bin"
  },
  "runtime": {},
  "restart": {
    "mode": "always",
    "max_retries": 0
  },
  "health": [
    {
      "type": "http",
      "url": "$PI_WEB_URL",
      "interval": "30s",
      "timeout": "5s"
    }
  ],
  "enabled": true,
  "tags": ["group:local-stack", "openhouseai", "agent", "pi", "openhouse-component:pi-web"]
}
EOF
}

write_component() {
  mkdir -p "$COMPONENT_DIR"
  cat > "$COMPONENT_PATH" <<EOF
{
  "id": "pi-web",
  "enabled": true,
  "shellMenu": {
    "title": "Pi Agent",
    "subtitle": "本机主 Agent 工作台",
    "section": "ai",
    "order": 20,
    "visible": true,
    "favorite": true,
    "home": true,
    "entry": {
      "type": "webview",
      "url": "$PI_WEB_URL"
    },
    "controlEntry": {
      "type": "service-control",
      "title": "控制",
      "serviceRefs": [
        "service-manager://services/pi-web",
        "service-manager://services/pi-agent"
      ]
    }
  },
  "smallphoneApp": {},
  "serviceManager": {
    "services": [
      {
        "name": "pi-web",
        "serviceRef": "service-manager://services/pi-web"
      },
      {
        "name": "pi-agent",
        "serviceRef": "service-manager://services/pi-agent"
      }
    ]
  },
  "ai": {
    "role": "primary-agent-ui",
    "agent": "pi",
    "url": "$PI_WEB_URL",
    "extensionDirs": [
      "/root/.pi/extensions",
      "/root/.pi/agent/extensions"
    ]
  }
}
EOF
}

service_name_to_id() {
  py="$1"
  services_file="$2"
  "$py" - "$SERVICE_NAME" "$services_file" <<'PY'
import json
import sys

name = sys.argv[1]
with open(sys.argv[2], "r", encoding="utf-8") as handle:
    raw = handle.read().strip()
if not raw:
    raise SystemExit(0)
try:
    payload = json.loads(raw)
except Exception:
    raise SystemExit(0)

if isinstance(payload, dict):
    if isinstance(payload.get("services"), list):
        services = payload["services"]
    elif isinstance(payload.get("data"), list):
        services = payload["data"]
    elif isinstance(payload.get("data"), dict) and isinstance(payload["data"].get("services"), list):
        services = payload["data"]["services"]
    else:
        services = []
elif isinstance(payload, list):
    services = payload
else:
    services = []

for svc in services:
    if not isinstance(svc, dict):
        continue
    spec = svc.get("spec")
    if isinstance(spec, dict) and spec.get("name") == name:
        sid = svc.get("id")
        if isinstance(sid, str) and sid:
            sys.stdout.write(sid)
            break
PY
}

upsert_service() {
  token="$1"
  py="$2"
  work_dir="$(mktemp -d "${TMPDIR:-/tmp}/pi-web-sm.XXXXXX")" || return 1
  curl_cfg="$work_dir/curl.cfg"
  services_file="$work_dir/services.json"
  printf 'header = "Authorization: Bearer %s"\n' "$token" > "$curl_cfg"
  printf 'header = "Content-Type: application/json"\n' >> "$curl_cfg"

  services_json="$(curl -q -fsS --max-time 5 -K "$curl_cfg" "${SM_URL%/}/api/v1/services" 2>/dev/null || true)"
  printf '%s' "$services_json" > "$services_file"
  service_id="$(service_name_to_id "$py" "$services_file" 2>/dev/null || true)"

  if [ -n "$service_id" ]; then
    log "service-manager: updating $SERVICE_NAME ($service_id)"
    curl -q -fsS --max-time 10 -X PUT -K "$curl_cfg" --data-binary "@$SPEC_PATH" "${SM_URL%/}/api/v1/services/$service_id" >/dev/null 2>&1 || warn "service-manager update failed: $SERVICE_NAME"
    curl -q -fsS --max-time 5 -X POST -K "$curl_cfg" "${SM_URL%/}/api/v1/services/$service_id/register" >/dev/null 2>&1 || true
  else
    log "service-manager: creating $SERVICE_NAME"
    create_resp="$(curl -q -fsS --max-time 10 -X POST -K "$curl_cfg" --data-binary "@$SPEC_PATH" "${SM_URL%/}/api/v1/services" 2>/dev/null || true)"
    created_id="$(printf '%s' "$create_resp" | "$py" -c 'import json,sys; p=json.loads(sys.stdin.read() or "{}"); print(p.get("id","") if isinstance(p,dict) else "")' 2>/dev/null || true)"
    [ -z "$created_id" ] || curl -q -fsS --max-time 5 -X POST -K "$curl_cfg" "${SM_URL%/}/api/v1/services/$created_id/register" >/dev/null 2>&1 || true
  fi

  rm -rf "$work_dir"
}

main() {
  write_spec
  write_component
  log "wrote service registry: $SPEC_PATH"
  log "wrote component registry: $COMPONENT_PATH"

  have curl || {
    warn "curl not found; service registry file will be loaded on next service-manager restart"
    exit 0
  }
  curl -fsS --max-time 2 "${SM_URL%/}/api/v1/health" >/dev/null 2>&1 || {
    warn "service-manager is not reachable at $SM_URL; registry file will be loaded on next restart"
    exit 0
  }

  token="$(resolve_token)"
  [ -n "$token" ] || {
    warn "service-manager token not available; registry file will be loaded on next restart"
    exit 0
  }

  if have python3; then
    py=python3
  elif have python; then
    py=python
  else
    warn "python not found; registry file will be loaded on next service-manager restart"
    exit 0
  fi

  upsert_service "$token" "$py" || warn "service-manager upsert failed: $SERVICE_NAME"
  log "done"
}

main "$@"
