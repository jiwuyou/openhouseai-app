#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }
die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

SCRIPT_DIR=$(CDPATH= cd "$(dirname "$0")" && pwd)
ROOT_DIR=$(CDPATH= cd "$SCRIPT_DIR/.." && pwd)
PI_AGENT_DIR="${PI_CODING_AGENT_DIR:-/root/.pi}"
GLOBAL_PREFIX="${NPM_CONFIG_PREFIX:-/root/.npm-global}"
LOCAL_BIN="/root/.local/bin"

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"
}

node_version_ok() {
  node -e '
const [major, minor] = process.versions.node.split(".").map(Number);
process.exit(major > 22 || (major === 22 && minor >= 19) ? 0 : 1);
' >/dev/null 2>&1
}

find_package() {
  find "$ROOT_DIR/packages" -maxdepth 1 -type f -name 'agegr-pi-web-*.tgz' | sort | tail -n 1
}

install_bundled_pi_dependencies() {
  set -- "$ROOT_DIR"/../pi-agent/packages/*.tgz
  if [ "$#" -gt 0 ] && [ -f "$1" ]; then
    package_names=""
    for pkg in "$@"; do
      package_names="$package_names $(basename "$pkg")"
    done
    log "install: pi-web bundled pi dependencies:$package_names"
    npm install -g --ignore-scripts "$@"
  fi
}

install_pi_web() {
  pkg="$(find_package || true)"
  mkdir -p "$GLOBAL_PREFIX/bin"
  npm config set prefix "$GLOBAL_PREFIX" >/dev/null
  npm config set registry "${NPM_REGISTRY:-https://registry.npmjs.org/}" >/dev/null

  install_bundled_pi_dependencies

  if [ -n "$pkg" ]; then
    log "install: pi-web from bundled npm package $(basename "$pkg")"
    npm install -g --ignore-scripts "$pkg"
  else
    version="${OPENHOUSE_PI_WEB_VERSION:-0.7.0}"
    warn "Bundled pi-web package is missing; falling back to npm registry @agegr/pi-web@$version"
    npm install -g --ignore-scripts "@agegr/pi-web@$version"
  fi
}

install_wrappers() {
  mkdir -p "$LOCAL_BIN"
  install -m 755 "$ROOT_DIR/bin/openhouse-pi-web-start" "$LOCAL_BIN/openhouse-pi-web-start"
}

main() {
  require_cmd node
  require_cmd npm
  node_version_ok || die "Node >= 22.19 is required for pi-web/pi. Found: $(node -v 2>/dev/null || printf unknown)"

  mkdir -p "$PI_AGENT_DIR" "$PI_AGENT_DIR/extensions" "$PI_AGENT_DIR/agent/extensions" "$HOME/workspace"
  install_pi_web
  install_wrappers

  export PATH="$GLOBAL_PREFIX/bin:/root/.local/node/bin:$LOCAL_BIN:$PATH"
  [ -x "$LOCAL_BIN/openhouse-pi-web-start" ] || die "openhouse-pi-web-start was not installed"
  log "done: pi-web installed; default URL http://127.0.0.1:${PI_WEB_PORT:-30141}/"
}

main "$@"
