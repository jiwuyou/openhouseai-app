#!/data/data/com.termux/files/usr/bin/sh
set -eu
root=$(CDPATH= cd "$(dirname "$0")" && pwd)
"$root/scripts/install.sh"
"$root/scripts/register-service.sh"
