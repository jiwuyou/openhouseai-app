#!/data/data/com.termux/files/usr/bin/sh
set -eu
: "${HOME:?HOME is required}"
root=$(CDPATH= cd "$(dirname "$0")/.." && pwd)
command -v zstd >/dev/null
WUXIANPI_INSTALL_ROOT="${WUXIANPI_INSTALL_ROOT:-$HOME/.local/share/wuxianpi}" \
  "$root/scripts/install-release.sh" "$root"
