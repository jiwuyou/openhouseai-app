#!/data/data/com.termux/files/usr/bin/sh
set -eu
: "${HOME:?HOME is required}"
product_root=${WUXIANPI_INSTALL_ROOT:-$HOME/.local/share/wuxianpi}
command -v node >/dev/null
command -v zstd >/dev/null
test -x "$HOME/.local/bin/wuxianpi"
test -x "$HOME/.local/bin/wuxianpi-node"
test -x "$HOME/.local/bin/wuxianpi-node-start"
test -s "$product_root/runtime/dist/index.js"
test -s "$product_root/runtime/builtin-packages/task-manager/wuxianpi-package.json"
test -s "$product_root/web/index.html"
test -s "$product_root/base/node_modules/@earendil-works/pi-coding-agent/package.json"
node -e 'const p=require(process.argv[1]);if(p.version!=="0.80.10")process.exit(1)' \
  "$product_root/base/node_modules/@earendil-works/pi-coding-agent/package.json"
printf 'ok: official WuxianPi ARM64 release is installed\n'
