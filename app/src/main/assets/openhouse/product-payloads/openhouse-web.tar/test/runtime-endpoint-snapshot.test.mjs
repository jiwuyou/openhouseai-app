import assert from 'node:assert/strict';
import { mkdtemp, writeFile, utimes } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

import { RuntimeEndpointSnapshot, normalizeLoopbackUrl } from '../src/runtime-endpoint-snapshot.mjs';

function document(url = 'http://127.0.0.1:24001/') {
  return {
    schemaVersion: 1,
    state: 'ready',
    managerInstanceId: 'test-manager',
    snapshotRevision: 7,
    portStateGeneration: 7,
    generatedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 60_000).toISOString(),
    endpoints: [{ serviceId: 'smallphone-frontend-beta', name: 'web', url }],
  };
}

test('resolves ready dynamic endpoint and rejects static or non-loopback URLs', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'openhouse-endpoints-'));
  const file = path.join(dir, 'endpoints.json');
  await writeFile(file, JSON.stringify(document()), 'utf8');
  const reader = new RuntimeEndpointSnapshot(file);
  const endpoint = await reader.resolve('smallphone-frontend-beta', 'web');
  assert.equal(endpoint.url, 'http://127.0.0.1:24001/');
  assert.equal(await reader.resolve('smallphone-core', 'api'), null);

  await writeFile(file, JSON.stringify(document('http://example.com:24001/')), 'utf8');
  await utimes(file, new Date(), new Date(Date.now() + 1000));
  assert.equal(await reader.resolve('smallphone-frontend-beta', 'web'), null);
});

test('expired or malformed snapshot returns unknown without fixed fallback', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'openhouse-endpoints-'));
  const file = path.join(dir, 'endpoints.json');
  const expired = document('http://127.0.0.1:22082/');
  expired.expiresAt = new Date(Date.now() - 1000).toISOString();
  await writeFile(file, JSON.stringify(expired), 'utf8');
  const reader = new RuntimeEndpointSnapshot(file);
  assert.equal(await reader.resolve('smallphone-frontend-beta', 'web'), null);
  await writeFile(file, JSON.stringify({ schemaVersion: 99, state: 'ready' }), 'utf8');
  assert.equal(await reader.resolve('smallphone-frontend-beta', 'web'), null);
});

test('URL sanitizer rejects credentials and query strings', () => {
  assert.equal(normalizeLoopbackUrl('http://127.0.0.1:24000/api'), 'http://127.0.0.1:24000/api');
  assert.equal(normalizeLoopbackUrl('http://user:secret@127.0.0.1:24000/'), '');
  assert.equal(normalizeLoopbackUrl('http://127.0.0.1:24000/?token=secret'), '');
});
