import { readFile, stat } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

export const ENDPOINT_SNAPSHOT_SCHEMA_VERSION = 1;
export const DEFAULT_ENDPOINT_SNAPSHOT_PATH = path.join(
  process.env.HOME || os.homedir(),
  '.config',
  'openhouseai',
  'runtime',
  'endpoints.json',
);

function validId(value) {
  return /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(String(value || ''));
}

export function normalizeLoopbackUrl(value) {
  try {
    const url = new URL(String(value || '').trim());
    if (url.protocol !== 'http:'
      || !['127.0.0.1', 'localhost', '::1', '[::1]'].includes(url.hostname)
      || !url.port
      || url.username
      || url.password
      || url.search
      || url.hash) return '';
    return url.href;
  } catch {
    return '';
  }
}

function parseSnapshot(value, now) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('endpoint snapshot must be an object');
  if (value.schemaVersion !== ENDPOINT_SNAPSHOT_SCHEMA_VERSION) throw new Error('unsupported endpoint snapshot schema');
  if (value.state !== 'ready') throw new Error('endpoint snapshot is not ready');
  if (!String(value.managerInstanceId || '').trim()) throw new Error('endpoint snapshot managerInstanceId is missing');
  if (!Number.isInteger(value.snapshotRevision) || value.snapshotRevision < 0) throw new Error('endpoint snapshot revision is invalid');
  if (!Number.isInteger(value.portStateGeneration) || value.portStateGeneration < 0) throw new Error('endpoint port state generation is invalid');
  if (!Number.isFinite(Date.parse(value.generatedAt))) throw new Error('endpoint snapshot generatedAt is invalid');
  const expiresAt = Date.parse(value.expiresAt);
  if (!Number.isFinite(expiresAt) || expiresAt <= now()) throw new Error('endpoint snapshot expired');
  if (!Array.isArray(value.endpoints)) throw new Error('endpoint snapshot endpoints is invalid');

  const endpoints = new Map();
  for (const raw of value.endpoints) {
    const serviceId = String(raw?.serviceId || '').trim();
    const name = String(raw?.name || '').trim();
    if (!validId(serviceId) || !validId(name)) throw new Error('endpoint serviceId/name is invalid');
    if (raw?.state && raw.state !== 'ready') continue;
    const url = normalizeLoopbackUrl(raw?.url);
    if (!url) throw new Error('endpoint URL is not a loopback HTTP URL');
    endpoints.set(`${serviceId}\0${name}`, Object.freeze({
      serviceId,
      name,
      url,
      host: String(raw?.host || '').trim(),
      port: Number.isInteger(raw?.port) ? raw.port : Number(new URL(url).port),
      protocol: String(raw?.protocol || '').trim(),
      generation: Number.isInteger(raw?.generation) ? raw.generation : value.portStateGeneration,
      publishedAt: String(raw?.publishedAt || ''),
      state: 'ready',
    }));
  }
  return Object.freeze({
    snapshotRevision: value.snapshotRevision,
    portStateGeneration: value.portStateGeneration,
    expiresAt,
    endpoints,
  });
}

export class RuntimeEndpointSnapshot {
  constructor(filePath = DEFAULT_ENDPOINT_SNAPSHOT_PATH, options = {}) {
    this.filePath = filePath || DEFAULT_ENDPOINT_SNAPSHOT_PATH;
    this.readFile = options.readFile || readFile;
    this.stat = options.stat || stat;
    this.now = options.now || Date.now;
    this.cached = null;
    this.cachedMtimeMs = -1;
    this.cachedSize = -1;
  }

  invalidate() {
    this.cached = null;
    this.cachedMtimeMs = -1;
    this.cachedSize = -1;
  }

  async load() {
    let info;
    try {
      info = await this.stat(this.filePath);
    } catch {
      this.invalidate();
      return null;
    }
    if (this.cached && this.cachedMtimeMs === info.mtimeMs && this.cachedSize === info.size) {
      if (this.cached.expiresAt > this.now()) return this.cached;
      this.invalidate();
      return null;
    }
    try {
      const snapshot = parseSnapshot(JSON.parse(await this.readFile(this.filePath, 'utf8')), this.now);
      this.cached = snapshot;
      this.cachedMtimeMs = info.mtimeMs;
      this.cachedSize = info.size;
      return snapshot;
    } catch {
      this.invalidate();
      return null;
    }
  }

  async resolve(serviceId, endpointName) {
    if (!validId(serviceId) || !validId(endpointName)) return null;
    const snapshot = await this.load();
    return snapshot?.endpoints.get(`${serviceId}\0${endpointName}`) || null;
  }

  async list(serviceId) {
    if (!validId(serviceId)) return { serviceId, state: 'unknown', snapshotRevision: 0, endpoints: [] };
    const snapshot = await this.load();
    if (!snapshot) return { serviceId, state: 'unknown', snapshotRevision: 0, endpoints: [] };
    return {
      serviceId,
      state: 'ready',
      snapshotRevision: snapshot.snapshotRevision,
      generation: snapshot.portStateGeneration,
      endpoints: [...snapshot.endpoints.values()].filter((endpoint) => endpoint.serviceId === serviceId),
    };
  }
}
