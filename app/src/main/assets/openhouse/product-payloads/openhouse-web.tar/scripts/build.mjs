import { cp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dist = path.join(root, 'dist');
await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });
for (const directory of ['src', 'public', 'config']) {
  await cp(path.join(root, directory), path.join(dist, directory), { recursive: true });
}
for (const file of ['README.md', 'package.json']) await cp(path.join(root, file), path.join(dist, file));
const pkg = JSON.parse(await readFile(path.join(dist, 'package.json'), 'utf8'));
delete pkg.scripts.check;
delete pkg.scripts.test;
delete pkg.scripts.integration;
delete pkg.scripts['test:integration'];
pkg.scripts.start = 'node src/server.mjs';
await writeFile(path.join(dist, 'package.json'), `${JSON.stringify(pkg, null, 2)}\n`);
console.log(`runtime built at ${dist}`);
