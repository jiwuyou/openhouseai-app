#!/usr/bin/env bash
set -euo pipefail

BIN_NAME="service-manager"

usage() {
  cat <<'EOF'
Usage:
  scripts/build-release.sh

Builds:
  - cargo build --release
  - dist/service-manager-<platform>.tar.gz

Platform:
  - Linux/macOS: service-manager-<version>-<os>-<arch>.tar.gz
  - Termux:      service-manager-<version>-termux-<arch>.tar.gz

Includes:
  - service-manager binary
  - scripts/
  - README.md
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

script_dir="$(CDPATH='' cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(CDPATH='' cd -- "${script_dir}/.." && pwd)"

cd "${repo_root}"

version="$(grep -E '^version = "' Cargo.toml | head -n1 | sed -E 's/^version = "([^"]+)".*$/\1/')"
if [[ -z "${version}" ]]; then
  echo "error: failed to read version from Cargo.toml" >&2
  exit 1
fi

os="$(uname -s | tr '[:upper:]' '[:lower:]')"
arch="$(uname -m)"
platform_os="${os}"
if [[ -n "${PREFIX:-}" && "${PREFIX}" == *"com.termux"* ]]; then
  platform_os="termux"
fi

rewrite_termux_script_shebangs() {
  local scripts_dir="$1"
  local termux_shebang='#!/data/data/com.termux/files/usr/bin/env bash'
  local script first_line tmp mode

  while IFS= read -r -d '' script; do
    first_line=""
    IFS= read -r first_line < "${script}" || true
    if [[ "${first_line}" != '#!/usr/bin/env bash' ]]; then
      continue
    fi

    tmp="${script}.tmp.$$"
    {
      printf '%s\n' "${termux_shebang}"
      tail -n +2 "${script}"
    } > "${tmp}"

    mode="$(stat -c '%a' "${script}" 2>/dev/null || stat -f '%Lp' "${script}" 2>/dev/null || true)"
    if [[ -n "${mode}" ]]; then
      chmod "${mode}" "${tmp}"
    else
      chmod +x "${tmp}"
    fi
    mv "${tmp}" "${script}"
    echo "rewrote Termux script shebang: ${script#${scripts_dir}/}"
  done < <(find "${scripts_dir}" -maxdepth 1 -type f -name '*.sh' -print0)
}

echo "building (${platform_os}/${arch})..."
cargo build --release

bin_path="${repo_root}/target/release/${BIN_NAME}"
if [[ ! -x "${bin_path}" ]]; then
  echo "error: missing built binary: ${bin_path}" >&2
  exit 1
fi

if ! version_output="$("${bin_path}" --version 2>&1)"; then
  echo "error: built binary cannot run in this environment: ${bin_path}" >&2
  echo "       attempted: ${bin_path} --version" >&2
  if [[ -n "${version_output}" ]]; then
    echo "       output:" >&2
    printf '%s\n' "${version_output}" | sed 's/^/         /' >&2
  fi
  if [[ "${platform_os}" == "termux" ]]; then
    echo "hint: Termux release packages must contain an Android/bionic executable built in Termux or with an Android target." >&2
    echo "      Do not package a Linux glibc/proot binary as a termux asset." >&2
  fi
  exit 1
fi
echo "verified: ${version_output}"

dist="${repo_root}/dist"
mkdir -p "${dist}"

pkg_dir="${dist}/${BIN_NAME}-${version}-${platform_os}-${arch}"
rm -rf "${pkg_dir}"
mkdir -p "${pkg_dir}"

cp "${bin_path}" "${pkg_dir}/${BIN_NAME}"
cp -R "${repo_root}/scripts" "${pkg_dir}/scripts"
if [[ "${platform_os}" == "termux" ]]; then
  rewrite_termux_script_shebangs "${pkg_dir}/scripts"
fi
cp "${repo_root}/README.md" "${pkg_dir}/README.md"

tarball="${pkg_dir}.tar.gz"
rm -f "${tarball}"
tar -czf "${tarball}" -C "${dist}" "$(basename -- "${pkg_dir}")"

echo "wrote: ${tarball}"
