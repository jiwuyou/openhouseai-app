#!/usr/bin/env sh
set -eu

APP_DIR="/root/projects/service-manager"
BIND_ADDR="127.0.0.1:20087"
URL="http://${BIND_ADDR}/"
LOG_FILE="/tmp/service-manager-20087.log"
OPENHOUSE_CONFIG="$HOME/.config/openhouseai/service-manager/config.json"

cd "$APP_DIR"

if ! curl -fsS "$URL" >/dev/null 2>&1; then
  if [ -f "$OPENHOUSE_CONFIG" ]; then
    nohup "$APP_DIR/target/debug/service-manager" serve --config "$OPENHOUSE_CONFIG" --bind "$BIND_ADDR" >"$LOG_FILE" 2>&1 &
  else
    nohup "$APP_DIR/target/debug/service-manager" serve --bind "$BIND_ADDR" >"$LOG_FILE" 2>&1 &
  fi
  sleep 1
fi

if [ -f "$OPENHOUSE_CONFIG" ]; then
  TOKEN="$($APP_DIR/target/debug/service-manager token show --config "$OPENHOUSE_CONFIG" 2>/dev/null | sed -n '1p')"
else
  TOKEN="$($APP_DIR/target/debug/service-manager token show 2>/dev/null | sed -n '1p')"
fi
TICKET_JSON="$(curl -fsS -X POST -H "Authorization: Bearer $TOKEN" \
  "http://${BIND_ADDR}/api/v1/web-session-tickets")"
SESSION_PATH="$(printf '%s' "$TICKET_JSON" | sed -n 's/.*"path":"\([^"]*\)".*/\1/p')"
if [ -z "$SESSION_PATH" ]; then
  echo "failed to create one-time Web session" >&2
  exit 1
fi

unset TOKEN TICKET_JSON
exec google-chrome-stable "http://${BIND_ADDR}${SESSION_PATH}"
