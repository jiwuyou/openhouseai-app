# OpenHouse Production Service Declarations

These registry documents target `service-manager` 0.2.0 running natively in
Termux. Install them into the configured `service_registry_dir` as part of
OpenHouse runtime provisioning.

## Runtime assumptions

- `pi-web` is globally available at
  `/data/data/com.termux/files/usr/bin/pi-web` and keeps its production runtime
  data under `/data/data/com.termux/files/home`.
- AionUi 2.1.32 or a compatible release is available inside the Ubuntu distro
  at `/opt/aionui-web/aionui-web`. Its persistent data remains in
  `/root/.aionui-web`.
- The manager config defines the `local-web` port pool. Both services prefer
  their historical ports but may receive another free port from that pool.

The allocated `web` port is materialized into the command, environment and
health check. Consumers must resolve the published endpoint by service ID
instead of caching `30141` or `25808` as permanent addresses.

## Stable IDs

- Pi Web: `pi-web`
- AionUi: `aionui-web`

The production `aionui-web` identity is deliberately stable so upper-layer
references always resolve the same service. Components should use
`service-manager://services/aionui-web`; declarations using alternate AionUi
IDs can create independently managed duplicate instances.

## Health behavior

Pi Web publishes its endpoint after `/` returns a successful HTTP status.
AionUi must use `/health`; probing its root route during startup can trigger
runtime preparation and transiently withdraw an otherwise healthy endpoint.
