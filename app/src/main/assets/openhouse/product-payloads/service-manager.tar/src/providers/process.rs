use std::{
    collections::HashMap,
    fs,
    io::{Read, Write},
    path::{Path, PathBuf},
    process::Stdio,
    sync::{Mutex, OnceLock},
    time::{Duration, SystemTime},
};

static PROCESS_MONITORS: OnceLock<Mutex<HashMap<String, tokio::task::AbortHandle>>> =
    OnceLock::new();

#[cfg(unix)]
use std::os::unix::process::CommandExt;

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use tokio::time::sleep;

use crate::{
    error::Result,
    model::{
        Capability, DetectResult, LogEntry, LogsOptions, Provider, ProviderId, Service,
        ServiceState, ServiceStatus,
    },
};

use super::{bad_request, find_in_path, lossy_stderr, run_command_output};

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
struct ProcMetaV1 {
    version: u32,
    provider: String,
    service_id: String,
    boot_id: String,
    pid: u32,
    pgid: i32,
    exe: String,
    argv: Vec<String>,
    proc_starttime_ticks: u64,
    created_at: DateTime<Utc>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
struct ObservedProcessIdentity {
    boot_id: String,
    starttime_ticks: u64,
    pgid: i32,
    exe: String,
}

#[derive(Clone, Debug)]
enum ProcVerify {
    Managed,
    Stale(String),
    Unverifiable(String),
}

#[derive(Clone, Debug)]
pub struct ProcessProvider {
    data_dir: PathBuf,
}

impl ProcessProvider {
    pub fn new(data_dir: PathBuf) -> Self {
        Self { data_dir }
    }

    fn state_dir(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self
            .data_dir
            .clone()
            .join("providers")
            .join("process")
            .join(&svc.id.0))
    }

    fn pid_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("pid"))
    }

    fn started_at_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("started_at"))
    }

    fn stdout_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("stdout.log"))
    }

    fn stderr_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("stderr.log"))
    }

    fn meta_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("meta.json"))
    }

    fn orphan_meta_path(&self, svc: &Service) -> Result<PathBuf> {
        Ok(self.state_dir(svc)?.join("orphan-meta.json"))
    }

    fn started_at_path_or(&self, svc: &Service) -> Result<PathBuf> {
        self.started_at_path(svc)
    }

    fn ensure_dirs(&self, svc: &Service) -> Result<()> {
        let dir = self.state_dir(svc)?;
        fs::create_dir_all(&dir)?;
        Ok(())
    }

    fn read_pid(path: &Path) -> Result<Option<u32>> {
        let mut f = match fs::File::open(path) {
            Ok(f) => f,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Err(e) => return Err(crate::error::AppError::Io(e)),
        };
        let mut s = String::new();
        f.read_to_string(&mut s)?;
        let s = s.trim();
        if s.is_empty() {
            return Ok(None);
        }
        let pid: u32 = s
            .parse()
            .map_err(|_| bad_request(format!("invalid pid file contents: {s:?}")))?;
        Ok(Some(pid))
    }

    fn write_pid(path: &Path, pid: u32) -> Result<()> {
        let mut f = fs::File::create(path)?;
        writeln!(f, "{pid}")?;
        Ok(())
    }

    fn write_started_at(path: &Path, t: DateTime<Utc>) -> Result<()> {
        let mut f = fs::File::create(path)?;
        writeln!(f, "{}", t.to_rfc3339())?;
        Ok(())
    }

    fn read_started_at(path: &Path) -> Result<Option<DateTime<Utc>>> {
        let mut f = match fs::File::open(path) {
            Ok(f) => f,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Err(e) => return Err(crate::error::AppError::Io(e)),
        };
        let mut s = String::new();
        f.read_to_string(&mut s)?;
        let s = s.trim();
        if s.is_empty() {
            return Ok(None);
        }
        let dt = DateTime::parse_from_rfc3339(s)
            .map_err(|e| bad_request(format!("invalid started_at file: {e}")))?
            .with_timezone(&Utc);
        Ok(Some(dt))
    }

    async fn pid_is_alive(&self, pid: u32) -> Result<bool> {
        #[cfg(unix)]
        {
            Ok(Self::proc_state_and_pgrp(pid).is_some_and(|(state, _)| state != 'Z'))
        }
        #[cfg(not(unix))]
        {
            let _ = pid;
            Ok(false)
        }
    }

    async fn process_group_is_alive(&self, pgid: i32) -> Result<bool> {
        #[cfg(unix)]
        {
            let Ok(entries) = fs::read_dir(Self::proc_root()) else {
                return Ok(false);
            };
            for entry in entries.flatten() {
                let Some(name) = entry.file_name().to_str().map(str::to_string) else {
                    continue;
                };
                let Ok(pid) = name.parse::<u32>() else {
                    continue;
                };
                if Self::proc_state_and_pgrp(pid)
                    .is_some_and(|(state, observed_pgid)| state != 'Z' && observed_pgid == pgid)
                {
                    return Ok(true);
                }
            }
            Ok(false)
        }
        #[cfg(not(unix))]
        {
            let _ = pgid;
            Ok(false)
        }
    }

    async fn signal_process_group(&self, pgid: i32, signal: &str) -> Result<()> {
        #[cfg(unix)]
        {
            let out = run_command_output(
                "kill".to_string(),
                vec![signal.to_string(), "--".to_string(), format!("-{pgid}")],
            )
            .await?;
            if !out.status.success() && self.process_group_is_alive(pgid).await.unwrap_or(true) {
                return Err(bad_request(format!(
                    "kill {signal} -- -{pgid} failed: {}",
                    lossy_stderr(&out)
                )));
            }
            Ok(())
        }
        #[cfg(not(unix))]
        {
            let _ = (pgid, signal);
            Err(bad_request("process provider is only supported on unix"))
        }
    }

    async fn wait_for_process_group_exit(&self, pgid: i32, timeout: Duration) -> Result<bool> {
        #[cfg(unix)]
        {
            let deadline = tokio::time::Instant::now() + timeout;
            loop {
                if !self.process_group_is_alive(pgid).await.unwrap_or(false) {
                    return Ok(true);
                }
                if tokio::time::Instant::now() >= deadline {
                    return Ok(false);
                }
                sleep(Duration::from_millis(50)).await;
            }
        }
        #[cfg(not(unix))]
        {
            let _ = (pgid, timeout);
            Ok(false)
        }
    }

    async fn terminate_process_group_with_timeouts(
        &self,
        pgid: i32,
        term_timeout: Duration,
        kill_timeout: Duration,
    ) -> Result<()> {
        if !self.process_group_is_alive(pgid).await? {
            return Ok(());
        }
        self.signal_process_group(pgid, "-TERM").await?;
        if self.wait_for_process_group_exit(pgid, term_timeout).await? {
            return Ok(());
        }
        self.signal_process_group(pgid, "-KILL").await?;
        if self.wait_for_process_group_exit(pgid, kill_timeout).await? {
            return Ok(());
        }
        Err(bad_request(format!(
            "process group remains alive after SIGTERM and SIGKILL: pgid={pgid}"
        )))
    }

    async fn terminate_process_group(&self, pgid: i32) -> Result<()> {
        self.terminate_process_group_with_timeouts(
            pgid,
            Duration::from_secs(5),
            Duration::from_secs(2),
        )
        .await
    }

    fn slice_log_lines(s: &str, limit: Option<usize>) -> Vec<&str> {
        let mut lines: Vec<&str> = s.lines().collect();
        if let Some(n) = limit
            && lines.len() > n
        {
            lines = lines[lines.len() - n..].to_vec();
        }
        lines
    }

    fn proc_root() -> PathBuf {
        // Test hook: allow overriding procfs root so unit tests can provide fixture files.
        if let Ok(v) = std::env::var("SERVICE_MANAGER_PROCFS_ROOT") {
            let v = v.trim().to_string();
            if !v.is_empty() {
                return PathBuf::from(v);
            }
        }
        PathBuf::from("/proc")
    }

    fn proc_stat_starttime_from_str(s: &str) -> Option<u64> {
        // /proc/<pid>/stat has a tricky format due to `comm` in parentheses. We locate the last
        // ')' and parse tokens after it. `starttime` is field 22 overall, i.e. token 19 after comm.
        let end = s.rfind(')')?;
        let after = s[end + 1..].trim();
        let mut it = after.split_whitespace();
        let _state = it.next()?;
        for _ in 0..18 {
            it.next()?;
        }
        it.next()?.parse::<u64>().ok()
    }

    fn proc_stat_state_pgrp_from_str(s: &str) -> Option<(char, i32)> {
        let end = s.rfind(')')?;
        let after = s[end + 1..].trim();
        let mut it = after.split_whitespace();
        let state = it.next()?.chars().next()?;
        let _ppid = it.next()?;
        let pgrp = it.next()?.parse::<i32>().ok()?;
        Some((state, pgrp))
    }

    fn proc_starttime_ticks(pid: u32) -> Option<u64> {
        let p = Self::proc_root().join(pid.to_string()).join("stat");
        let s = fs::read_to_string(p).ok()?;
        Self::proc_stat_starttime_from_str(&s)
    }

    fn proc_state_and_pgrp(pid: u32) -> Option<(char, i32)> {
        let p = Self::proc_root().join(pid.to_string()).join("stat");
        let s = fs::read_to_string(p).ok()?;
        Self::proc_stat_state_pgrp_from_str(&s)
    }

    fn proc_pgrp(pid: u32) -> Option<i32> {
        Self::proc_state_and_pgrp(pid).map(|(_, pgrp)| pgrp)
    }

    fn proc_boot_id() -> Option<String> {
        let path = Self::proc_root()
            .join("sys")
            .join("kernel")
            .join("random")
            .join("boot_id");
        let boot_id = fs::read_to_string(path).ok()?;
        let boot_id = boot_id.trim();
        if boot_id.is_empty() {
            None
        } else {
            Some(boot_id.to_string())
        }
    }

    fn proc_exe(pid: u32) -> Option<String> {
        let path = Self::proc_root().join(pid.to_string()).join("exe");
        fs::canonicalize(&path)
            .or_else(|_| fs::read_link(&path))
            .ok()
            .map(|value| value.to_string_lossy().to_string())
    }

    fn proc_cmdline(pid: u32) -> Option<Vec<String>> {
        let p = Self::proc_root().join(pid.to_string()).join("cmdline");
        let b = fs::read(p).ok()?;
        Self::parse_proc_cmdline(&b)
    }

    fn parse_proc_cmdline(b: &[u8]) -> Option<Vec<String>> {
        if b.is_empty() {
            return None;
        }
        let mut out = Vec::new();
        for part in b.split(|c| *c == 0u8) {
            if part.is_empty() {
                continue;
            }
            out.push(String::from_utf8_lossy(part).to_string());
        }
        if out.is_empty() { None } else { Some(out) }
    }

    fn observe_process_argv(pid: u32, fallback: &[String]) -> Vec<String> {
        for _ in 0..20 {
            if let Some(argv) = Self::proc_cmdline(pid) {
                return argv;
            }
            std::thread::sleep(Duration::from_millis(25));
        }
        fallback.to_vec()
    }

    fn observe_process_identity(pid: u32) -> Option<ObservedProcessIdentity> {
        let boot_id = Self::proc_boot_id()?;
        let mut previous: Option<ObservedProcessIdentity> = None;
        for _ in 0..40 {
            let current = match (
                Self::proc_starttime_ticks(pid),
                Self::proc_pgrp(pid),
                Self::proc_exe(pid),
            ) {
                (Some(starttime_ticks), Some(pgid), Some(exe)) => ObservedProcessIdentity {
                    boot_id: boot_id.clone(),
                    starttime_ticks,
                    pgid,
                    exe,
                },
                _ => {
                    std::thread::sleep(Duration::from_millis(25));
                    continue;
                }
            };
            if previous.as_ref() == Some(&current) {
                return Some(current);
            }
            previous = Some(current);
            std::thread::sleep(Duration::from_millis(25));
        }
        None
    }

    fn read_meta(path: &Path) -> Option<ProcMetaV1> {
        let b = fs::read(path).ok()?;
        serde_json::from_slice::<ProcMetaV1>(&b).ok()
    }

    fn read_meta_with_fallback(meta_path: &Path, orphan_meta_path: &Path) -> Option<ProcMetaV1> {
        Self::read_meta(meta_path).or_else(|| Self::read_meta(orphan_meta_path))
    }

    fn write_meta(path: &Path, meta: &ProcMetaV1) -> Result<()> {
        let b = serde_json::to_vec_pretty(meta).map_err(crate::error::AppError::Json)?;
        fs::write(path, b)?;
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    fn verify_pid_with_obs(
        svc: &Service,
        pid: u32,
        meta: Option<&ProcMetaV1>,
        boot_id: Option<String>,
        start: Option<u64>,
        pgrp: Option<i32>,
        exe: Option<String>,
        cmdline: Option<Vec<String>>,
    ) -> ProcVerify {
        let Some(meta) = meta else {
            // Newer builds always write meta; if missing, treat as unsafe (PID reuse risk).
            return ProcVerify::Unverifiable("missing meta.json".to_string());
        };

        if meta.pid != pid {
            return ProcVerify::Stale("pid mismatch".to_string());
        }
        if meta.provider != "process" {
            return ProcVerify::Stale(format!("provider mismatch: {}", meta.provider));
        }
        if meta.service_id != svc.id.0 {
            return ProcVerify::Stale("service_id mismatch".to_string());
        }

        match boot_id {
            Some(current) if current == meta.boot_id => {}
            Some(current) => {
                return ProcVerify::Stale(format!(
                    "boot_id mismatch: recorded {}, observed {current}",
                    meta.boot_id
                ));
            }
            None => {
                return ProcVerify::Unverifiable(
                    "boot_id unavailable; refusing to manage pid".to_string(),
                );
            }
        }

        // PID + starttime is the stable Linux identity. Process titles and /proc/cmdline may
        // legitimately change (Node/Next does this), so argv is only a diagnostic snapshot.
        match start {
            Some(observed) if meta.proc_starttime_ticks != observed => {
                return ProcVerify::Stale("proc starttime mismatch".to_string());
            }
            None => {
                return ProcVerify::Unverifiable(
                    "proc starttime unavailable; refusing to manage pid".to_string(),
                );
            }
            _ => {}
        }

        match pgrp {
            Some(actual_pgid) if actual_pgid == meta.pgid => {}
            Some(actual_pgid) => {
                return ProcVerify::Unverifiable(format!(
                    "process group changed: expected {}, observed {actual_pgid}",
                    meta.pgid
                ));
            }
            None => {
                return ProcVerify::Unverifiable(
                    "proc process group unavailable; refusing to manage pid".to_string(),
                );
            }
        }

        match exe {
            Some(actual_exe) if actual_exe == meta.exe => {}
            Some(actual_exe) => {
                return ProcVerify::Unverifiable(format!(
                    "executable identity mismatch: recorded {:?}, observed {:?}",
                    meta.exe, actual_exe
                ));
            }
            None => {
                return ProcVerify::Unverifiable(
                    "proc executable identity unavailable; refusing to manage pid".to_string(),
                );
            }
        }

        let _ = cmdline;

        ProcVerify::Managed
    }

    fn verify_pid(svc: &Service, pid: u32, meta: Option<&ProcMetaV1>) -> ProcVerify {
        let boot_id = Self::proc_boot_id();
        let start = Self::proc_starttime_ticks(pid);
        let pgrp = Self::proc_pgrp(pid);
        let exe = Self::proc_exe(pid);
        let cmdline = Self::proc_cmdline(pid);
        Self::verify_pid_with_obs(svc, pid, meta, boot_id, start, pgrp, exe, cmdline)
    }

    fn verify_runtime_identity(meta: &ProcMetaV1) -> ProcVerify {
        match Self::proc_boot_id() {
            Some(current) if current == meta.boot_id => {}
            Some(_) => return ProcVerify::Stale("boot_id mismatch".to_string()),
            None => {
                return ProcVerify::Unverifiable(
                    "boot_id unavailable; refusing to monitor process runtime".to_string(),
                );
            }
        }
        match Self::proc_starttime_ticks(meta.pid) {
            Some(current) if current == meta.proc_starttime_ticks => {}
            Some(_) => return ProcVerify::Stale("proc starttime mismatch".to_string()),
            None => {
                return ProcVerify::Unverifiable(
                    "proc starttime unavailable; refusing to monitor process runtime".to_string(),
                );
            }
        }
        match Self::proc_pgrp(meta.pid) {
            Some(current) if current == meta.pgid => {}
            Some(current) => {
                return ProcVerify::Unverifiable(format!(
                    "process group changed: expected {}, observed {current}",
                    meta.pgid
                ));
            }
            None => {
                return ProcVerify::Unverifiable(
                    "proc process group unavailable; refusing to monitor process runtime"
                        .to_string(),
                );
            }
        }
        match Self::proc_exe(meta.pid) {
            Some(current) if current == meta.exe => ProcVerify::Managed,
            Some(current) => ProcVerify::Unverifiable(format!(
                "executable identity mismatch: recorded {:?}, observed {:?}",
                meta.exe, current
            )),
            None => ProcVerify::Unverifiable(
                "proc executable identity unavailable; refusing to monitor process runtime"
                    .to_string(),
            ),
        }
    }

    async fn verify_dead_leader_group(&self, meta: Option<&ProcMetaV1>) -> ProcVerify {
        let Some(meta) = meta else {
            return ProcVerify::Unverifiable(
                "leader exited and process metadata is missing".to_string(),
            );
        };
        match Self::proc_boot_id() {
            Some(current) if current == meta.boot_id => {}
            Some(_) => return ProcVerify::Stale("boot_id mismatch".to_string()),
            None => {
                return ProcVerify::Unverifiable(
                    "boot_id unavailable while checking exited leader".to_string(),
                );
            }
        }
        if self.process_group_is_alive(meta.pgid).await.unwrap_or(true) {
            ProcVerify::Unverifiable(format!(
                "leader pid {} exited but process group {} remains alive (orphan)",
                meta.pid, meta.pgid
            ))
        } else {
            ProcVerify::Stale("leader and process group exited".to_string())
        }
    }

    fn cleanup_runtime_state(
        pid_path: &Path,
        meta_path: &Path,
        orphan_meta_path: &Path,
        started_at_path: &Path,
    ) {
        let _ = fs::remove_file(pid_path);
        let _ = fs::remove_file(meta_path);
        let _ = fs::remove_file(orphan_meta_path);
        let _ = fs::remove_file(started_at_path);
    }

    fn cleanup_runtime_state_if_matches(
        expected: &ProcMetaV1,
        pid_path: &Path,
        meta_path: &Path,
        orphan_meta_path: &Path,
        started_at_path: &Path,
    ) {
        let current = Self::read_meta_with_fallback(meta_path, orphan_meta_path);
        if current.as_ref() == Some(expected) {
            Self::cleanup_runtime_state(pid_path, meta_path, orphan_meta_path, started_at_path);
        }
    }

    fn append_reaper_error(stderr_path: &Path, message: &str) {
        if let Ok(mut file) = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(stderr_path)
        {
            let _ = writeln!(file, "[service-manager reaper] {message}");
        }
    }

    fn monitor_registry() -> &'static Mutex<HashMap<String, tokio::task::AbortHandle>> {
        PROCESS_MONITORS.get_or_init(|| Mutex::new(HashMap::new()))
    }

    fn monitor_key(meta_path: &Path, meta: &ProcMetaV1) -> String {
        format!(
            "{}:{}:{}:{}",
            meta_path.display(),
            meta.boot_id,
            meta.pid,
            meta.proc_starttime_ticks
        )
    }

    fn ensure_runtime_monitor(
        &self,
        meta: ProcMetaV1,
        pid_path: PathBuf,
        meta_path: PathBuf,
        orphan_meta_path: PathBuf,
        started_at_path: PathBuf,
        stderr_path: PathBuf,
    ) -> Result<()> {
        let key = Self::monitor_key(&meta_path, &meta);
        let mut registry = Self::monitor_registry()
            .lock()
            .map_err(|_| bad_request("process monitor registry lock poisoned"))?;
        registry.retain(|_, handle| !handle.is_finished());
        if registry.contains_key(&key) {
            return Ok(());
        }

        let provider = self.clone();
        let task = tokio::spawn(async move {
            loop {
                tokio::time::sleep(Duration::from_millis(100)).await;
                if provider.pid_is_alive(meta.pid).await.unwrap_or(false) {
                    match Self::verify_runtime_identity(&meta) {
                        ProcVerify::Managed => continue,
                        ProcVerify::Stale(reason) | ProcVerify::Unverifiable(reason) => {
                            Self::append_reaper_error(
                                &stderr_path,
                                &format!(
                                    "process runtime identity changed; metadata retained as orphan: {reason}"
                                ),
                            );
                            break;
                        }
                    }
                }
                match provider.terminate_process_group(meta.pgid).await {
                    Ok(()) => Self::cleanup_runtime_state_if_matches(
                        &meta,
                        &pid_path,
                        &meta_path,
                        &orphan_meta_path,
                        &started_at_path,
                    ),
                    Err(error) => Self::append_reaper_error(
                        &stderr_path,
                        &format!(
                            "unable to clean process group {}; metadata retained: {error}",
                            meta.pgid
                        ),
                    ),
                }
                break;
            }
        });
        registry.insert(key, task.abort_handle());
        Ok(())
    }
}

#[async_trait]
impl Provider for ProcessProvider {
    fn id(&self) -> ProviderId {
        ProviderId("process".to_string())
    }

    fn display_name(&self) -> String {
        "Raw process".to_string()
    }

    fn description(&self) -> String {
        "Spawn/stop a background OS process with PID+log files under the service-manager data dir."
            .to_string()
    }

    fn capabilities(&self) -> Vec<Capability> {
        vec![
            Capability::Register,
            Capability::Unregister,
            Capability::Start,
            Capability::Stop,
            Capability::Restart,
            Capability::Status,
            Capability::Logs,
        ]
    }

    async fn detect(&self) -> Result<DetectResult> {
        #[cfg(unix)]
        {
            // Soft check for `kill` availability; some environments can be weird.
            let kill = find_in_path("kill", &[]);
            if kill.is_none() {
                return Ok(DetectResult {
                    detected: false,
                    details: "missing `kill` in PATH".to_string(),
                });
            }
            Ok(DetectResult {
                detected: true,
                details: "ok".to_string(),
            })
        }
        #[cfg(not(unix))]
        {
            Ok(DetectResult {
                detected: false,
                details: "unsupported platform".to_string(),
            })
        }
    }

    async fn register(&self, svc: &Service) -> Result<()> {
        self.ensure_dirs(svc)?;
        Ok(())
    }

    async fn unregister(&self, svc: &Service) -> Result<()> {
        self.stop(svc).await?;
        let dir = self.state_dir(svc)?;
        let _ = fs::remove_dir_all(&dir);
        Ok(())
    }

    async fn start(&self, svc: &Service) -> Result<()> {
        if svc.spec.command.is_empty() {
            return Err(bad_request("command is required"));
        }
        self.ensure_dirs(svc)?;

        let pid_path = self.pid_path(svc)?;
        let meta_path = self.meta_path(svc)?;
        let orphan_meta_path = self.orphan_meta_path(svc)?;
        let started_at_path = self.started_at_path_or(svc)?;
        let existing_meta = Self::read_meta_with_fallback(&meta_path, &orphan_meta_path);
        let existing_pid =
            Self::read_pid(&pid_path)?.or_else(|| existing_meta.as_ref().map(|m| m.pid));
        if let Some(pid) = existing_pid {
            if !self.pid_is_alive(pid).await.unwrap_or(false) {
                match self.verify_dead_leader_group(existing_meta.as_ref()).await {
                    ProcVerify::Stale(_) => Self::cleanup_runtime_state(
                        &pid_path,
                        &meta_path,
                        &orphan_meta_path,
                        &started_at_path,
                    ),
                    ProcVerify::Unverifiable(reason) => {
                        return Err(bad_request(format!(
                            "refusing to start: previous leader is unavailable and its process group cannot be safely replaced: pid={pid} ({reason})"
                        )));
                    }
                    ProcVerify::Managed => unreachable!(),
                }
            } else {
                match Self::verify_pid(svc, pid, existing_meta.as_ref()) {
                    ProcVerify::Managed => {
                        let meta = existing_meta.clone().expect("managed process has metadata");
                        self.ensure_runtime_monitor(
                            meta,
                            pid_path.clone(),
                            meta_path.clone(),
                            orphan_meta_path.clone(),
                            started_at_path.clone(),
                            self.stderr_path(svc)?,
                        )?;
                        return Ok(());
                    }
                    ProcVerify::Stale(_) => Self::cleanup_runtime_state(
                        &pid_path,
                        &meta_path,
                        &orphan_meta_path,
                        &started_at_path,
                    ),
                    ProcVerify::Unverifiable(reason) => {
                        return Err(bad_request(format!(
                            "refusing to start: existing pidfile points to a live process but identity cannot be verified: pid={pid} ({reason})"
                        )));
                    }
                }
            }
        }

        // Always append to logs (service restarts should preserve history).
        let stdout = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(self.stdout_path(svc)?)?;
        let stderr = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(self.stderr_path(svc)?)?;

        let mut cmd = std::process::Command::new(&svc.spec.command[0]);
        if svc.spec.command.len() > 1 {
            cmd.args(&svc.spec.command[1..]);
        }
        if !svc.spec.working_dir.trim().is_empty() {
            cmd.current_dir(&svc.spec.working_dir);
        }
        for (k, v) in &svc.spec.env {
            cmd.env(k, v);
        }
        cmd.stdin(Stdio::null());
        cmd.stdout(Stdio::from(stdout));
        cmd.stderr(Stdio::from(stderr));

        #[cfg(unix)]
        {
            // Put the child in its own process group so we can stop the full subtree.
            cmd.process_group(0);
        }

        let mut child = cmd.spawn().map_err(|e| {
            bad_request(format!(
                "spawn {:?}: {e}",
                svc.spec.command.first().cloned().unwrap_or_default()
            ))
        })?;

        let pid = child.id();
        let Some(identity) = Self::observe_process_identity(pid) else {
            let rollback = self.terminate_process_group(pid as i32).await;
            if rollback.is_ok() {
                let _ = tokio::task::spawn_blocking(move || child.wait()).await;
            }
            return match rollback {
                Ok(()) => Err(bad_request(format!(
                    "spawned process identity is unavailable; process group rolled back: pid={pid}, pgid={pid}"
                ))),
                Err(rollback_error) => Err(bad_request(format!(
                    "spawned process identity is unavailable and rollback could not confirm process-group exit; manual cleanup required: pid={pid}, pgid={pid}: {rollback_error}"
                ))),
            };
        };
        if identity.pgid != pid as i32 {
            let rollback = self.terminate_process_group(identity.pgid).await;
            if rollback.is_ok() {
                let _ = tokio::task::spawn_blocking(move || child.wait()).await;
            }
            return match rollback {
                Ok(()) => Err(bad_request(format!(
                    "spawned process did not become process-group leader; rolled back: pid={pid}, pgid={}",
                    identity.pgid
                ))),
                Err(rollback_error) => Err(bad_request(format!(
                    "spawned process did not become process-group leader and rollback failed; manual cleanup required: pid={pid}, pgid={}: {rollback_error}",
                    identity.pgid
                ))),
            };
        }
        // Store the observed cmdline for diagnostics; PID + starttime + process group remain the
        // stable identity because runtimes may rewrite their title after startup.
        let argv = Self::observe_process_argv(pid, &svc.spec.command);
        let meta = ProcMetaV1 {
            version: 2,
            provider: "process".to_string(),
            service_id: svc.id.0.clone(),
            boot_id: identity.boot_id,
            pid,
            pgid: identity.pgid,
            exe: identity.exe,
            argv,
            proc_starttime_ticks: identity.starttime_ticks,
            created_at: Utc::now(),
        };
        let persist_result = (|| -> Result<()> {
            Self::write_meta(&meta_path, &meta)?;
            Self::write_pid(&pid_path, pid)?;
            Self::write_started_at(&started_at_path, meta.created_at)?;
            Ok(())
        })();
        if let Err(e) = persist_result {
            let _ = Self::write_meta(&orphan_meta_path, &meta);
            let rollback = self.terminate_process_group(meta.pgid).await;
            if rollback.is_ok() {
                let _ = tokio::task::spawn_blocking(move || child.wait()).await;
                Self::cleanup_runtime_state(
                    &pid_path,
                    &meta_path,
                    &orphan_meta_path,
                    &started_at_path,
                );
            }
            return match rollback {
                Ok(()) => Err(bad_request(format!(
                    "failed to persist process metadata; spawned process group was rolled back: {e}"
                ))),
                Err(rollback_error) => Err(bad_request(format!(
                    "failed to persist process metadata and rollback could not confirm process-group exit; metadata retained at {:?} / {:?}, pid={pid}, pgid={}: {e}; rollback: {rollback_error}",
                    meta_path, orphan_meta_path, meta.pgid
                ))),
            };
        }

        if let Err(monitor_error) = self.ensure_runtime_monitor(
            meta.clone(),
            pid_path.clone(),
            meta_path.clone(),
            orphan_meta_path.clone(),
            started_at_path.clone(),
            self.stderr_path(svc)?,
        ) {
            let rollback = self.terminate_process_group(meta.pgid).await;
            if rollback.is_ok() {
                Self::cleanup_runtime_state_if_matches(
                    &meta,
                    &pid_path,
                    &meta_path,
                    &orphan_meta_path,
                    &started_at_path,
                );
            }
            let _ = tokio::task::spawn_blocking(move || child.wait()).await;
            return match rollback {
                Ok(()) => Err(bad_request(format!(
                    "failed to establish process monitor; process group rolled back: {monitor_error}"
                ))),
                Err(rollback_error) => Err(bad_request(format!(
                    "failed to establish process monitor and rollback could not confirm process-group exit; metadata retained: {monitor_error}; rollback: {rollback_error}"
                ))),
            };
        }
        tokio::spawn(async move {
            let _ = tokio::task::spawn_blocking(move || child.wait()).await;
        });

        Ok(())
    }

    async fn stop(&self, svc: &Service) -> Result<()> {
        let pid_path = self.pid_path(svc)?;
        let meta_path = self.meta_path(svc)?;
        let orphan_meta_path = self.orphan_meta_path(svc)?;
        let started_at_path = self.started_at_path_or(svc)?;
        let meta = Self::read_meta_with_fallback(&meta_path, &orphan_meta_path);
        let Some(pid) = Self::read_pid(&pid_path)?.or_else(|| meta.as_ref().map(|m| m.pid)) else {
            return Ok(());
        };

        if !self.pid_is_alive(pid).await.unwrap_or(false) {
            return match self.verify_dead_leader_group(meta.as_ref()).await {
                ProcVerify::Stale(_) => {
                    Self::cleanup_runtime_state(
                        &pid_path,
                        &meta_path,
                        &orphan_meta_path,
                        &started_at_path,
                    );
                    Ok(())
                }
                ProcVerify::Unverifiable(reason) => Err(bad_request(format!(
                    "refusing to stop orphan process group without a live leader identity: pid={pid} ({reason})"
                ))),
                ProcVerify::Managed => unreachable!(),
            };
        }

        match Self::verify_pid(svc, pid, meta.as_ref()) {
            ProcVerify::Managed => {
                let meta = meta.as_ref().expect("managed process has metadata");
                self.terminate_process_group(meta.pgid).await?;
                Self::cleanup_runtime_state_if_matches(
                    meta,
                    &pid_path,
                    &meta_path,
                    &orphan_meta_path,
                    &started_at_path,
                );
                Ok(())
            }
            ProcVerify::Stale(_) => {
                Self::cleanup_runtime_state(
                    &pid_path,
                    &meta_path,
                    &orphan_meta_path,
                    &started_at_path,
                );
                Ok(())
            }
            ProcVerify::Unverifiable(reason) => Err(bad_request(format!(
                "refusing to stop: pid identity cannot be verified: pid={pid} ({reason})"
            ))),
        }
    }

    async fn restart(&self, svc: &Service) -> Result<()> {
        self.stop(svc).await?;
        self.start(svc).await
    }

    async fn status(&self, svc: &Service) -> Result<ServiceStatus> {
        let observed_at = Utc::now();
        let pid_path = self.pid_path(svc)?;
        let meta_path = self.meta_path(svc)?;
        let orphan_meta_path = self.orphan_meta_path(svc)?;
        let started_at_path = self.started_at_path_or(svc)?;
        let started_at = Self::read_started_at(&started_at_path).ok().flatten();

        let mut st = ServiceStatus {
            service_id: svc.id.clone(),
            state: ServiceState::Stopped,
            message: String::new(),
            provider: self.id(),
            observed_at,
            started_at,
            pid: None,
            exit_code: None,
        };

        let meta = Self::read_meta_with_fallback(&meta_path, &orphan_meta_path);
        let Some(pid) = Self::read_pid(&pid_path)?.or_else(|| meta.as_ref().map(|m| m.pid)) else {
            st.state = ServiceState::Stopped;
            st.message = "not running".to_string();
            return Ok(st);
        };

        if !self.pid_is_alive(pid).await.unwrap_or(false) {
            return match self.verify_dead_leader_group(meta.as_ref()).await {
                ProcVerify::Stale(reason) => {
                    Self::cleanup_runtime_state(
                        &pid_path,
                        &meta_path,
                        &orphan_meta_path,
                        &started_at_path,
                    );
                    st.state = ServiceState::Stopped;
                    st.message = format!("stale runtime metadata ({reason})");
                    Ok(st)
                }
                ProcVerify::Unverifiable(reason) => {
                    st.state = ServiceState::Unknown;
                    st.pid = Some(pid);
                    st.message = reason;
                    Ok(st)
                }
                ProcVerify::Managed => unreachable!(),
            };
        }

        match Self::verify_pid(svc, pid, meta.as_ref()) {
            ProcVerify::Managed => {
                let meta = meta.as_ref().expect("managed process has metadata");
                self.ensure_runtime_monitor(
                    meta.clone(),
                    pid_path.clone(),
                    meta_path.clone(),
                    orphan_meta_path.clone(),
                    started_at_path.clone(),
                    self.stderr_path(svc)?,
                )?;
                st.state = ServiceState::Running;
                st.pid = Some(pid);
                st.message = "running".to_string();
                Ok(st)
            }
            ProcVerify::Stale(reason) => {
                Self::cleanup_runtime_state(
                    &pid_path,
                    &meta_path,
                    &orphan_meta_path,
                    &started_at_path,
                );
                st.state = ServiceState::Stopped;
                st.message = format!("stale pidfile ({reason})");
                Ok(st)
            }
            ProcVerify::Unverifiable(reason) => {
                st.state = ServiceState::Unknown;
                st.pid = Some(pid);
                st.message = format!("pid identity cannot be verified ({reason})");
                Ok(st)
            }
        }
    }

    async fn logs(&self, svc: &Service, opts: LogsOptions) -> Result<Vec<LogEntry>> {
        // For now, we treat log lines as "now" time-stamped. If we later add timestamped
        // output wrappers, update this to parse timestamps.
        let limit = opts.limit;

        let mut out = Vec::new();
        let now = DateTime::<Utc>::from(SystemTime::now());

        let stdout = fs::read_to_string(self.stdout_path(svc)?).unwrap_or_default();
        for line in Self::slice_log_lines(&stdout, limit) {
            if line.trim().is_empty() {
                continue;
            }
            out.push(LogEntry {
                time: now,
                stream: "stdout".to_string(),
                message: line.to_string(),
            });
        }

        let stderr = fs::read_to_string(self.stderr_path(svc)?).unwrap_or_default();
        for line in Self::slice_log_lines(&stderr, limit) {
            if line.trim().is_empty() {
                continue;
            }
            out.push(LogEntry {
                time: now,
                stream: "stderr".to_string(),
                message: line.to_string(),
            });
        }

        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{ProviderId, Service, ServiceId, ServiceSpec};
    use std::collections::BTreeMap;

    fn svc() -> Service {
        Service {
            id: ServiceId("svc1".to_string()),
            spec: ServiceSpec {
                name: "demo".to_string(),
                description: String::new(),
                provider: ProviderId("process".to_string()),
                command: vec!["sleep".to_string(), "10".to_string()],
                working_dir: String::new(),
                env: BTreeMap::new(),
                runtime: BTreeMap::new(),
                restart: Default::default(),
                health: vec![],
                ports: vec![],
                enabled: true,
                resident_by_default: false,
                tags: vec![],
            },
            created_at: Utc::now(),
            updated_at: Utc::now(),
            deleted_at: None,
        }
    }

    fn meta(svc: &Service) -> ProcMetaV1 {
        ProcMetaV1 {
            version: 2,
            provider: "process".to_string(),
            service_id: svc.id.0.clone(),
            boot_id: "boot-a".to_string(),
            pid: 100,
            pgid: 100,
            exe: "/usr/bin/node".to_string(),
            argv: svc.spec.command.clone(),
            proc_starttime_ticks: 111,
            created_at: Utc::now(),
        }
    }

    #[test]
    fn slice_log_lines_applies_tail_limit() {
        let s = "a\nb\nc\nd\n";
        let out = ProcessProvider::slice_log_lines(s, Some(2));
        assert_eq!(out, vec!["c", "d"]);
    }

    #[test]
    fn cleanup_runtime_state_removes_pid_meta_and_started_at_files() {
        let dir = std::env::temp_dir().join(format!(
            "service-manager-process-cleanup-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        fs::create_dir_all(&dir).unwrap();
        let pid_path = dir.join("pid");
        let meta_path = dir.join("meta.json");
        let orphan_meta_path = dir.join("orphan-meta.json");
        let started_at_path = dir.join("started_at");

        fs::write(&pid_path, b"123\n").unwrap();
        fs::write(&meta_path, b"{}").unwrap();
        fs::write(&orphan_meta_path, b"{}").unwrap();
        fs::write(&started_at_path, b"2026-05-05T00:00:00Z\n").unwrap();

        ProcessProvider::cleanup_runtime_state(
            &pid_path,
            &meta_path,
            &orphan_meta_path,
            &started_at_path,
        );

        assert!(!pid_path.exists());
        assert!(!meta_path.exists());
        assert!(!orphan_meta_path.exists());
        assert!(!started_at_path.exists());
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn proc_stat_starttime_from_str_parses_starttime() {
        // starttime is field 22 overall (token 19 after comm). We only care that we can parse it.
        let s = "123 (weird comm) R 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 424242";
        assert_eq!(
            ProcessProvider::proc_stat_starttime_from_str(s),
            Some(424242)
        );
    }

    #[test]
    fn parse_proc_cmdline_preserves_runtime_arguments() {
        assert_eq!(
            ProcessProvider::parse_proc_cmdline(
            b"/apex/com.android.runtime/bin/linker64\0/data/data/com.termux/files/usr/bin/sh\0-lc\0echo hi\0",
            ),
            Some(vec![
                "/apex/com.android.runtime/bin/linker64".to_string(),
                "/data/data/com.termux/files/usr/bin/sh".to_string(),
                "-lc".to_string(),
                "echo hi".to_string(),
            ])
        );
    }

    #[test]
    fn observe_process_argv_uses_fallback_when_proc_entry_is_missing() {
        let fallback = vec!["sh".to_string(), "-lc".to_string(), "echo hi".to_string()];
        assert_eq!(
            ProcessProvider::observe_process_argv(u32::MAX, &fallback),
            vec!["sh".to_string(), "-lc".to_string(), "echo hi".to_string(),]
        );
    }

    #[test]
    fn verify_pid_with_obs_refuses_on_starttime_mismatch() {
        let svc = svc();
        let meta = meta(&svc);
        match ProcessProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(222),
            Some(100),
            Some("/usr/bin/node".to_string()),
            Some(svc.spec.command.clone()),
        ) {
            ProcVerify::Stale(reason) => assert!(reason.contains("starttime")),
            other => panic!("expected Stale, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_accepts_process_title_change_when_starttime_matches() {
        let svc = svc();
        let meta = meta(&svc);
        match ProcessProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(111),
            Some(100),
            Some("/usr/bin/node".to_string()),
            Some(vec![
                "node".to_string(),
                "next-server (v16.2.9)".to_string(),
            ]),
        ) {
            ProcVerify::Managed => {}
            other => panic!("expected Managed, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_refuses_on_process_group_change() {
        let svc = svc();
        let meta = meta(&svc);
        match ProcessProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(111),
            Some(200),
            Some("/usr/bin/node".to_string()),
            Some(svc.spec.command.clone()),
        ) {
            ProcVerify::Unverifiable(reason) => assert!(reason.contains("process group changed")),
            other => panic!("expected Unverifiable, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_rejects_executable_change() {
        let svc = svc();
        let meta = meta(&svc);
        match ProcessProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-a".to_string()),
            Some(111),
            Some(100),
            Some("/usr/bin/other".to_string()),
            Some(vec!["node next-server".to_string()]),
        ) {
            ProcVerify::Unverifiable(reason) => assert!(reason.contains("executable")),
            other => panic!("expected Unverifiable, got {other:?}"),
        }
    }

    #[test]
    fn verify_pid_with_obs_rejects_cross_boot_metadata() {
        let svc = svc();
        let meta = meta(&svc);
        match ProcessProvider::verify_pid_with_obs(
            &svc,
            100,
            Some(&meta),
            Some("boot-b".to_string()),
            Some(111),
            Some(100),
            Some("/usr/bin/node".to_string()),
            Some(vec!["node next-server".to_string()]),
        ) {
            ProcVerify::Stale(reason) => assert!(reason.contains("boot_id")),
            other => panic!("expected Stale, got {other:?}"),
        }
    }

    #[test]
    fn service_spec_keeps_injected_command_environment_and_health() {
        let mut svc = svc();
        svc.spec.command = vec![
            "/opt/bin/pi-web".to_string(),
            "--port".to_string(),
            "30142".to_string(),
        ];
        svc.spec
            .env
            .insert("PI_WEB_PORT".to_string(), "30142".to_string());
        let original = svc.clone();

        assert_eq!(svc.spec.command, original.spec.command);
        assert_eq!(svc.spec.env, original.spec.env);
        assert_eq!(svc.spec.health, original.spec.health);
    }

    #[test]
    fn service_runtime_metadata_paths_are_isolated() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-process-isolation-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let provider = ProcessProvider::new(data_dir.clone());
        let first = svc();
        let mut second = svc();
        second.id = ServiceId("svc2".to_string());

        let first_meta = provider.meta_path(&first).unwrap();
        let second_meta = provider.meta_path(&second).unwrap();
        assert_ne!(first_meta, second_meta);
        fs::create_dir_all(first_meta.parent().unwrap()).unwrap();
        fs::create_dir_all(second_meta.parent().unwrap()).unwrap();
        fs::write(&first_meta, br#"{"service_id":"svc1"}"#).unwrap();
        fs::write(&second_meta, br#"{"service_id":"svc2"}"#).unwrap();
        assert!(fs::read_to_string(first_meta).unwrap().contains("svc1"));
        assert!(fs::read_to_string(second_meta).unwrap().contains("svc2"));

        let _ = fs::remove_dir_all(data_dir);
    }

    #[tokio::test]
    async fn persisted_identity_is_recovered_after_provider_recreation() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-process-recovery-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let mut service = svc();
        service.spec.command = vec![
            "sh".to_string(),
            "-c".to_string(),
            "echo \"$ALLOCATED_PORT\"; sleep 30".to_string(),
        ];
        service
            .spec
            .env
            .insert("ALLOCATED_PORT".to_string(), "30142".to_string());

        let first = ProcessProvider::new(data_dir.clone());
        first.start(&service).await.unwrap();
        tokio::time::sleep(Duration::from_millis(100)).await;
        assert_eq!(
            first.status(&service).await.unwrap().state,
            ServiceState::Running
        );

        let meta_path = first.meta_path(&service).unwrap();
        let meta = ProcessProvider::read_meta(&meta_path).unwrap();
        let monitor_key = ProcessProvider::monitor_key(&meta_path, &meta);
        let previous_monitor = ProcessProvider::monitor_registry()
            .lock()
            .unwrap()
            .remove(&monitor_key)
            .expect("initial process monitor");
        previous_monitor.abort();
        tokio::task::yield_now().await;

        let recovered = ProcessProvider::new(data_dir.clone());
        let recovered_status = recovered.status(&service).await.unwrap();
        assert_eq!(recovered_status.state, ServiceState::Running);
        assert!(recovered_status.pid.is_some());
        assert!(
            ProcessProvider::monitor_registry()
                .lock()
                .unwrap()
                .get(&monitor_key)
                .is_some_and(|handle| !handle.is_finished())
        );
        let logs = recovered
            .logs(
                &service,
                LogsOptions {
                    since: None,
                    until: None,
                    limit: Some(10),
                },
            )
            .await
            .unwrap();
        assert!(logs.iter().any(|entry| entry.message == "30142"));

        recovered.stop(&service).await.unwrap();
        assert_eq!(
            recovered.status(&service).await.unwrap().state,
            ServiceState::Stopped
        );
        let _ = fs::remove_dir_all(data_dir);
    }

    #[tokio::test]
    async fn daemonizing_command_reaper_cleans_background_process_group() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-process-daemon-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let provider = ProcessProvider::new(data_dir.clone());
        let mut service = svc();
        let release = data_dir.join("release-leader");
        service.spec.command = vec![
            "sh".to_string(),
            "-c".to_string(),
            format!(
                "sleep 30 & while [ ! -f {} ]; do sleep 0.05; done",
                release.to_string_lossy()
            ),
        ];

        provider.start(&service).await.unwrap();
        let meta = ProcessProvider::read_meta(&provider.meta_path(&service).unwrap()).unwrap();
        fs::write(&release, b"release\n").unwrap();
        for _ in 0..80 {
            if provider.status(&service).await.unwrap().state == ServiceState::Stopped {
                break;
            }
            tokio::time::sleep(Duration::from_millis(50)).await;
        }

        assert_eq!(
            provider.status(&service).await.unwrap().state,
            ServiceState::Stopped
        );
        assert!(!provider.process_group_is_alive(meta.pgid).await.unwrap());
        let _ = fs::remove_dir_all(data_dir);
    }

    #[tokio::test]
    async fn exited_leader_with_live_group_is_orphan_and_blocks_start() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-process-orphan-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let provider = ProcessProvider::new(data_dir.clone());
        let service = svc();
        provider.ensure_dirs(&service).unwrap();
        let release = data_dir.join("release-leader");

        let mut command = std::process::Command::new("sh");
        command.args([
            "-c",
            &format!(
                "sleep 30 & while [ ! -f {} ]; do sleep 0.05; done",
                release.to_string_lossy()
            ),
        ]);
        command.process_group(0);
        let mut child = command.spawn().unwrap();
        let pid = child.id();
        let identity = ProcessProvider::observe_process_identity(pid).unwrap();
        let meta = ProcMetaV1 {
            version: 2,
            provider: "process".to_string(),
            service_id: service.id.0.clone(),
            boot_id: identity.boot_id,
            pid,
            pgid: identity.pgid,
            exe: identity.exe,
            argv: ProcessProvider::observe_process_argv(pid, &["sh".to_string()]),
            proc_starttime_ticks: identity.starttime_ticks,
            created_at: Utc::now(),
        };
        ProcessProvider::write_meta(&provider.meta_path(&service).unwrap(), &meta).unwrap();
        ProcessProvider::write_pid(&provider.pid_path(&service).unwrap(), pid).unwrap();
        ProcessProvider::write_started_at(&provider.started_at_path(&service).unwrap(), Utc::now())
            .unwrap();
        fs::write(&release, b"release\n").unwrap();
        let _ = tokio::task::spawn_blocking(move || child.wait()).await;

        assert!(!provider.pid_is_alive(pid).await.unwrap());
        assert!(provider.process_group_is_alive(meta.pgid).await.unwrap());
        let status = provider.status(&service).await.unwrap();
        assert_eq!(status.state, ServiceState::Unknown);
        assert!(status.message.contains("orphan"));
        let error = provider.start(&service).await.unwrap_err().to_string();
        assert!(error.contains("refusing to start"));
        assert!(provider.meta_path(&service).unwrap().exists());

        provider.terminate_process_group(meta.pgid).await.unwrap();
        ProcessProvider::cleanup_runtime_state(
            &provider.pid_path(&service).unwrap(),
            &provider.meta_path(&service).unwrap(),
            &provider.orphan_meta_path(&service).unwrap(),
            &provider.started_at_path(&service).unwrap(),
        );
        let _ = fs::remove_dir_all(data_dir);
    }

    #[tokio::test]
    async fn term_ignored_process_group_is_escalated_to_kill() {
        let provider = ProcessProvider::new(std::env::temp_dir());
        let mut command = std::process::Command::new("sh");
        command.args(["-c", "trap '' TERM; while :; do sleep 1; done"]);
        command.process_group(0);
        let mut child = command.spawn().unwrap();
        let pgid = child.id() as i32;
        ProcessProvider::observe_process_identity(child.id()).unwrap();

        provider
            .terminate_process_group_with_timeouts(
                pgid,
                Duration::from_millis(100),
                Duration::from_secs(2),
            )
            .await
            .unwrap();
        let _ = tokio::task::spawn_blocking(move || child.wait()).await;
        assert!(!provider.process_group_is_alive(pgid).await.unwrap());
    }

    #[tokio::test]
    async fn persistence_failure_rolls_back_spawned_group() {
        let data_dir = std::env::temp_dir().join(format!(
            "service-manager-process-persist-failure-{}",
            Utc::now().timestamp_nanos_opt().unwrap_or_default()
        ));
        let provider = ProcessProvider::new(data_dir.clone());
        let mut service = svc();
        let marker = data_dir.join("spawned-pid");
        service.spec.command = vec![
            "sh".to_string(),
            "-c".to_string(),
            format!("echo $$ > {}; sleep 30", marker.to_string_lossy()),
        ];
        provider.ensure_dirs(&service).unwrap();
        fs::create_dir(provider.started_at_path(&service).unwrap()).unwrap();

        let error = provider.start(&service).await.unwrap_err().to_string();
        assert!(error.contains("rolled back"));
        let pid: u32 = fs::read_to_string(&marker).unwrap().trim().parse().unwrap();
        assert!(!provider.pid_is_alive(pid).await.unwrap());
        assert!(!provider.process_group_is_alive(pid as i32).await.unwrap());
        assert!(!provider.meta_path(&service).unwrap().is_file());
        assert!(!provider.pid_path(&service).unwrap().exists());

        let _ = fs::remove_dir_all(data_dir);
    }
}
