use std::{
    collections::{BTreeMap, BTreeSet},
    fmt,
    time::Duration,
};

use async_trait::async_trait;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Deserializer, Serialize, Serializer};

use crate::error::{AppError, Result};

#[derive(Clone, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(transparent)]
pub struct ServiceId(pub String);

impl ServiceId {
    pub fn new(id: impl Into<String>) -> Self {
        Self(id.into())
    }
}

impl fmt::Display for ServiceId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(transparent)]
pub struct ProviderId(pub String);

impl ProviderId {
    #[allow(dead_code)]
    pub fn new(id: impl Into<String>) -> Self {
        Self(id.into())
    }
}

impl fmt::Display for ProviderId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Action {
    Create,
    Update,
    Delete,
    Register,
    Unregister,
    Start,
    Stop,
    Restart,
    Repair,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ServiceState {
    Unknown,
    Stopped,
    Starting,
    Running,
    Stopping,
    Failed,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum RestartMode {
    #[serde(rename = "no")]
    No,
    OnFailure,
    Always,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct RestartPolicy {
    #[serde(default)]
    pub mode: Option<RestartMode>,
    #[serde(default)]
    pub max_retries: i32,
}

impl Default for RestartPolicy {
    fn default() -> Self {
        Self {
            mode: Some(RestartMode::No),
            max_retries: 0,
        }
    }
}

impl RestartPolicy {
    pub fn validate(&mut self) -> Result<()> {
        if self.mode.is_none() {
            self.mode = Some(RestartMode::No);
        }
        if self.max_retries < 0 {
            return Err(AppError::BadRequest(
                "restart.max_retries must be >= 0".to_string(),
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum HealthCheckType {
    Http,
    Tcp,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct DurationDef(#[serde(with = "duration_serde")] pub Duration);

mod duration_serde {
    use std::time::Duration;

    use serde::{Deserialize, Deserializer, Serializer};

    pub fn serialize<S>(d: &Duration, s: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        // Match Go's intent ("5s", "1m0s") loosely via humantime formatting.
        s.serialize_str(&humantime::format_duration(*d).to_string())
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<Duration, D::Error>
    where
        D: Deserializer<'de>,
    {
        #[derive(Deserialize)]
        #[serde(untagged)]
        enum In {
            Str(String),
            Ns(i64),
            Null,
        }

        match In::deserialize(deserializer)? {
            In::Null => Ok(Duration::from_secs(0)),
            In::Str(s) => {
                let s = s.trim();
                if s.is_empty() {
                    return Ok(Duration::from_secs(0));
                }
                humantime::parse_duration(s).map_err(serde::de::Error::custom)
            }
            In::Ns(n) => {
                if n < 0 {
                    return Err(serde::de::Error::custom("duration must be >= 0"));
                }
                Ok(Duration::from_nanos(n as u64))
            }
        }
    }
}

impl Default for DurationDef {
    fn default() -> Self {
        Self(Duration::from_secs(0))
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct HealthCheck {
    #[serde(rename = "type")]
    pub ty: HealthCheckType,
    #[serde(default)]
    pub interval: DurationDef,
    #[serde(default)]
    pub timeout: DurationDef,

    // HTTP
    #[serde(default)]
    pub url: String,

    // TCP
    #[serde(default)]
    pub address: String,
}

impl HealthCheck {
    pub fn validate(&mut self) -> Result<()> {
        match self.ty {
            HealthCheckType::Http => {
                if self.url.trim().is_empty() {
                    return Err(AppError::BadRequest(
                        "url is required for http healthcheck".to_string(),
                    ));
                }
            }
            HealthCheckType::Tcp => {
                if self.address.trim().is_empty() {
                    return Err(AppError::BadRequest(
                        "address is required for tcp healthcheck".to_string(),
                    ));
                }
            }
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ServicePortProtocol {
    #[default]
    Tcp,
    Udp,
}

fn default_port_host() -> String {
    "127.0.0.1".to_string()
}

fn default_port_pool() -> String {
    "local-web".to_string()
}

fn default_endpoint_scheme() -> String {
    "http".to_string()
}

fn default_endpoint_path() -> String {
    "/".to_string()
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ServiceEndpointSpec {
    #[serde(default = "default_endpoint_scheme")]
    pub scheme: String,
    #[serde(default = "default_endpoint_path")]
    pub path: String,
}

impl ServiceEndpointSpec {
    pub fn validate(&mut self) -> Result<()> {
        self.scheme = self.scheme.trim().to_ascii_lowercase();
        self.path = self.path.trim().to_string();
        if self.scheme.is_empty()
            || !self.scheme.chars().enumerate().all(|(i, c)| {
                c.is_ascii_alphabetic()
                    || (i > 0 && (c.is_ascii_digit() || matches!(c, '+' | '-' | '.')))
            })
        {
            return Err(AppError::BadRequest(
                "endpoint.scheme must be a valid URI scheme".to_string(),
            ));
        }
        if self.path.is_empty() {
            self.path = default_endpoint_path();
        } else if !self.path.starts_with('/') {
            return Err(AppError::BadRequest(
                "endpoint.path must start with '/'".to_string(),
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ServicePortSpec {
    pub name: String,
    #[serde(default = "default_port_host")]
    pub host: String,
    pub preferred: u16,
    pub dynamic: bool,
    #[serde(default = "default_port_pool")]
    pub pool: String,
    #[serde(default)]
    pub protocol: ServicePortProtocol,
    #[serde(rename = "envVar")]
    pub env_var: String,
    #[serde(default)]
    pub endpoint: Option<ServiceEndpointSpec>,
}

impl ServicePortSpec {
    pub fn validate(&mut self) -> Result<()> {
        self.name = self.name.trim().to_string();
        self.host = self.host.trim().to_string();
        self.pool = self.pool.trim().to_string();
        self.env_var = self.env_var.trim().to_string();

        if self.name.is_empty() {
            return Err(AppError::BadRequest("ports[].name is required".to_string()));
        }
        if self.host.is_empty() {
            self.host = default_port_host();
        }
        if self.preferred == 0 {
            return Err(AppError::BadRequest(format!(
                "ports[{}].preferred must be between 1 and 65535",
                self.name
            )));
        }
        if self.pool.is_empty() {
            self.pool = default_port_pool();
        }
        if !valid_env_var(&self.env_var) {
            return Err(AppError::BadRequest(format!(
                "ports[{}].envVar must be a valid environment variable name",
                self.name
            )));
        }
        if let Some(endpoint) = &mut self.endpoint {
            endpoint.validate()?;
        }
        Ok(())
    }
}

fn valid_env_var(value: &str) -> bool {
    let mut chars = value.chars();
    let Some(first) = chars.next() else {
        return false;
    };
    (first.is_ascii_alphabetic() || first == '_')
        && chars.all(|c| c.is_ascii_alphanumeric() || c == '_')
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PortPoolSpec {
    pub name: String,
    pub start: u16,
    pub end: u16,
}

impl PortPoolSpec {
    pub fn local_web_default() -> Self {
        Self {
            name: default_port_pool(),
            start: 24_000,
            end: 39_999,
        }
    }

    pub fn validate(&mut self) -> Result<()> {
        self.name = self.name.trim().to_string();
        if self.name.is_empty() {
            return Err(AppError::BadRequest(
                "port pool name is required".to_string(),
            ));
        }
        if self.start == 0 || self.end == 0 || self.start > self.end {
            return Err(AppError::BadRequest(format!(
                "port pool {} must have a valid inclusive range",
                self.name
            )));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PortConflictDiagnostic {
    pub preferred_port: u16,
    pub reason: PortConflictReason,
    pub observed_at: DateTime<Utc>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum PortConflictReason {
    AddressInUse,
    ManagedLease,
    OrphanedLease,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum PortLeaseLifecycle {
    Leased,
    Published,
    Orphaned,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct PortLease {
    pub service_id: ServiceId,
    pub port_name: String,
    pub host: String,
    pub preferred_port: u16,
    pub allocated_port: u16,
    pub dynamic: bool,
    pub pool: String,
    pub protocol: ServicePortProtocol,
    pub env_var: String,
    #[serde(default)]
    pub endpoint: Option<ServiceEndpointSpec>,
    #[serde(default)]
    pub conflict: Option<PortConflictDiagnostic>,
    pub lifecycle: PortLeaseLifecycle,
    #[serde(default)]
    pub orphan_reason: Option<String>,
    pub generation: u64,
    pub allocated_at: DateTime<Utc>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ServiceEndpoint {
    pub service_id: ServiceId,
    pub name: String,
    pub host: String,
    pub port: u16,
    pub protocol: ServicePortProtocol,
    pub url: String,
    pub generation: u64,
    pub published_at: DateTime<Utc>,
}

fn default_true() -> bool {
    true
}

fn default_repair_timeout() -> DurationDef {
    DurationDef(Duration::from_secs(10 * 60))
}

const REPAIR_RUNTIME_KEY: &str = "service-manager.repair";

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum RepairHookMode {
    #[default]
    Hook,
    Script,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RepairHook {
    #[serde(default)]
    pub mode: RepairHookMode,
    #[serde(default)]
    pub command: Vec<String>,
    #[serde(default)]
    pub working_dir: String,
    #[serde(default)]
    pub env: BTreeMap<String, String>,
    #[serde(default = "default_repair_timeout")]
    pub timeout: DurationDef,
}

impl RepairHook {
    pub fn validate(&mut self) -> Result<()> {
        self.working_dir = self.working_dir.trim().to_string();
        if self.command.is_empty() {
            return Err(AppError::BadRequest(
                "repair.command is required when repair is configured".to_string(),
            ));
        }
        for (i, part) in self.command.iter().enumerate() {
            if part.trim().is_empty() {
                return Err(AppError::BadRequest(format!(
                    "repair.command[{i}] is empty"
                )));
            }
        }
        if self.timeout.0.is_zero() {
            self.timeout = default_repair_timeout();
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ServiceSpec {
    pub name: String,
    pub description: String,
    pub provider: ProviderId,
    pub command: Vec<String>, // argv; command[0] is executable
    pub working_dir: String,
    pub env: BTreeMap<String, String>,

    // Provider-specific options. Schema intentionally loose.
    pub runtime: BTreeMap<String, serde_json::Value>,

    pub restart: RestartPolicy,
    pub health: Vec<HealthCheck>,
    pub ports: Vec<ServicePortSpec>,

    pub enabled: bool,
    /// Initial residency preference. It is copied into the independent policy store only when
    /// that service id has never had a policy; later registry refreshes cannot overwrite it.
    pub resident_by_default: bool,
    pub tags: Vec<String>,
}

impl ServiceSpec {
    pub fn validate(&mut self) -> Result<()> {
        self.name = self.name.trim().to_string();
        self.description = self.description.trim().to_string();
        self.working_dir = self.working_dir.trim().to_string();

        if self.name.is_empty() {
            return Err(AppError::BadRequest("name is required".to_string()));
        }
        if !valid_service_name(&self.name) {
            return Err(AppError::BadRequest(
                "name must match ^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$".to_string(),
            ));
        }
        if self.provider.0.trim().is_empty() {
            return Err(AppError::BadRequest("provider is required".to_string()));
        }
        for (i, part) in self.command.iter().enumerate() {
            if part.trim().is_empty() {
                return Err(AppError::BadRequest(format!("command[{i}] is empty")));
            }
        }

        self.restart.validate()?;
        if let Some(mut repair) = self.repair_hook()? {
            repair.validate()?;
            let value = serde_json::to_value(repair)?;
            self.runtime.insert(REPAIR_RUNTIME_KEY.to_string(), value);
        }
        for i in 0..self.health.len() {
            self.health[i].validate().map_err(|e| match e {
                AppError::BadRequest(msg) => AppError::BadRequest(format!("health[{i}]: {msg}")),
                other => other,
            })?;
        }
        for i in 0..self.ports.len() {
            self.ports[i].validate().map_err(|e| match e {
                AppError::BadRequest(msg) => AppError::BadRequest(format!("ports[{i}]: {msg}")),
                other => other,
            })?;
        }
        let mut port_names = BTreeSet::new();
        let mut port_env_vars = BTreeSet::new();
        let mut canonical_port_envs = BTreeSet::new();
        for port in &self.ports {
            if !port_names.insert(port.name.clone()) {
                return Err(AppError::BadRequest(format!(
                    "duplicate port name: {}",
                    port.name
                )));
            }
            if !port_env_vars.insert(port.env_var.clone()) {
                return Err(AppError::BadRequest(format!(
                    "duplicate port envVar: {}",
                    port.env_var
                )));
            }
            let canonical_env = canonical_port_env(&port.name);
            if !canonical_port_envs.insert(canonical_env.clone()) {
                return Err(AppError::BadRequest(format!(
                    "canonical port env conflict: {} maps to {}",
                    port.name, canonical_env
                )));
            }
            if port.endpoint.is_some() {
                let template = format!("{{{{port:{}}}}}", port.name);
                let referenced = self.health.iter().any(|health| match health.ty {
                    HealthCheckType::Http => health.url.contains(&template),
                    HealthCheckType::Tcp => health.address.contains(&template),
                });
                if !referenced {
                    return Err(AppError::BadRequest(format!(
                        "ports[{}].endpoint requires an HTTP or TCP health check referencing {}",
                        port.name, template
                    )));
                }
            }
        }
        Ok(())
    }

    pub fn repair_hook(&self) -> Result<Option<RepairHook>> {
        let Some(value) = self.runtime.get(REPAIR_RUNTIME_KEY) else {
            return Ok(None);
        };
        Ok(Some(serde_json::from_value(value.clone())?))
    }
}

fn canonical_port_env(name: &str) -> String {
    let mut out = String::with_capacity(name.len());
    let mut previous_separator = false;
    for c in name.trim().chars() {
        if c.is_ascii_alphanumeric() {
            out.push(c.to_ascii_uppercase());
            previous_separator = false;
        } else if !previous_separator {
            out.push('_');
            previous_separator = true;
        }
    }
    while out.ends_with('_') {
        out.pop();
    }
    out
}

impl Serialize for ServiceSpec {
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        #[derive(Serialize)]
        struct Out {
            name: String,
            description: String,
            provider: ProviderId,
            command: Vec<String>,
            working_dir: String,
            env: BTreeMap<String, String>,
            runtime: BTreeMap<String, serde_json::Value>,
            restart: RestartPolicy,
            #[serde(skip_serializing_if = "Option::is_none")]
            repair: Option<RepairHook>,
            health: Vec<HealthCheck>,
            ports: Vec<ServicePortSpec>,
            enabled: bool,
            #[serde(rename = "residentByDefault")]
            resident_by_default: bool,
            tags: Vec<String>,
        }

        let mut runtime = self.runtime.clone();
        let repair = runtime
            .remove(REPAIR_RUNTIME_KEY)
            .map(serde_json::from_value)
            .transpose()
            .map_err(serde::ser::Error::custom)?;

        Out {
            name: self.name.clone(),
            description: self.description.clone(),
            provider: self.provider.clone(),
            command: self.command.clone(),
            working_dir: self.working_dir.clone(),
            env: self.env.clone(),
            runtime,
            restart: self.restart.clone(),
            repair,
            health: self.health.clone(),
            ports: self.ports.clone(),
            enabled: self.enabled,
            resident_by_default: self.resident_by_default,
            tags: self.tags.clone(),
        }
        .serialize(serializer)
    }
}

impl<'de> Deserialize<'de> for ServiceSpec {
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: Deserializer<'de>,
    {
        #[derive(Deserialize)]
        #[serde(deny_unknown_fields)]
        struct In {
            name: String,
            #[serde(default)]
            description: String,
            provider: ProviderId,
            #[serde(default)]
            command: Vec<String>,
            #[serde(default)]
            working_dir: String,
            #[serde(default)]
            env: BTreeMap<String, String>,
            #[serde(default)]
            runtime: BTreeMap<String, serde_json::Value>,
            #[serde(default)]
            restart: RestartPolicy,
            #[serde(default)]
            repair: Option<RepairHook>,
            #[serde(default)]
            health: Vec<HealthCheck>,
            #[serde(default)]
            ports: Vec<ServicePortSpec>,
            #[serde(default = "default_true")]
            enabled: bool,
            #[serde(default, rename = "residentByDefault")]
            resident_by_default: bool,
            #[serde(default)]
            tags: Vec<String>,
        }

        let mut input = In::deserialize(deserializer)?;
        if let Some(repair) = input.repair {
            let value = serde_json::to_value(repair).map_err(serde::de::Error::custom)?;
            input.runtime.insert(REPAIR_RUNTIME_KEY.to_string(), value);
        }
        Ok(Self {
            name: input.name,
            description: input.description,
            provider: input.provider,
            command: input.command,
            working_dir: input.working_dir,
            env: input.env,
            runtime: input.runtime,
            restart: input.restart,
            health: input.health,
            ports: input.ports,
            enabled: input.enabled,
            resident_by_default: input.resident_by_default,
            tags: input.tags,
        })
    }
}

fn valid_service_name(s: &str) -> bool {
    let mut chars = s.chars();
    let Some(first) = chars.next() else {
        return false;
    };
    if !first.is_ascii_alphanumeric() {
        return false;
    }
    let mut len = 1usize;
    for c in chars {
        len += 1;
        if len > 64 {
            return false;
        }
        if !(c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-')) {
            return false;
        }
    }
    true
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Service {
    pub id: ServiceId,
    pub spec: ServiceSpec,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    #[serde(default)]
    pub deleted_at: Option<DateTime<Utc>>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct ServiceStatus {
    pub service_id: ServiceId,
    pub state: ServiceState,
    #[serde(default)]
    pub message: String,
    pub provider: ProviderId,
    pub observed_at: DateTime<Utc>,
    #[serde(default)]
    pub started_at: Option<DateTime<Utc>>,
    #[serde(default)]
    pub pid: Option<u32>,
    #[serde(default)]
    pub exit_code: Option<i32>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct ServiceGroup {
    pub name: String,
    pub service_ids: Vec<ServiceId>,
    pub services: Vec<Service>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct GroupActionResult {
    pub group: String,
    pub action: Action,
    pub total: usize,
    pub succeeded: Vec<ServiceId>,
    pub skipped: Vec<GroupActionSkip>,
    pub failed: Vec<GroupActionFailure>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct GroupActionSkip {
    pub service_id: ServiceId,
    pub reason: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct GroupActionFailure {
    pub service_id: ServiceId,
    pub message: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct LogEntry {
    pub time: DateTime<Utc>,
    #[serde(default)]
    pub stream: String, // stdout|stderr|system|unknown
    pub message: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuditEvent {
    pub id: String,
    pub time: DateTime<Utc>,
    pub action: Action,
    #[serde(default)]
    pub service_id: Option<ServiceId>,
    #[serde(default)]
    pub provider: Option<ProviderId>,
    #[serde(default)]
    pub actor: String, // e.g. "api"
    #[serde(default)]
    pub details: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct LogsOptions {
    #[serde(default)]
    pub since: Option<DateTime<Utc>>,
    #[serde(default)]
    pub until: Option<DateTime<Utc>>,
    #[serde(default)]
    pub limit: Option<usize>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Capability {
    Register,
    Unregister,
    Start,
    Stop,
    Restart,
    Status,
    Logs,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProviderInfo {
    pub id: ProviderId,
    pub display_name: String,
    pub description: String,
    pub capabilities: Vec<Capability>,
    pub detected: bool,
    #[serde(default)]
    pub detect_error: String,
    #[serde(default)]
    pub detect_details: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DetectResult {
    pub detected: bool,
    pub details: String,
}

#[async_trait]
pub trait Provider: Send + Sync {
    fn id(&self) -> ProviderId;
    fn display_name(&self) -> String;
    fn description(&self) -> String;
    fn capabilities(&self) -> Vec<Capability>;

    async fn detect(&self) -> Result<DetectResult>;

    async fn register(&self, svc: &Service) -> Result<()>;
    async fn unregister(&self, svc: &Service) -> Result<()>;

    async fn start(&self, svc: &Service) -> Result<()>;
    async fn stop(&self, svc: &Service) -> Result<()>;
    #[allow(dead_code)]
    async fn restart(&self, svc: &Service) -> Result<()>;
    async fn status(&self, svc: &Service) -> Result<ServiceStatus>;
    async fn logs(&self, svc: &Service, opts: LogsOptions) -> Result<Vec<LogEntry>>;
}

#[cfg(test)]
mod tests {
    use super::*;

    fn service_spec(ports: serde_json::Value, health: serde_json::Value) -> ServiceSpec {
        serde_json::from_value(serde_json::json!({
            "name": "demo",
            "provider": "process",
            "ports": ports,
            "health": health
        }))
        .unwrap()
    }

    fn port(name: &str, env_var: &str, endpoint: bool) -> serde_json::Value {
        let mut value = serde_json::json!({
            "name": name,
            "preferred": 30141,
            "dynamic": true,
            "envVar": env_var
        });
        if endpoint {
            value
                .as_object_mut()
                .unwrap()
                .insert("endpoint".to_string(), serde_json::json!({}));
        }
        value
    }

    #[test]
    fn endpoint_requires_health_check_with_matching_port_template() {
        let mut spec = service_spec(
            serde_json::json!([port("web", "WEB_PORT", true)]),
            serde_json::json!([]),
        );
        let error = spec.validate().unwrap_err();
        assert!(error.to_string().contains("{{port:web}}"));

        let mut wrong_port = service_spec(
            serde_json::json!([port("web", "WEB_PORT", true)]),
            serde_json::json!([{
                "type": "http",
                "url": "http://127.0.0.1:{{port:admin}}/health"
            }]),
        );
        assert!(wrong_port.validate().is_err());
    }

    #[test]
    fn endpoint_accepts_http_or_tcp_health_reference() {
        let mut http = service_spec(
            serde_json::json!([port("web", "WEB_PORT", true)]),
            serde_json::json!([{
                "type": "http",
                "url": "http://127.0.0.1:{{port:web}}/health"
            }]),
        );
        http.validate().unwrap();

        let mut tcp = service_spec(
            serde_json::json!([port("web", "WEB_PORT", true)]),
            serde_json::json!([{
                "type": "tcp",
                "address": "127.0.0.1:{{port:web}}"
            }]),
        );
        tcp.validate().unwrap();
    }

    #[test]
    fn duplicate_port_env_var_is_rejected() {
        let mut spec = service_spec(
            serde_json::json!([port("web", "PORT", false), port("admin", "PORT", false)]),
            serde_json::json!([]),
        );
        let error = spec.validate().unwrap_err();
        assert!(error.to_string().contains("duplicate port envVar"));
    }

    #[test]
    fn canonical_port_env_collision_is_rejected() {
        let mut spec = service_spec(
            serde_json::json!([
                port("web-api", "WEB_API_PORT", false),
                port("web_api", "WEB_API_ALT_PORT", false)
            ]),
            serde_json::json!([]),
        );
        let error = spec.validate().unwrap_err();
        assert!(error.to_string().contains("canonical port env conflict"));
        assert!(error.to_string().contains("WEB_API"));
    }
}
