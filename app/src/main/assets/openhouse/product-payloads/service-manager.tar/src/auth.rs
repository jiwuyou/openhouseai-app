use axum::{
    extract::{Request, State},
    http::{
        HeaderValue, Method, StatusCode,
        header::{AUTHORIZATION, COOKIE, HOST, ORIGIN, WWW_AUTHENTICATE},
    },
    middleware::Next,
    response::{IntoResponse, Response},
};
use std::{
    collections::BTreeMap,
    sync::{Mutex, OnceLock},
    time::{Duration, Instant},
};

use crate::{error::AppError, server::AppState};

pub async fn require_bearer_token(
    State(state): State<AppState>,
    req: Request,
    next: Next,
) -> Response {
    let expected = state.config.auth_token.clone();
    if expected.is_empty() {
        return unauthorized();
    }

    let bearer_ok =
        bearer_token(req.headers()).is_some_and(|token| constant_time_eq(&token, &expected));
    if bearer_ok {
        next.run(req).await
    } else if let Some(token) = session_cookie(req.headers())
        && let Some(session) = sessions().get(&token)
    {
        if is_safe_method(req.method()) || valid_csrf_request(&req, &session.csrf_token) {
            next.run(req).await
        } else {
            forbidden()
        }
    } else {
        unauthorized()
    }
}

const SESSION_COOKIE: &str = "service_manager_session";
const MAX_PENDING_TICKETS: usize = 64;
const MAX_ACTIVE_SESSIONS: usize = 64;

struct Sessions {
    tickets: Mutex<BTreeMap<String, Instant>>,
    sessions: Mutex<BTreeMap<String, SessionEntry>>,
}

#[derive(Clone)]
struct SessionEntry {
    expires_at: Instant,
    csrf_token: String,
}

impl Sessions {
    fn new() -> Self {
        Self {
            tickets: Mutex::new(BTreeMap::new()),
            sessions: Mutex::new(BTreeMap::new()),
        }
    }

    fn issue_ticket(&self) -> crate::error::Result<String> {
        let token = random_token()?;
        let now = Instant::now();
        let mut tickets = self.tickets.lock().expect("ticket mutex poisoned");
        tickets.retain(|_, expiry| *expiry > now);
        while tickets.len() >= MAX_PENDING_TICKETS {
            let Some(oldest) = tickets
                .iter()
                .min_by_key(|(_, expiry)| **expiry)
                .map(|(token, _)| token.clone())
            else {
                break;
            };
            tickets.remove(&oldest);
        }
        tickets.insert(token.clone(), now + Duration::from_secs(60));
        Ok(token)
    }

    fn consume_ticket(&self, ticket: &str) -> crate::error::Result<(String, String)> {
        let expiry = self
            .tickets
            .lock()
            .expect("ticket mutex poisoned")
            .remove(ticket)
            .ok_or(crate::error::AppError::Unauthorized)?;
        if expiry <= Instant::now() {
            return Err(crate::error::AppError::Unauthorized);
        }
        let session = random_token()?;
        let csrf_token = random_token()?;
        let now = Instant::now();
        let mut sessions = self.sessions.lock().expect("session mutex poisoned");
        sessions.retain(|_, entry| entry.expires_at > now);
        while sessions.len() >= MAX_ACTIVE_SESSIONS {
            let Some(oldest) = sessions
                .iter()
                .min_by_key(|(_, entry)| entry.expires_at)
                .map(|(token, _)| token.clone())
            else {
                break;
            };
            sessions.remove(&oldest);
        }
        sessions.insert(
            session.clone(),
            SessionEntry {
                expires_at: now + Duration::from_secs(12 * 60 * 60),
                csrf_token: csrf_token.clone(),
            },
        );
        Ok((session, csrf_token))
    }

    fn get(&self, session: &str) -> Option<SessionEntry> {
        let now = Instant::now();
        let mut sessions = self.sessions.lock().expect("session mutex poisoned");
        sessions.retain(|_, entry| entry.expires_at > now);
        sessions.get(session).cloned()
    }
}

static SESSIONS: OnceLock<Sessions> = OnceLock::new();
fn sessions() -> &'static Sessions {
    SESSIONS.get_or_init(Sessions::new)
}

pub fn issue_web_ticket() -> crate::error::Result<String> {
    sessions().issue_ticket()
}
pub fn consume_web_ticket(ticket: &str) -> crate::error::Result<(String, String)> {
    sessions().consume_ticket(ticket)
}

pub fn csrf_for_cookie(headers: &axum::http::HeaderMap) -> crate::error::Result<String> {
    let token = session_cookie(headers).ok_or(crate::error::AppError::Unauthorized)?;
    sessions()
        .get(&token)
        .map(|session| session.csrf_token)
        .ok_or(crate::error::AppError::Unauthorized)
}

pub fn session_set_cookie(token: &str) -> String {
    format!("{SESSION_COOKIE}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200")
}

fn session_cookie(headers: &axum::http::HeaderMap) -> Option<String> {
    let cookies = headers.get(COOKIE)?.to_str().ok()?;
    cookies.split(';').find_map(|part| {
        let (name, value) = part.trim().split_once('=')?;
        (name == SESSION_COOKIE && !value.is_empty()).then(|| value.to_string())
    })
}

fn is_safe_method(method: &Method) -> bool {
    matches!(*method, Method::GET | Method::HEAD | Method::OPTIONS)
}

fn valid_csrf_request(req: &Request, expected_token: &str) -> bool {
    let headers = req.headers();
    let Some(origin) = headers.get(ORIGIN).and_then(|value| value.to_str().ok()) else {
        return false;
    };
    let Some(host) = headers.get(HOST).and_then(|value| value.to_str().ok()) else {
        return false;
    };
    if origin != format!("http://{host}") && origin != format!("https://{host}") {
        return false;
    }
    headers
        .get("x-csrf-token")
        .and_then(|value| value.to_str().ok())
        .is_some_and(|token| constant_time_eq(token, expected_token))
}

fn random_token() -> crate::error::Result<String> {
    let mut bytes = [0_u8; 32];
    getrandom::getrandom(&mut bytes).map_err(|_| crate::error::AppError::Internal)?;
    Ok(bytes.iter().map(|byte| format!("{byte:02x}")).collect())
}

fn unauthorized() -> Response {
    let mut res = AppError::Unauthorized.into_response();
    res.headers_mut().insert(
        WWW_AUTHENTICATE,
        HeaderValue::from_static("Bearer realm=\"service-manager\""),
    );
    res
}

fn forbidden() -> Response {
    (
        StatusCode::FORBIDDEN,
        "cookie-authenticated mutations require same-origin Origin and X-CSRF-Token",
    )
        .into_response()
}

fn bearer_token(headers: &axum::http::HeaderMap) -> Option<String> {
    let h = headers.get(AUTHORIZATION)?.to_str().ok()?.trim();
    if h.is_empty() {
        return None;
    }
    const PREFIX: &str = "Bearer ";
    if h.len() < PREFIX.len() {
        return None;
    }
    if !h[..PREFIX.len()].eq_ignore_ascii_case(PREFIX) {
        return None;
    }
    let tok = h[PREFIX.len()..].trim();
    if tok.is_empty() {
        return None;
    }
    Some(tok.to_string())
}

fn constant_time_eq(a: &str, b: &str) -> bool {
    // Constant-time for equal-length strings.
    if a.len() != b.len() {
        return false;
    }
    let mut diff: u8 = 0;
    for (&x, &y) in a.as_bytes().iter().zip(b.as_bytes().iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ticket_and_session_collections_are_bounded() {
        let sessions = Sessions::new();
        for _ in 0..(MAX_PENDING_TICKETS + 8) {
            sessions.issue_ticket().unwrap();
        }
        assert_eq!(sessions.tickets.lock().unwrap().len(), MAX_PENDING_TICKETS);

        for _ in 0..(MAX_ACTIVE_SESSIONS + 8) {
            let ticket = sessions.issue_ticket().unwrap();
            sessions.consume_ticket(&ticket).unwrap();
        }
        assert_eq!(sessions.sessions.lock().unwrap().len(), MAX_ACTIVE_SESSIONS);
    }
}
