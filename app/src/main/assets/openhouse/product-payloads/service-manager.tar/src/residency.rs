use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
    sync::Mutex,
};

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::error::{AppError, Result};

pub const RESIDENCY_STORE_VERSION: u32 = 1;

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ResidencyPolicy {
    pub service_id: String,
    pub resident: bool,
    #[serde(default, rename = "suspendedByUser", alias = "suspended")]
    pub suspended: bool,
    #[serde(default)]
    pub last_error: Option<String>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
struct ResidencyDisk {
    version: u32,
    #[serde(default)]
    policies: BTreeMap<String, ResidencyPolicy>,
}

impl Default for ResidencyDisk {
    fn default() -> Self {
        Self {
            version: RESIDENCY_STORE_VERSION,
            policies: BTreeMap::new(),
        }
    }
}

#[derive(Debug)]
pub struct ResidencyStore {
    path: Option<PathBuf>,
    disk: Mutex<ResidencyDisk>,
}

impl ResidencyStore {
    pub fn open(path: impl Into<PathBuf>) -> Result<Self> {
        let path = path.into();
        if path.as_os_str().is_empty() {
            return Err(AppError::BadRequest(
                "residency store path is empty".to_string(),
            ));
        }
        let store = Self {
            path: Some(path),
            disk: Mutex::new(ResidencyDisk::default()),
        };
        store.load()?;
        Ok(store)
    }

    #[cfg(test)]
    pub fn memory() -> Self {
        Self {
            path: None,
            disk: Mutex::new(ResidencyDisk::default()),
        }
    }

    pub fn list(&self) -> Vec<ResidencyPolicy> {
        self.disk
            .lock()
            .expect("residency store mutex poisoned")
            .policies
            .values()
            .cloned()
            .collect()
    }

    pub fn get(&self, service_id: &str) -> Option<ResidencyPolicy> {
        self.disk
            .lock()
            .expect("residency store mutex poisoned")
            .policies
            .get(service_id)
            .cloned()
    }

    pub fn seed_once(&self, service_id: &str, resident: bool) -> Result<ResidencyPolicy> {
        if let Some(existing) = self.get(service_id) {
            return Ok(existing);
        }
        self.put(service_id, resident, false)
    }

    pub fn put(
        &self,
        service_id: &str,
        resident: bool,
        suspended: bool,
    ) -> Result<ResidencyPolicy> {
        validate_id(service_id)?;
        let policy = ResidencyPolicy {
            service_id: service_id.to_string(),
            resident,
            suspended: resident && suspended,
            last_error: None,
            updated_at: Utc::now(),
        };
        let returned = policy.clone();
        self.stage_and_commit(move |disk| {
            disk.policies.insert(service_id.to_string(), policy);
        })?;
        Ok(returned)
    }

    pub fn set_suspended(&self, service_id: &str, suspended: bool) -> Result<()> {
        self.stage_and_commit(move |disk| {
            if let Some(policy) = disk.policies.get_mut(service_id)
                && policy.resident
            {
                policy.suspended = suspended;
                policy.last_error = None;
                policy.updated_at = Utc::now();
            }
        })
    }

    pub fn set_last_error(&self, service_id: &str, error: Option<String>) -> Result<()> {
        self.stage_and_commit(move |disk| {
            if let Some(policy) = disk.policies.get_mut(service_id) {
                policy.last_error = error;
                policy.updated_at = Utc::now();
            }
        })
    }

    pub fn delete(&self, service_id: &str) -> Result<bool> {
        validate_id(service_id)?;
        let mut removed = false;
        self.stage_and_commit(|disk| {
            removed = disk.policies.remove(service_id).is_some();
        })?;
        Ok(removed)
    }

    fn load(&self) -> Result<()> {
        let path = self.path.as_ref().expect("persistent store has path");
        let bytes = match fs::read(path) {
            Ok(bytes) => bytes,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(()),
            Err(error) => return Err(AppError::Io(error)),
        };
        if bytes.iter().all(|byte| byte.is_ascii_whitespace()) {
            return Ok(());
        }

        let value: serde_json::Value = serde_json::from_slice(&bytes)?;
        let disk = if value.get("version").is_some() {
            let parsed: ResidencyDisk = serde_json::from_value(value)?;
            if parsed.version != RESIDENCY_STORE_VERSION {
                return Err(AppError::BadRequest(format!(
                    "unsupported residency store version {}",
                    parsed.version
                )));
            }
            parsed
        } else {
            // v0 was an unversioned map keyed by service id. Normalize it to v1 on load.
            let legacy: BTreeMap<String, LegacyPolicy> = serde_json::from_value(value)?;
            ResidencyDisk {
                version: RESIDENCY_STORE_VERSION,
                policies: legacy
                    .into_iter()
                    .map(|(service_id, policy)| {
                        let normalized = ResidencyPolicy {
                            service_id: service_id.clone(),
                            resident: policy.resident,
                            suspended: policy.resident && policy.suspended,
                            last_error: None,
                            updated_at: policy.updated_at.unwrap_or_else(Utc::now),
                        };
                        (service_id, normalized)
                    })
                    .collect(),
            }
        };
        *self.disk.lock().expect("residency store mutex poisoned") = disk;
        // Persist the normalized versioned shape after a successful legacy load.
        if self.path.is_some() {
            let disk = self.disk.lock().expect("residency store mutex poisoned");
            self.flush(&disk)?;
        }
        Ok(())
    }

    fn stage_and_commit(&self, mutate: impl FnOnce(&mut ResidencyDisk)) -> Result<()> {
        let mut disk = self.disk.lock().expect("residency store mutex poisoned");
        let mut staged = disk.clone();
        mutate(&mut staged);
        self.flush(&staged)?;
        *disk = staged;
        Ok(())
    }

    fn flush(&self, disk: &ResidencyDisk) -> Result<()> {
        let Some(path) = &self.path else {
            return Ok(());
        };
        let parent = path.parent().ok_or_else(|| {
            AppError::BadRequest("residency store path has no parent".to_string())
        })?;
        fs::create_dir_all(parent)?;
        let tmp = tmp_path(path);
        let bytes = serde_json::to_vec_pretty(disk)?;
        #[cfg(unix)]
        {
            use std::{io::Write, os::unix::fs::PermissionsExt};
            let mut file = fs::OpenOptions::new()
                .create(true)
                .write(true)
                .truncate(true)
                .open(&tmp)?;
            file.write_all(&bytes)?;
            fs::set_permissions(&tmp, fs::Permissions::from_mode(0o600))?;
        }
        #[cfg(not(unix))]
        fs::write(&tmp, bytes)?;
        fs::rename(&tmp, path)?;
        Ok(())
    }
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct LegacyPolicy {
    resident: bool,
    #[serde(default)]
    suspended: bool,
    #[serde(default)]
    updated_at: Option<DateTime<Utc>>,
}

fn validate_id(id: &str) -> Result<()> {
    if id.trim().is_empty() || id != id.trim() {
        return Err(AppError::BadRequest("service id is invalid".to_string()));
    }
    Ok(())
}

fn tmp_path(path: &Path) -> PathBuf {
    let mut value = path.as_os_str().to_os_string();
    value.push(".tmp");
    PathBuf::from(value)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    #[test]
    fn seed_is_one_time_and_user_choice_wins() {
        let store = ResidencyStore::memory();
        store.seed_once("pi-web", true).unwrap();
        store.put("pi-web", false, false).unwrap();
        store.seed_once("pi-web", true).unwrap();
        assert!(!store.get("pi-web").unwrap().resident);
    }

    #[test]
    fn disabling_residency_also_clears_suspension() {
        let store = ResidencyStore::memory();
        store.put("pi-web", true, true).unwrap();
        let policy = store.put("pi-web", false, true).unwrap();
        assert!(!policy.suspended);
    }

    #[test]
    fn unversioned_store_is_migrated_to_v1() {
        let path = std::env::temp_dir().join(format!(
            "service-manager-residency-{}-{}.json",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::write(&path, r#"{"pi-web":{"resident":true,"suspended":false}}"#).unwrap();
        let store = ResidencyStore::open(&path).unwrap();
        assert!(store.get("pi-web").unwrap().resident);
        let persisted: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        assert_eq!(persisted["version"], RESIDENCY_STORE_VERSION);
        assert_eq!(persisted["policies"]["pi-web"]["serviceId"], "pi-web");
        let _ = fs::remove_file(path);
    }
}
