use std::{
    fs,
    io::Write,
    path::{Path, PathBuf},
    sync::{
        Mutex,
        atomic::{AtomicU64, Ordering},
    },
    time::Duration,
};

use axum::http::Uri;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::{
    error::{AppError, Result},
    model::ServiceEndpoint,
};

pub const RUNTIME_ENDPOINT_SNAPSHOT_SCHEMA_VERSION: u32 = 1;
pub const RUNTIME_ENDPOINT_SNAPSHOT_TTL: Duration = Duration::from_secs(120);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum RuntimeEndpointSnapshotState {
    Initializing,
    Ready,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct RuntimeEndpointSnapshot {
    pub schema_version: u32,
    pub state: RuntimeEndpointSnapshotState,
    pub manager_instance_id: String,
    pub snapshot_revision: u64,
    pub port_state_generation: u64,
    pub generated_at: DateTime<Utc>,
    pub expires_at: DateTime<Utc>,
    pub endpoints: Vec<ServiceEndpoint>,
}

#[derive(Debug)]
pub struct RuntimeEndpointSnapshotPublisher {
    path: PathBuf,
    manager_instance_id: String,
    snapshot_revision: AtomicU64,
    write_lock: Mutex<()>,
}

impl RuntimeEndpointSnapshotPublisher {
    pub fn new(path: impl Into<PathBuf>, manager_instance_id: impl Into<String>) -> Result<Self> {
        let path = path.into();
        if path.as_os_str().is_empty() {
            return Err(AppError::BadRequest(
                "runtime endpoint snapshot path is empty".to_string(),
            ));
        }
        let manager_instance_id = manager_instance_id.into().trim().to_string();
        if manager_instance_id.is_empty() {
            return Err(AppError::BadRequest(
                "runtime endpoint manager instance id is empty".to_string(),
            ));
        }
        Ok(Self {
            path,
            manager_instance_id,
            snapshot_revision: AtomicU64::new(0),
            write_lock: Mutex::new(()),
        })
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn write_initializing(
        &self,
        port_state_generation: u64,
        generated_at: DateTime<Utc>,
    ) -> Result<RuntimeEndpointSnapshot> {
        self.write(
            RuntimeEndpointSnapshotState::Initializing,
            port_state_generation,
            generated_at,
            Vec::new(),
        )
    }

    pub fn write_ready(
        &self,
        port_state_generation: u64,
        generated_at: DateTime<Utc>,
        mut endpoints: Vec<ServiceEndpoint>,
    ) -> Result<RuntimeEndpointSnapshot> {
        endpoints.retain(endpoint_is_consumer_safe);
        endpoints.sort_by(|left, right| {
            (&left.service_id.0, &left.name).cmp(&(&right.service_id.0, &right.name))
        });
        self.write(
            RuntimeEndpointSnapshotState::Ready,
            port_state_generation,
            generated_at,
            endpoints,
        )
    }

    fn write(
        &self,
        state: RuntimeEndpointSnapshotState,
        port_state_generation: u64,
        generated_at: DateTime<Utc>,
        endpoints: Vec<ServiceEndpoint>,
    ) -> Result<RuntimeEndpointSnapshot> {
        let _guard = self
            .write_lock
            .lock()
            .expect("runtime endpoint snapshot write lock poisoned");
        let snapshot_revision = self
            .snapshot_revision
            .load(Ordering::Acquire)
            .checked_add(1)
            .ok_or_else(|| {
                AppError::BadRequest("runtime endpoint snapshot revision exhausted".to_string())
            })?;
        let expires_at = generated_at
            + chrono::Duration::from_std(RUNTIME_ENDPOINT_SNAPSHOT_TTL)
                .map_err(|_| AppError::Internal)?;
        let snapshot = RuntimeEndpointSnapshot {
            schema_version: RUNTIME_ENDPOINT_SNAPSHOT_SCHEMA_VERSION,
            state,
            manager_instance_id: self.manager_instance_id.clone(),
            snapshot_revision,
            port_state_generation,
            generated_at,
            expires_at,
            endpoints,
        };
        atomic_write_json_0600(&self.path, &snapshot)?;
        self.snapshot_revision
            .store(snapshot_revision, Ordering::Release);
        Ok(snapshot)
    }
}

/// The runtime file is a local consumer contract, not a general reverse proxy registry. Only
/// loopback HTTP/TCP endpoints without credentials or URL query/fragment data are safe to expose.
pub fn endpoint_is_consumer_safe(endpoint: &ServiceEndpoint) -> bool {
    if endpoint.protocol != crate::model::ServicePortProtocol::Tcp || endpoint.port == 0 {
        return false;
    }
    let declared_host = normalize_loopback_host(&endpoint.host);
    let Ok(uri) = endpoint.url.parse::<Uri>() else {
        return false;
    };
    if uri.scheme_str() != Some("http") || endpoint.url.contains('#') {
        return false;
    }
    let Some(authority) = uri.authority() else {
        return false;
    };
    if authority.as_str().contains('@') || uri.query().is_some() {
        return false;
    }
    let Some(url_host) = normalize_loopback_host(authority.host()) else {
        return false;
    };
    let Some(declared_host) = declared_host else {
        return false;
    };
    if url_host != declared_host || authority.port_u16() != Some(endpoint.port) {
        return false;
    }
    true
}

fn normalize_loopback_host(value: &str) -> Option<String> {
    let host = value.trim().trim_start_matches('[').trim_end_matches(']');
    match host.to_ascii_lowercase().as_str() {
        "127.0.0.1" => Some("127.0.0.1".to_string()),
        "localhost" => Some("localhost".to_string()),
        "::1" => Some("::1".to_string()),
        _ => None,
    }
}

fn atomic_write_json_0600(path: &Path, value: &impl Serialize) -> Result<()> {
    let parent = path.parent().ok_or_else(|| {
        AppError::BadRequest("runtime endpoint snapshot path has no parent dir".to_string())
    })?;
    fs::create_dir_all(parent)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        fs::set_permissions(parent, fs::Permissions::from_mode(0o700))?;
    }

    let bytes = serde_json::to_vec_pretty(value)?;
    let tmp = temporary_path(path);
    let result = (|| -> Result<()> {
        let mut options = fs::OpenOptions::new();
        options.create(true).write(true).truncate(true);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        let mut file = options.open(&tmp)?;
        file.write_all(&bytes)?;
        file.sync_all()?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(&tmp, fs::Permissions::from_mode(0o600))?;
        }
        fs::rename(&tmp, path)?;
        sync_parent(parent)?;
        Ok(())
    })();
    if result.is_err() {
        let _ = fs::remove_file(&tmp);
    }
    result
}

fn temporary_path(path: &Path) -> PathBuf {
    let mut value = path.as_os_str().to_os_string();
    value.push(format!(".tmp.{}", std::process::id()));
    PathBuf::from(value)
}

fn sync_parent(parent: &Path) -> Result<()> {
    #[cfg(unix)]
    {
        fs::File::open(parent)?.sync_all()?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{ServiceId, ServicePortProtocol};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn test_dir(name: &str) -> PathBuf {
        let stamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let dir = std::env::temp_dir().join(format!(
            "service-manager-runtime-endpoints-{name}-{}-{stamp}",
            std::process::id()
        ));
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    fn endpoint(service_id: &str, name: &str, port: u16) -> ServiceEndpoint {
        ServiceEndpoint {
            service_id: ServiceId::new(service_id),
            name: name.to_string(),
            host: "127.0.0.1".to_string(),
            port,
            protocol: ServicePortProtocol::Tcp,
            url: format!("http://127.0.0.1:{port}/"),
            generation: 7,
            published_at: Utc::now(),
        }
    }

    #[test]
    fn writes_initializing_then_ready_snapshots_with_monotonic_revision() {
        let dir = test_dir("states");
        let path = dir.join("runtime/endpoints.json");
        let publisher = RuntimeEndpointSnapshotPublisher::new(&path, "manager-test").unwrap();
        let generated_at = Utc::now();

        let initializing = publisher.write_initializing(3, generated_at).unwrap();
        assert_eq!(initializing.schema_version, 1);
        assert_eq!(
            initializing.state,
            RuntimeEndpointSnapshotState::Initializing
        );
        assert_eq!(initializing.snapshot_revision, 1);
        assert!(initializing.endpoints.is_empty());
        assert_eq!(
            initializing.expires_at - initializing.generated_at,
            chrono::Duration::seconds(120)
        );

        let ready = publisher
            .write_ready(
                8,
                generated_at + chrono::Duration::seconds(1),
                vec![
                    endpoint("svc-b", "web", 24002),
                    endpoint("svc-a", "api", 24001),
                ],
            )
            .unwrap();
        assert_eq!(ready.state, RuntimeEndpointSnapshotState::Ready);
        assert_eq!(ready.snapshot_revision, 2);
        assert_eq!(ready.port_state_generation, 8);
        assert_eq!(ready.endpoints[0].service_id.0, "svc-a");
        assert_eq!(ready.endpoints[1].service_id.0, "svc-b");

        let on_disk: RuntimeEndpointSnapshot =
            serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        assert_eq!(on_disk, ready);
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            assert_eq!(
                fs::metadata(&path).unwrap().permissions().mode() & 0o777,
                0o600
            );
        }
        assert!(!temporary_path(&path).exists());
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn overwrites_unknown_existing_schema_without_reading_it() {
        let dir = test_dir("replace");
        let path = dir.join("endpoints.json");
        fs::write(&path, br#"{"legacySchema":99,"endpoints":"stale"}"#).unwrap();
        let publisher = RuntimeEndpointSnapshotPublisher::new(&path, "manager-new").unwrap();

        publisher.write_initializing(0, Utc::now()).unwrap();
        let value: serde_json::Value = serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
        assert_eq!(value["schemaVersion"], 1);
        assert_eq!(value["state"], "initializing");
        assert!(value.get("legacySchema").is_none());
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn failed_write_does_not_advance_snapshot_revision() {
        let dir = test_dir("failure");
        let blocked_parent = dir.join("blocked");
        fs::write(&blocked_parent, b"not-a-directory").unwrap();
        let publisher = RuntimeEndpointSnapshotPublisher::new(
            blocked_parent.join("endpoints.json"),
            "manager-test",
        )
        .unwrap();

        assert!(publisher.write_initializing(1, Utc::now()).is_err());
        assert_eq!(publisher.snapshot_revision.load(Ordering::Acquire), 0);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn mixed_endpoint_batch_keeps_safe_loopback_http_tcp_only() {
        let dir = test_dir("filter");
        let path = dir.join("endpoints.json");
        let publisher = RuntimeEndpointSnapshotPublisher::new(&path, "manager-test").unwrap();
        let endpoints = vec![
            endpoint("safe", "web", 24001),
            ServiceEndpoint {
                url: "http://10.0.0.2:24002/".to_string(),
                ..endpoint("remote", "web", 24002)
            },
            ServiceEndpoint {
                url: "http://127.0.0.1:24003/?token=secret".to_string(),
                ..endpoint("query", "web", 24003)
            },
            ServiceEndpoint {
                protocol: ServicePortProtocol::Udp,
                url: "http://127.0.0.1:24004/".to_string(),
                ..endpoint("udp", "web", 24004)
            },
            ServiceEndpoint {
                url: "http://user:pass@127.0.0.1:24005/".to_string(),
                ..endpoint("credentials", "web", 24005)
            },
        ];
        let snapshot = publisher.write_ready(4, Utc::now(), endpoints).unwrap();
        assert_eq!(snapshot.endpoints.len(), 1);
        assert_eq!(snapshot.endpoints[0].service_id.0, "safe");
        let _ = fs::remove_dir_all(dir);
    }
}
