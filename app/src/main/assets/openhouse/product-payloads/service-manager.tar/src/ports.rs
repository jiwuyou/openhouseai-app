use std::{
    collections::BTreeMap,
    fs,
    io::Write,
    net::{TcpListener, UdpSocket},
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
};

use chrono::Utc;
use serde::{Deserialize, Serialize};

use crate::{
    error::{AppError, Result},
    model::{
        PortConflictDiagnostic, PortConflictReason, PortLease, PortLeaseLifecycle, PortPoolSpec,
        ServiceEndpoint, ServiceId, ServicePortProtocol, ServicePortSpec,
    },
};

const PORT_STATE_VERSION: u32 = 2;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PortDisk {
    version: u32,
    generation: u64,
    #[serde(default)]
    leases: BTreeMap<String, PortLease>,
    #[serde(default)]
    endpoints: BTreeMap<String, ServiceEndpoint>,
    #[serde(default)]
    orphans: BTreeMap<String, PortLease>,
}

impl Default for PortDisk {
    fn default() -> Self {
        Self {
            version: PORT_STATE_VERSION,
            generation: 0,
            leases: BTreeMap::new(),
            endpoints: BTreeMap::new(),
            orphans: BTreeMap::new(),
        }
    }
}

#[derive(Debug)]
pub struct PortManager {
    path: PathBuf,
    pools: BTreeMap<String, PortPoolSpec>,
    probe: Arc<dyn PortProbe>,
    disk: Mutex<PortDisk>,
}

trait PortProbe: std::fmt::Debug + Send + Sync {
    fn available(&self, host: &str, port: u16, protocol: ServicePortProtocol) -> Result<bool>;
}

#[derive(Debug)]
struct SystemPortProbe;

impl PortProbe for SystemPortProbe {
    fn available(&self, host: &str, port: u16, protocol: ServicePortProtocol) -> Result<bool> {
        let result = match protocol {
            ServicePortProtocol::Tcp => TcpListener::bind((host, port)).map(drop),
            ServicePortProtocol::Udp => UdpSocket::bind((host, port)).map(drop),
        };
        match result {
            Ok(()) => Ok(true),
            Err(error) if error.kind() == std::io::ErrorKind::AddrInUse => Ok(false),
            Err(error) => Err(AppError::BadRequest(format!(
                "cannot probe {protocol:?} port {host}:{port}: {error}"
            ))),
        }
    }
}

#[allow(dead_code)]
impl PortManager {
    pub fn open(path: impl Into<PathBuf>, pools: Vec<PortPoolSpec>) -> Result<Self> {
        Self::open_with_probe(path, pools, Arc::new(SystemPortProbe))
    }

    fn open_with_probe(
        path: impl Into<PathBuf>,
        pools: Vec<PortPoolSpec>,
        probe: Arc<dyn PortProbe>,
    ) -> Result<Self> {
        let path = path.into();
        if path.as_os_str().is_empty() {
            return Err(AppError::BadRequest(
                "port lease store path is empty".to_string(),
            ));
        }

        let pools = normalize_pools(pools)?;
        let disk = load_disk(&path)?;
        if disk.version != PORT_STATE_VERSION {
            return Err(AppError::BadRequest(format!(
                "unsupported port lease store version: {}",
                disk.version
            )));
        }

        Ok(Self {
            path,
            pools,
            probe,
            disk: Mutex::new(disk),
        })
    }

    pub fn pools(&self) -> Vec<PortPoolSpec> {
        self.pools.values().cloned().collect()
    }

    pub fn generation(&self) -> u64 {
        self.disk
            .lock()
            .expect("port manager mutex poisoned")
            .generation
    }

    pub fn allocate(
        &self,
        service_id: &ServiceId,
        specs: &[ServicePortSpec],
    ) -> Result<Vec<PortLease>> {
        if service_id.0.trim().is_empty() {
            return Err(AppError::BadRequest("service id is empty".to_string()));
        }
        let mut normalized = Vec::with_capacity(specs.len());
        let mut names = std::collections::BTreeSet::new();
        for spec in specs {
            let mut spec = spec.clone();
            spec.validate()?;
            if !names.insert(spec.name.clone()) {
                return Err(AppError::BadRequest(format!(
                    "duplicate port name: {}",
                    spec.name
                )));
            }
            if !self.pools.contains_key(&spec.pool) {
                return Err(AppError::BadRequest(format!(
                    "port pool not found: {}",
                    spec.pool
                )));
            }
            normalized.push(spec);
        }

        let mut disk = self.disk.lock().expect("port manager mutex poisoned");
        let mut staged = disk.clone();
        let initial_generation = staged.generation;
        let stale_keys: Vec<String> = staged
            .leases
            .iter()
            .filter(|(_, lease)| {
                lease.service_id == *service_id && !names.contains(&lease.port_name)
            })
            .map(|(key, _)| key.clone())
            .collect();
        if !stale_keys.is_empty() {
            staged.generation = next_generation(staged.generation)?;
            for key in stale_keys {
                staged.leases.remove(&key);
                staged.endpoints.remove(&key);
            }
        }
        let mut leases = Vec::with_capacity(normalized.len());
        for spec in &normalized {
            let pool = self
                .pools
                .get(&spec.pool)
                .expect("pool existence checked above");
            leases.push(allocate_in_disk(
                &mut staged,
                service_id,
                spec,
                pool,
                self.probe.as_ref(),
            )?);
        }
        if staged.generation != initial_generation {
            self.flush(&staged)?;
            *disk = staged;
        }
        Ok(leases)
    }

    pub fn allocate_port(
        &self,
        service_id: &ServiceId,
        spec: &ServicePortSpec,
    ) -> Result<PortLease> {
        self.allocate(service_id, std::slice::from_ref(spec))?
            .into_iter()
            .next()
            .ok_or_else(|| AppError::BadRequest("port specification is missing".to_string()))
    }

    pub fn publish(&self, service_id: &ServiceId) -> Result<()> {
        let mut disk = self.disk.lock().expect("port manager mutex poisoned");
        let leases: Vec<(String, PortLease)> = disk
            .leases
            .iter()
            .filter(|(_, lease)| lease.service_id == *service_id && lease.endpoint.is_some())
            .map(|(key, lease)| (key.clone(), lease.clone()))
            .collect();
        if leases.is_empty() {
            return Ok(());
        }

        let already_published = leases.iter().all(|(key, lease)| {
            let endpoint_spec = lease.endpoint.as_ref().expect("endpoint checked above");
            lease.lifecycle == PortLeaseLifecycle::Published
                && disk.endpoints.get(key).is_some_and(|endpoint| {
                    endpoint.service_id == *service_id
                        && endpoint.name == lease.port_name
                        && endpoint.host == lease.host
                        && endpoint.port == lease.allocated_port
                        && endpoint.protocol == lease.protocol
                        && endpoint.url
                            == endpoint_url(
                                &endpoint_spec.scheme,
                                &lease.host,
                                lease.allocated_port,
                                &endpoint_spec.path,
                            )
                })
        });
        if already_published {
            return Ok(());
        }

        let mut staged = disk.clone();
        staged.generation = next_generation(staged.generation)?;
        let published_at = Utc::now();
        for (key, lease) in leases {
            let endpoint_spec = lease.endpoint.as_ref().expect("endpoint checked above");
            let endpoint = ServiceEndpoint {
                service_id: service_id.clone(),
                name: lease.port_name,
                host: lease.host.clone(),
                port: lease.allocated_port,
                protocol: lease.protocol,
                url: endpoint_url(
                    &endpoint_spec.scheme,
                    &lease.host,
                    lease.allocated_port,
                    &endpoint_spec.path,
                ),
                generation: staged.generation,
                published_at,
            };
            staged.endpoints.insert(key.clone(), endpoint);
            let staged_lease = staged
                .leases
                .get_mut(&key)
                .expect("published lease must still exist");
            staged_lease.lifecycle = PortLeaseLifecycle::Published;
            staged_lease.orphan_reason = None;
            staged_lease.generation = staged.generation;
        }
        self.flush(&staged)?;
        *disk = staged;
        Ok(())
    }

    pub fn unpublish(&self, service_id: &ServiceId) -> Result<()> {
        self.mutate_if_changed(|disk, generation| {
            let before = disk.endpoints.len();
            disk.endpoints
                .retain(|_, endpoint| endpoint.service_id != *service_id);
            let mut changed = disk.endpoints.len() != before;
            for lease in disk
                .leases
                .values_mut()
                .filter(|lease| lease.service_id == *service_id)
            {
                if lease.lifecycle == PortLeaseLifecycle::Published {
                    lease.lifecycle = PortLeaseLifecycle::Leased;
                    lease.generation = generation;
                    changed = true;
                }
            }
            Ok(changed)
        })?;
        Ok(())
    }

    pub fn unpublish_port(&self, service_id: &ServiceId, port_name: &str) -> Result<bool> {
        let key = lease_key(service_id, port_name);
        self.mutate_if_changed(|disk, generation| {
            let mut changed = disk.endpoints.remove(&key).is_some();
            if let Some(lease) = disk.leases.get_mut(&key)
                && lease.lifecycle == PortLeaseLifecycle::Published
            {
                lease.lifecycle = PortLeaseLifecycle::Leased;
                lease.generation = generation;
                changed = true;
            }
            Ok(changed)
        })
    }

    pub fn release(&self, service_id: &ServiceId) -> Result<()> {
        self.mutate_if_changed(|disk, _| {
            let endpoint_count = disk.endpoints.len();
            let lease_count = disk.leases.len();
            disk.endpoints
                .retain(|_, endpoint| endpoint.service_id != *service_id);
            disk.leases
                .retain(|_, lease| lease.service_id != *service_id);
            Ok(disk.endpoints.len() != endpoint_count || disk.leases.len() != lease_count)
        })?;
        Ok(())
    }

    pub fn release_port(&self, service_id: &ServiceId, port_name: &str) -> Result<bool> {
        let key = lease_key(service_id, port_name);
        self.mutate_if_changed(|disk, _| {
            let endpoint_removed = disk.endpoints.remove(&key).is_some();
            let lease_removed = disk.leases.remove(&key).is_some();
            Ok(endpoint_removed || lease_removed)
        })
    }

    pub fn mark_orphan(&self, service_id: &ServiceId, reason: &str) -> Result<()> {
        let reason = normalize_orphan_reason(reason)?;
        self.mutate_if_changed(|disk, generation| {
            let keys: Vec<String> = disk
                .leases
                .iter()
                .filter(|(_, lease)| lease.service_id == *service_id)
                .map(|(key, _)| key.clone())
                .collect();
            for key in &keys {
                archive_orphan(disk, key, &reason, generation);
            }
            Ok(!keys.is_empty())
        })?;
        Ok(())
    }

    pub fn mark_port_orphan(
        &self,
        service_id: &ServiceId,
        port_name: &str,
        reason: &str,
    ) -> Result<bool> {
        let reason = normalize_orphan_reason(reason)?;
        let key = lease_key(service_id, port_name);
        self.mutate_if_changed(|disk, generation| {
            if !disk.leases.contains_key(&key) {
                return Ok(false);
            }
            archive_orphan(disk, &key, &reason, generation);
            Ok(true)
        })
    }

    /// Releases one orphan reservation after the caller has confirmed its process is gone.
    /// Orphans are never released automatically because a temporarily non-listening process may
    /// bind the port again later.
    pub fn release_orphan(
        &self,
        service_id: &ServiceId,
        port_name: &str,
        orphan_generation: u64,
    ) -> Result<bool> {
        let key = orphan_record_key(service_id, port_name, orphan_generation);
        self.mutate_if_changed(|disk, _| Ok(disk.orphans.remove(&key).is_some()))
    }

    pub fn lease(&self, service_id: &ServiceId, port_name: &str) -> Result<PortLease> {
        let disk = self.disk.lock().expect("port manager mutex poisoned");
        disk.leases
            .get(&lease_key(service_id, port_name))
            .cloned()
            .ok_or(AppError::NotFound)
    }

    pub fn list_leases(&self) -> Vec<PortLease> {
        self.disk
            .lock()
            .expect("port manager mutex poisoned")
            .leases
            .values()
            .cloned()
            .collect()
    }

    pub fn list_orphans(&self) -> Vec<PortLease> {
        self.disk
            .lock()
            .expect("port manager mutex poisoned")
            .orphans
            .values()
            .cloned()
            .collect()
    }

    pub fn leases(&self, service_id: &ServiceId) -> Result<Vec<PortLease>> {
        Ok(self
            .disk
            .lock()
            .expect("port manager mutex poisoned")
            .leases
            .values()
            .filter(|lease| lease.service_id == *service_id)
            .cloned()
            .collect())
    }

    pub fn has_leases(&self, service_id: &ServiceId) -> Result<bool> {
        Ok(self
            .disk
            .lock()
            .expect("port manager mutex poisoned")
            .leases
            .values()
            .any(|lease| lease.service_id == *service_id))
    }

    pub fn endpoint(&self, service_id: &ServiceId, name: &str) -> Result<Option<ServiceEndpoint>> {
        let disk = self.disk.lock().expect("port manager mutex poisoned");
        Ok(disk.endpoints.get(&lease_key(service_id, name)).cloned())
    }

    pub fn endpoints(&self, service_id: &ServiceId) -> Result<Vec<ServiceEndpoint>> {
        Ok(self
            .disk
            .lock()
            .expect("port manager mutex poisoned")
            .endpoints
            .values()
            .filter(|endpoint| endpoint.service_id == *service_id)
            .cloned()
            .collect())
    }

    pub fn list_endpoints(&self) -> Vec<ServiceEndpoint> {
        self.disk
            .lock()
            .expect("port manager mutex poisoned")
            .endpoints
            .values()
            .cloned()
            .collect()
    }

    pub fn snapshot(&self) -> Result<serde_json::Value> {
        let disk = self.disk.lock().expect("port manager mutex poisoned");
        Ok(serde_json::to_value(&*disk)?)
    }

    fn mutate_if_changed<F>(&self, mutate: F) -> Result<bool>
    where
        F: FnOnce(&mut PortDisk, u64) -> Result<bool>,
    {
        let mut disk = self.disk.lock().expect("port manager mutex poisoned");
        let mut staged = disk.clone();
        let generation = next_generation(staged.generation)?;
        if !mutate(&mut staged, generation)? {
            return Ok(false);
        }
        staged.generation = generation;
        self.flush(&staged)?;
        *disk = staged;
        Ok(true)
    }

    fn flush(&self, disk: &PortDisk) -> Result<()> {
        let parent = self.path.parent().ok_or_else(|| {
            AppError::BadRequest("port lease store path has no parent dir".to_string())
        })?;
        fs::create_dir_all(parent)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(parent, fs::Permissions::from_mode(0o700))?;
        }

        let bytes = serde_json::to_vec_pretty(disk)?;
        let tmp = tmp_path(&self.path);
        let mut options = fs::OpenOptions::new();
        options.create(true).write(true).truncate(true);
        let mut file = options.open(&tmp)?;
        file.write_all(&bytes)?;
        file.sync_all()?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(&tmp, fs::Permissions::from_mode(0o600))?;
        }

        if let Err(rename_error) = fs::rename(&tmp, &self.path) {
            let _ = fs::remove_file(&self.path);
            fs::rename(&tmp, &self.path).map_err(|_| AppError::Io(rename_error))?;
        }
        sync_parent(parent)?;
        Ok(())
    }
}

fn normalize_pools(pools: Vec<PortPoolSpec>) -> Result<BTreeMap<String, PortPoolSpec>> {
    let pools = if pools.is_empty() {
        vec![PortPoolSpec::local_web_default()]
    } else {
        pools
    };
    let mut normalized = BTreeMap::new();
    for mut pool in pools {
        pool.validate()?;
        if normalized.insert(pool.name.clone(), pool.clone()).is_some() {
            return Err(AppError::BadRequest(format!(
                "duplicate port pool: {}",
                pool.name
            )));
        }
    }
    Ok(normalized)
}

fn load_disk(path: &Path) -> Result<PortDisk> {
    match fs::read(path) {
        Ok(bytes) if bytes.iter().all(|byte| byte.is_ascii_whitespace()) => Ok(PortDisk::default()),
        Ok(bytes) => Ok(serde_json::from_slice(&bytes)?),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(PortDisk::default()),
        Err(error) => Err(AppError::Io(error)),
    }
}

fn next_generation(current: u64) -> Result<u64> {
    current
        .checked_add(1)
        .ok_or_else(|| AppError::BadRequest("port state generation exhausted".to_string()))
}

fn lease_key(service_id: &ServiceId, port_name: &str) -> String {
    format!("{}\u{0}{}", service_id.0, port_name.trim())
}

fn orphan_key(lease: &PortLease) -> String {
    orphan_record_key(&lease.service_id, &lease.port_name, lease.generation)
}

fn orphan_record_key(service_id: &ServiceId, port_name: &str, generation: u64) -> String {
    format!("{}\u{0}{}\u{0}{}", service_id.0, port_name, generation)
}

fn normalize_orphan_reason(reason: &str) -> Result<String> {
    let reason = reason.trim();
    if reason.is_empty() {
        return Err(AppError::BadRequest(
            "orphan reason is required".to_string(),
        ));
    }
    Ok(reason.to_string())
}

fn archive_orphan(disk: &mut PortDisk, key: &str, reason: &str, generation: u64) {
    let Some(mut lease) = disk.leases.remove(key) else {
        return;
    };
    disk.endpoints.remove(key);
    lease.lifecycle = PortLeaseLifecycle::Orphaned;
    lease.orphan_reason = Some(reason.to_string());
    lease.generation = generation;
    disk.orphans.insert(orphan_key(&lease), lease);
}

fn allocate_in_disk(
    disk: &mut PortDisk,
    service_id: &ServiceId,
    spec: &ServicePortSpec,
    pool: &PortPoolSpec,
    probe: &dyn PortProbe,
) -> Result<PortLease> {
    let key = lease_key(service_id, &spec.name);
    if let Some(existing) = disk.leases.get(&key).cloned()
        && lease_matches_spec(&existing, spec)
        && port_in_pool(existing.allocated_port, pool)
    {
        let published = existing.lifecycle == PortLeaseLifecycle::Published
            && disk.endpoints.contains_key(&key);
        let reusable = published
            || (port_not_leased_by_other(disk, &key, existing.allocated_port, existing.protocol)
                && probe.available(&existing.host, existing.allocated_port, existing.protocol)?);
        if reusable {
            return Ok(existing);
        }
    }

    let preferred_reservation =
        port_reservation_conflict(disk, &key, spec.preferred, spec.protocol);
    let preferred_available = preferred_reservation.is_none()
        && probe.available(&spec.host, spec.preferred, spec.protocol)?;
    let conflict = (!preferred_available).then(|| PortConflictDiagnostic {
        preferred_port: spec.preferred,
        reason: preferred_reservation.unwrap_or(PortConflictReason::AddressInUse),
        observed_at: Utc::now(),
    });
    let allocated_port = if preferred_available {
        spec.preferred
    } else if !spec.dynamic {
        return Err(AppError::BadRequest(format!(
            "preferred port {} is unavailable for {}/{}",
            spec.preferred, service_id, spec.name
        )));
    } else {
        find_available_in_pool(disk, &key, spec, pool, probe)?.ok_or_else(|| {
            AppError::BadRequest(format!("no available ports in pool: {}", pool.name))
        })?
    };

    disk.generation = next_generation(disk.generation)?;
    disk.endpoints.remove(&key);
    let lease = PortLease {
        service_id: service_id.clone(),
        port_name: spec.name.clone(),
        host: spec.host.clone(),
        preferred_port: spec.preferred,
        allocated_port,
        dynamic: spec.dynamic,
        pool: spec.pool.clone(),
        protocol: spec.protocol,
        env_var: spec.env_var.clone(),
        endpoint: spec.endpoint.clone(),
        conflict,
        lifecycle: PortLeaseLifecycle::Leased,
        orphan_reason: None,
        generation: disk.generation,
        allocated_at: Utc::now(),
    };
    disk.leases.insert(key, lease.clone());
    Ok(lease)
}

fn port_in_pool(port: u16, pool: &PortPoolSpec) -> bool {
    (pool.start..=pool.end).contains(&port)
}

fn lease_matches_spec(lease: &PortLease, spec: &ServicePortSpec) -> bool {
    lease.host == spec.host
        && lease.preferred_port == spec.preferred
        && lease.dynamic == spec.dynamic
        && lease.pool == spec.pool
        && lease.protocol == spec.protocol
        && lease.env_var == spec.env_var
        && lease.endpoint == spec.endpoint
}

fn port_not_leased_by_other(
    disk: &PortDisk,
    current_key: &str,
    port: u16,
    protocol: ServicePortProtocol,
) -> bool {
    port_reservation_conflict(disk, current_key, port, protocol).is_none()
}

fn port_reservation_conflict(
    disk: &PortDisk,
    current_key: &str,
    port: u16,
    protocol: ServicePortProtocol,
) -> Option<PortConflictReason> {
    if disk.leases.iter().any(|(key, lease)| {
        key != current_key && lease.allocated_port == port && lease.protocol == protocol
    }) {
        return Some(PortConflictReason::ManagedLease);
    }
    if disk
        .orphans
        .values()
        .any(|lease| lease.allocated_port == port && lease.protocol == protocol)
    {
        return Some(PortConflictReason::OrphanedLease);
    }
    None
}

fn find_available_in_pool(
    disk: &PortDisk,
    key: &str,
    spec: &ServicePortSpec,
    pool: &PortPoolSpec,
    probe: &dyn PortProbe,
) -> Result<Option<u16>> {
    for port in pool.start..=pool.end {
        if port == spec.preferred {
            continue;
        }
        if port_not_leased_by_other(disk, key, port, spec.protocol)
            && probe.available(&spec.host, port, spec.protocol)?
        {
            return Ok(Some(port));
        }
    }
    Ok(None)
}

fn endpoint_url(scheme: &str, host: &str, port: u16, path: &str) -> String {
    let display_host = if host.contains(':') && !host.starts_with('[') {
        format!("[{host}]")
    } else {
        host.to_string()
    };
    format!("{scheme}://{display_host}:{port}{path}")
}

fn tmp_path(path: &Path) -> PathBuf {
    let mut value = path.as_os_str().to_os_string();
    value.push(format!(".tmp.{}", std::process::id()));
    PathBuf::from(value)
}

fn sync_parent(parent: &Path) -> Result<()> {
    #[cfg(unix)]
    {
        fs::File::open(parent)?.sync_all()?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::ServiceEndpointSpec;
    use std::collections::BTreeSet;
    use std::sync::Arc;
    use std::time::{SystemTime, UNIX_EPOCH};

    #[derive(Debug, Default)]
    struct ControlledPortProbe {
        unavailable: Mutex<BTreeSet<(u8, u16)>>,
    }

    impl ControlledPortProbe {
        fn set_unavailable(&self, protocol: ServicePortProtocol, port: u16) {
            self.unavailable
                .lock()
                .unwrap()
                .insert((protocol_key(protocol), port));
        }
    }

    impl PortProbe for ControlledPortProbe {
        fn available(&self, _host: &str, port: u16, protocol: ServicePortProtocol) -> Result<bool> {
            Ok(!self
                .unavailable
                .lock()
                .unwrap()
                .contains(&(protocol_key(protocol), port)))
        }
    }

    fn protocol_key(protocol: ServicePortProtocol) -> u8 {
        match protocol {
            ServicePortProtocol::Tcp => 0,
            ServicePortProtocol::Udp => 1,
        }
    }

    fn test_dir(name: &str) -> PathBuf {
        let stamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "service-manager-ports-{name}-{}-{stamp}",
            std::process::id()
        ));
        fs::create_dir_all(&path).unwrap();
        path
    }

    fn test_manager(
        path: impl Into<PathBuf>,
        pools: Vec<PortPoolSpec>,
    ) -> (PortManager, Arc<ControlledPortProbe>) {
        let probe = Arc::new(ControlledPortProbe::default());
        let manager = PortManager::open_with_probe(path, pools, probe.clone()).unwrap();
        (manager, probe)
    }

    fn pool_range(name: &str, start: u16, end: u16) -> PortPoolSpec {
        PortPoolSpec {
            name: name.to_string(),
            start,
            end,
        }
    }

    fn pool(name: &str, port: u16) -> PortPoolSpec {
        PortPoolSpec {
            name: name.to_string(),
            start: port,
            end: port,
        }
    }

    fn spec(preferred: u16, dynamic: bool, pool: &str) -> ServicePortSpec {
        ServicePortSpec {
            name: "web".to_string(),
            host: "127.0.0.1".to_string(),
            preferred,
            dynamic,
            pool: pool.to_string(),
            protocol: ServicePortProtocol::Tcp,
            env_var: "PORT".to_string(),
            endpoint: Some(ServiceEndpointSpec {
                scheme: "http".to_string(),
                path: "/health".to_string(),
            }),
        }
    }

    #[test]
    fn allocation_prefers_preferred_port() {
        let dir = test_dir("preferred");
        let preferred = 30_141;
        let (manager, _) = test_manager(dir.join("ports.json"), vec![]);
        let lease = manager
            .allocate_port(
                &ServiceId::new("svc-a"),
                &spec(preferred, true, "local-web"),
            )
            .unwrap();
        assert_eq!(lease.allocated_port, preferred);
        assert_eq!(lease.generation, 1);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn dynamic_allocation_falls_back_to_pool() {
        let dir = test_dir("fallback");
        let preferred = 30_141;
        let fallback = 30_142;
        let (manager, probe) = test_manager(dir.join("ports.json"), vec![pool("test", fallback)]);
        probe.set_unavailable(ServicePortProtocol::Tcp, preferred);
        let lease = manager
            .allocate_port(&ServiceId::new("svc-a"), &spec(preferred, true, "test"))
            .unwrap();
        assert_eq!(lease.allocated_port, fallback);
        assert_eq!(lease.lifecycle, PortLeaseLifecycle::Leased);
        let conflict = lease.conflict.unwrap();
        assert_eq!(conflict.preferred_port, preferred);
        assert_eq!(conflict.reason, PortConflictReason::AddressInUse);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn static_allocation_rejects_conflict() {
        let dir = test_dir("static-conflict");
        let preferred = 30_141;
        let (manager, probe) = test_manager(dir.join("ports.json"), vec![]);
        probe.set_unavailable(ServicePortProtocol::Tcp, preferred);
        let error = manager
            .allocate_port(
                &ServiceId::new("svc-a"),
                &spec(preferred, false, "local-web"),
            )
            .unwrap_err();
        assert!(error.to_string().contains("preferred port"));
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn different_services_never_receive_same_lease() {
        let dir = test_dir("unique");
        let preferred = 30_141;
        let fallback = 30_142;
        let (manager, _) = test_manager(dir.join("ports.json"), vec![pool("test", fallback)]);
        let first = manager
            .allocate_port(&ServiceId::new("svc-a"), &spec(preferred, true, "test"))
            .unwrap();
        let second = manager
            .allocate_port(&ServiceId::new("svc-b"), &spec(preferred, true, "test"))
            .unwrap();
        assert_eq!(first.allocated_port, preferred);
        assert_eq!(second.allocated_port, fallback);
        assert_ne!(first.allocated_port, second.allocated_port);
        assert_eq!(
            second.conflict.as_ref().unwrap().reason,
            PortConflictReason::ManagedLease
        );
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn leases_and_endpoints_survive_reopen() {
        let dir = test_dir("reopen");
        let path = dir.join("ports.json");
        let preferred = 30_141;
        let generation;
        {
            let (manager, _) = test_manager(&path, vec![]);
            manager
                .allocate_port(
                    &ServiceId::new("svc-a"),
                    &spec(preferred, true, "local-web"),
                )
                .unwrap();
            manager.publish(&ServiceId::new("svc-a")).unwrap();
            let endpoint = manager
                .endpoint(&ServiceId::new("svc-a"), "web")
                .unwrap()
                .unwrap();
            assert_eq!(endpoint.url, format!("http://127.0.0.1:{preferred}/health"));
            generation = manager.generation();
        }

        let (reopened, _) = test_manager(&path, vec![]);
        assert_eq!(reopened.generation(), generation);
        assert_eq!(
            reopened
                .lease(&ServiceId::new("svc-a"), "web")
                .unwrap()
                .allocated_port,
            preferred
        );
        assert_eq!(
            reopened
                .endpoint(&ServiceId::new("svc-a"), "web")
                .unwrap()
                .unwrap()
                .port,
            preferred
        );
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn generation_increases_for_each_state_change() {
        let dir = test_dir("generation");
        let (manager, _) = test_manager(dir.join("ports.json"), vec![]);
        let id = ServiceId::new("svc-a");
        let preferred = 30_141;
        let lease = manager
            .allocate_port(&id, &spec(preferred, true, "local-web"))
            .unwrap();
        manager.publish(&id).unwrap();
        let endpoint = manager.endpoint(&id, "web").unwrap().unwrap();
        assert_eq!(endpoint.generation, manager.generation());
        assert_eq!(
            manager.lease(&id, "web").unwrap().lifecycle,
            PortLeaseLifecycle::Published
        );
        assert!(endpoint.generation > lease.generation);
        let published_generation = manager.generation();
        manager.publish(&id).unwrap();
        assert_eq!(manager.generation(), published_generation);
        manager.unpublish(&id).unwrap();
        let after_unpublish = manager.generation();
        assert!(after_unpublish > endpoint.generation);
        assert_eq!(
            manager.lease(&id, "web").unwrap().lifecycle,
            PortLeaseLifecycle::Leased
        );
        manager.release(&id).unwrap();
        assert!(manager.generation() > after_unpublish);
        manager.release(&id).unwrap();
        assert_eq!(manager.generation(), after_unpublish + 1);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn batch_allocation_is_atomic_when_any_port_fails() {
        let dir = test_dir("batch-atomic");
        let (manager, probe) = test_manager(dir.join("ports.json"), vec![]);
        let first = spec(30_141, false, "local-web");
        let mut second = spec(30_142, false, "local-web");
        second.name = "admin".to_string();
        second.env_var = "ADMIN_PORT".to_string();
        probe.set_unavailable(ServicePortProtocol::Tcp, second.preferred);

        manager
            .allocate(&ServiceId::new("svc-a"), &[first, second])
            .unwrap_err();
        assert!(manager.list_leases().is_empty());
        assert_eq!(manager.generation(), 0);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn allocation_reconciles_ports_removed_from_service_spec() {
        let dir = test_dir("reconcile");
        let (manager, _) = test_manager(dir.join("ports.json"), vec![]);
        let id = ServiceId::new("svc-a");
        manager
            .allocate(&id, &[spec(30_141, true, "local-web")])
            .unwrap();
        manager.publish(&id).unwrap();
        assert!(manager.has_leases(&id).unwrap());

        manager.allocate(&id, &[]).unwrap();
        assert!(!manager.has_leases(&id).unwrap());
        assert!(manager.endpoints(&id).unwrap().is_empty());
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn unpublished_lease_is_reused_only_when_port_is_available() {
        let dir = test_dir("reuse");
        let path = dir.join("ports.json");
        let preferred = 30_141;
        let fallback = 30_142;
        let (manager, probe) = test_manager(&path, vec![pool_range("test", preferred, fallback)]);
        let id = ServiceId::new("svc-a");
        let first = manager
            .allocate_port(&id, &spec(preferred, true, "test"))
            .unwrap();
        let reused = manager
            .allocate_port(&id, &spec(preferred, true, "test"))
            .unwrap();
        assert_eq!(first, reused);

        probe.set_unavailable(ServicePortProtocol::Tcp, preferred);
        let replaced = manager
            .allocate_port(&id, &spec(preferred, true, "test"))
            .unwrap();
        assert_eq!(replaced.allocated_port, fallback);
        assert!(replaced.generation > reused.generation);
        assert!(replaced.conflict.is_some());
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn published_lease_outside_current_pool_is_not_reused() {
        let dir = test_dir("pool-boundary");
        let path = dir.join("ports.json");
        let preferred = 30_141;
        let fallback = 30_142;
        let id = ServiceId::new("svc-a");
        {
            let (manager, _) = test_manager(&path, vec![pool_range("test", preferred, fallback)]);
            manager
                .allocate_port(&id, &spec(preferred, true, "test"))
                .unwrap();
            manager.publish(&id).unwrap();
        }

        let (manager, probe) = test_manager(&path, vec![pool("test", fallback)]);
        probe.set_unavailable(ServicePortProtocol::Tcp, preferred);
        let lease = manager
            .allocate_port(&id, &spec(preferred, true, "test"))
            .unwrap();
        assert_eq!(lease.allocated_port, fallback);
        assert_eq!(
            lease.conflict.as_ref().unwrap().reason,
            PortConflictReason::AddressInUse
        );
        assert_eq!(lease.lifecycle, PortLeaseLifecycle::Leased);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn orphan_reservation_blocks_unlistened_port_until_explicit_release() {
        let dir = test_dir("orphan");
        let path = dir.join("ports.json");
        let preferred = 30_141;
        let fallback = 30_142;
        let (manager, _) = test_manager(&path, vec![pool_range("test", preferred, fallback)]);
        let id = ServiceId::new("svc-a");
        manager
            .allocate_port(&id, &spec(preferred, true, "test"))
            .unwrap();
        manager.publish(&id).unwrap();
        let before = manager.generation();

        manager
            .mark_orphan(&id, "old process could not be stopped")
            .unwrap();
        assert!(manager.generation() > before);
        assert!(!manager.has_leases(&id).unwrap());
        assert!(manager.endpoints(&id).unwrap().is_empty());
        let orphans = manager.list_orphans();
        assert_eq!(orphans.len(), 1);
        assert_eq!(orphans[0].lifecycle, PortLeaseLifecycle::Orphaned);
        assert_eq!(
            orphans[0].orphan_reason.as_deref(),
            Some("old process could not be stopped")
        );
        assert_eq!(orphans[0].generation, manager.generation());
        let orphan_generation = orphans[0].generation;
        let generation = manager.generation();
        drop(manager);

        let (reopened, _) = test_manager(&path, vec![pool_range("test", preferred, fallback)]);
        assert_eq!(reopened.generation(), generation);
        assert_eq!(reopened.list_orphans(), orphans);

        // The controlled probe reports this port as available, so only the persisted orphan
        // reservation can force the allocator onto the fallback.
        let replacement = reopened
            .allocate_port(&ServiceId::new("svc-b"), &spec(preferred, true, "test"))
            .unwrap();
        assert_eq!(replacement.allocated_port, fallback);
        assert_eq!(
            replacement.conflict.as_ref().unwrap().reason,
            PortConflictReason::OrphanedLease
        );
        reopened.release(&ServiceId::new("svc-b")).unwrap();
        assert!(
            reopened
                .release_orphan(&id, "web", orphan_generation)
                .unwrap()
        );
        let reclaimed = reopened
            .allocate_port(&ServiceId::new("svc-c"), &spec(preferred, false, "test"))
            .unwrap();
        assert_eq!(reclaimed.allocated_port, preferred);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn old_fixed_reservation_fields_are_rejected() {
        for old_field in ["primary", "count"] {
            let mut value = serde_json::json!({
                "name": "web",
                "host": "127.0.0.1",
                "preferred": 30141,
                "dynamic": true,
                "pool": "local-web",
                "protocol": "tcp",
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            });
            value
                .as_object_mut()
                .unwrap()
                .insert(old_field.to_string(), serde_json::json!(1));
            let error = serde_json::from_value::<ServicePortSpec>(value).unwrap_err();
            assert!(error.to_string().contains("unknown field"));
            assert!(error.to_string().contains(old_field));
        }
    }

    #[test]
    fn udp_conflict_uses_dynamic_fallback() {
        let dir = test_dir("udp-fallback");
        let preferred = 30_141;
        let fallback = 30_142;
        let (manager, probe) = test_manager(dir.join("ports.json"), vec![pool("udp", fallback)]);
        probe.set_unavailable(ServicePortProtocol::Udp, preferred);
        let mut udp_spec = spec(preferred, true, "udp");
        udp_spec.protocol = ServicePortProtocol::Udp;
        let lease = manager
            .allocate_port(&ServiceId::new("svc-udp"), &udp_spec)
            .unwrap();
        assert_eq!(lease.allocated_port, fallback);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn concurrent_allocations_are_serialized_and_unique() {
        let dir = test_dir("concurrent");
        let (manager, _) = test_manager(dir.join("ports.json"), vec![]);
        let manager = Arc::new(manager);
        let preferred = 30_141;
        let mut threads = Vec::new();
        for index in 0..8 {
            let manager = Arc::clone(&manager);
            threads.push(std::thread::spawn(move || {
                manager
                    .allocate_port(
                        &ServiceId::new(format!("svc-{index}")),
                        &spec(preferred, true, "local-web"),
                    )
                    .unwrap()
                    .allocated_port
            }));
        }
        let mut ports: Vec<u16> = threads
            .into_iter()
            .map(|thread| thread.join().unwrap())
            .collect();
        ports.sort_unstable();
        ports.dedup();
        assert_eq!(ports.len(), 8);
        assert_eq!(manager.list_leases().len(), 8);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn system_probe_detects_held_tcp_and_udp_sockets() {
        let probe = SystemPortProbe;
        let tcp = TcpListener::bind(("127.0.0.1", 0)).unwrap();
        let tcp_port = tcp.local_addr().unwrap().port();
        assert!(
            !probe
                .available("127.0.0.1", tcp_port, ServicePortProtocol::Tcp)
                .unwrap()
        );

        let udp = UdpSocket::bind(("127.0.0.1", 0)).unwrap();
        let udp_port = udp.local_addr().unwrap().port();
        assert!(
            !probe
                .available("127.0.0.1", udp_port, ServicePortProtocol::Udp)
                .unwrap()
        );
    }
}
