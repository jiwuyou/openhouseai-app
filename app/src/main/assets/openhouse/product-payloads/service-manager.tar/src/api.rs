use axum::{
    Json, Router,
    body::Bytes,
    extract::{DefaultBodyLimit, Path, Query, State},
    http::{HeaderMap, HeaderValue, StatusCode, header},
    middleware,
    response::{IntoResponse, Redirect, Response},
    routing::{get, post},
};
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::{
    assets, auth,
    error::{AppError, Result},
    model::{Action, LogsOptions, Service, ServiceId, ServiceSpec, ServiceStatus},
    openhouse_registry,
    server::{AppState, health_payload},
};

pub fn router(state: AppState) -> Router {
    let protected: Router<AppState> = Router::new()
        .route("/providers", get(providers_list))
        .route("/groups", get(groups_list))
        .route("/groups/:name/status", get(group_status))
        .route("/groups/:name/start", post(group_start))
        .route("/groups/:name/stop", post(group_stop))
        .route("/groups/:name/restart", post(group_restart))
        .route("/services", get(services_list).post(services_create))
        .route("/services/statuses", get(services_statuses))
        .route("/residency", get(residency_list))
        .route("/residency/:id", axum::routing::delete(residency_delete))
        .route(
            "/services/:id",
            get(services_get)
                .put(services_update)
                .delete(services_delete),
        )
        .route("/services/:id/start", post(service_start))
        .route("/services/:id/stop", post(service_stop))
        .route("/services/:id/restart", post(service_restart))
        .route(
            "/services/:id/residency",
            get(service_residency_get).put(service_residency_put),
        )
        .route("/services/:id/repair", post(service_repair))
        .route("/services/:id/register", post(service_register))
        .route("/services/:id/unregister", post(service_unregister))
        .route("/services/:id/status", get(service_status))
        .route("/services/:id/endpoints", get(service_endpoints))
        .route("/services/:id/endpoints/:name", get(service_endpoint))
        .route("/services/:id/logs", get(service_logs))
        .route("/ports", get(ports_list))
        .route("/audit", get(audit_list))
        .route("/export", get(export_store))
        .route("/import", post(import_store))
        .route("/registry/state", get(registry_state))
        .route("/registry/components", get(registry_components))
        .route(
            "/registry/components/:id",
            get(registry_component_get)
                .put(registry_component_put)
                .delete(registry_component_delete),
        )
        .route("/registry/sync", post(registry_sync))
        .route("/registry/apply", post(registry_apply))
        .route("/web-session-tickets", post(web_session_ticket))
        .route("/web-session", get(web_session_info))
        .layer(middleware::from_fn_with_state(
            state.clone(),
            auth::require_bearer_token,
        ));

    Router::<AppState>::new()
        .route("/", get(root))
        .route("/index.html", get(root))
        .route("/app.js", get(asset_app_js))
        .route("/styles.css", get(asset_styles_css))
        .route("/web-session", get(web_session_exchange))
        .route("/api/v1/health", get(health))
        .nest("/api/v1", protected)
        .layer(DefaultBodyLimit::max(20 * 1024 * 1024))
        .with_state(state)
}

async fn root() -> Response {
    assets::response("/").expect("index asset is embedded")
}

async fn asset_app_js() -> Response {
    assets::response("/app.js").expect("app.js asset is embedded")
}

async fn asset_styles_css() -> Response {
    assets::response("/styles.css").expect("styles.css asset is embedded")
}

async fn health() -> impl IntoResponse {
    Json(health_payload())
}

async fn web_session_ticket() -> Result<Json<serde_json::Value>> {
    let ticket = auth::issue_web_ticket()?;
    Ok(Json(serde_json::json!({
        "path": format!("/web-session?ticket={ticket}"),
        "expiresIn": 60
    })))
}

#[derive(Deserialize)]
struct WebSessionQuery {
    ticket: String,
}

async fn web_session_exchange(Query(query): Query<WebSessionQuery>) -> Result<Response> {
    let (session, _csrf_token) = auth::consume_web_ticket(query.ticket.trim())?;
    let mut response = Redirect::to("/").into_response();
    response.headers_mut().insert(
        header::SET_COOKIE,
        HeaderValue::from_str(&auth::session_set_cookie(&session))
            .map_err(|_| AppError::Internal)?,
    );
    response.headers_mut().insert(
        header::REFERRER_POLICY,
        HeaderValue::from_static("no-referrer"),
    );
    Ok(response)
}

async fn web_session_info(headers: HeaderMap) -> Result<Json<serde_json::Value>> {
    let csrf_token = auth::csrf_for_cookie(&headers)?;
    Ok(Json(serde_json::json!({ "csrfToken": csrf_token })))
}

async fn providers_list(State(state): State<AppState>) -> Result<Json<serde_json::Value>> {
    let out = state.engine.list_providers().await?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn services_list(
    State(state): State<AppState>,
    Query(q): Query<ServicesQuery>,
) -> Result<Json<serde_json::Value>> {
    let filters = ServiceFilters::from_query(&q);
    let svcs = filter_services(state.engine.list_services()?, &filters);
    Ok(Json(serde_json::to_value(svcs)?))
}

async fn groups_list(State(state): State<AppState>) -> Result<Json<serde_json::Value>> {
    let groups = state.engine.list_groups()?;
    Ok(Json(serde_json::to_value(groups)?))
}

async fn group_status(
    State(state): State<AppState>,
    Path(name): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let group = name.trim();
    if group.is_empty() {
        return Err(AppError::BadRequest("group name is required".to_string()));
    }

    let Some(svc_group) = state
        .engine
        .list_groups()?
        .into_iter()
        .find(|g| g.name == group)
    else {
        return Err(AppError::NotFound);
    };
    let out = collect_service_statuses(&state, svc_group.services).await;
    Ok(Json(serde_json::to_value(out)?))
}

async fn group_start(
    State(state): State<AppState>,
    Path(name): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let out = state.engine.group_action(&name, Action::Start).await?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn group_stop(
    State(state): State<AppState>,
    Path(name): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let out = state.engine.group_action(&name, Action::Stop).await?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn group_restart(
    State(state): State<AppState>,
    Path(name): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let out = state.engine.group_action(&name, Action::Restart).await?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn services_create(State(state): State<AppState>, body: Bytes) -> Result<impl IntoResponse> {
    let spec: ServiceSpec = parse_json_body(&body)?;
    let svc = state.engine.create_service(spec).await?;
    Ok((StatusCode::CREATED, Json(serde_json::to_value(svc)?)))
}

async fn services_statuses(
    State(state): State<AppState>,
    Query(q): Query<ServicesQuery>,
) -> Result<Json<serde_json::Value>> {
    let filters = ServiceFilters::from_query(&q);
    let svcs = filter_services(state.engine.list_services()?, &filters);
    let out = collect_service_statuses(&state, svcs).await;
    Ok(Json(serde_json::to_value(out)?))
}

async fn services_get(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let service_id = resolve_service_id(&state, &id)?;
    let svc = state.engine.get_service(&service_id)?;
    Ok(Json(serde_json::to_value(svc)?))
}

async fn services_update(
    State(state): State<AppState>,
    Path(id): Path<String>,
    body: Bytes,
) -> Result<Json<serde_json::Value>> {
    let spec: ServiceSpec = parse_json_body(&body)?;
    let service_id = resolve_service_id(&state, &id)?;
    let svc = state.engine.update_service(&service_id, spec).await?;
    Ok(Json(serde_json::to_value(svc)?))
}

async fn services_delete(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<StatusCode> {
    let service_id = resolve_service_id(&state, &id)?;
    state.engine.delete_service(&service_id).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn service_start(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<StatusCode> {
    let service_id = resolve_service_id(&state, &id)?;
    state.engine.start(&service_id).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn service_stop(State(state): State<AppState>, Path(id): Path<String>) -> Result<StatusCode> {
    let service_id = resolve_service_id(&state, &id)?;
    state.engine.stop(&service_id).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn service_restart(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<StatusCode> {
    let service_id = resolve_service_id(&state, &id)?;
    state.engine.restart(&service_id).await?;
    Ok(StatusCode::NO_CONTENT)
}

#[derive(Debug, Deserialize)]
struct ResidencyUpdate {
    resident: bool,
}

async fn residency_list(State(state): State<AppState>) -> Result<Json<serde_json::Value>> {
    let policies = state
        .engine
        .list_residency()
        .into_iter()
        .map(|policy| {
            let registered = state
                .engine
                .get_service(&ServiceId::new(policy.service_id.clone()))
                .is_ok();
            residency_json(policy, registered)
        })
        .collect::<Vec<_>>();
    Ok(Json(serde_json::json!(policies)))
}

async fn service_residency_get(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let service_id = resolve_service_id(&state, &id)?;
    let policy = state.engine.get_residency(&service_id)?;
    Ok(Json(residency_json(policy, true)))
}

async fn service_residency_put(
    State(state): State<AppState>,
    Path(id): Path<String>,
    body: Bytes,
) -> Result<Json<serde_json::Value>> {
    let service_id = resolve_service_id(&state, &id)?;
    let update: ResidencyUpdate = parse_json_body(&body)?;
    let policy = state
        .engine
        .set_residency(&service_id, update.resident)
        .await?;
    Ok(Json(residency_json(policy, true)))
}

fn residency_json(
    policy: crate::residency::ResidencyPolicy,
    registered: bool,
) -> serde_json::Value {
    serde_json::json!({
        "serviceId": policy.service_id,
        "resident": policy.resident,
        "suspendedByUser": policy.suspended,
        "lastError": policy.last_error,
        "updatedAt": policy.updated_at,
        "registered": registered,
    })
}

async fn residency_delete(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<StatusCode> {
    state
        .engine
        .delete_orphan_residency(&ServiceId::new(id.trim().to_string()))?;
    Ok(StatusCode::NO_CONTENT)
}

async fn service_repair(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<StatusCode> {
    let service_id = resolve_service_id(&state, &id)?;
    state.engine.repair(&service_id).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn service_register(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<StatusCode> {
    let service_id = resolve_service_id(&state, &id)?;
    state.engine.register(&service_id).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn service_unregister(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<StatusCode> {
    let service_id = resolve_service_id(&state, &id)?;
    state.engine.unregister(&service_id).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn service_status(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let service_id = resolve_service_id(&state, &id)?;
    let st = state.engine.status(&service_id).await?;
    Ok(Json(serde_json::to_value(st)?))
}

async fn service_endpoints(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let service_id = resolve_service_id(&state, &id)?;
    let resolution = state.engine.endpoints(&service_id).await?;
    Ok(Json(endpoint_resolution_json(resolution)))
}

async fn service_endpoint(
    State(state): State<AppState>,
    Path((id, name)): Path<(String, String)>,
) -> Result<Response> {
    let service_id = resolve_service_id(&state, &id)?;
    let resolution = state.engine.endpoints(&service_id).await?;
    if let Some(endpoint) = resolution
        .endpoints
        .iter()
        .find(|endpoint| endpoint.name == name.trim())
    {
        return Ok(Json(endpoint_json(endpoint, resolution.generation)).into_response());
    }

    let status = match resolution.status {
        crate::server::EndpointAvailability::Starting
        | crate::server::EndpointAvailability::Unhealthy => StatusCode::SERVICE_UNAVAILABLE,
        crate::server::EndpointAvailability::Healthy
        | crate::server::EndpointAvailability::Stopped => StatusCode::NOT_FOUND,
    };
    Ok((
        status,
        Json(serde_json::json!({
            "serviceId": service_id,
            "name": name.trim(),
            "status": resolution.status,
            "generation": resolution.generation,
            "error": "endpoint is not available"
        })),
    )
        .into_response())
}

async fn ports_list(State(state): State<AppState>) -> Result<Json<serde_json::Value>> {
    Ok(Json(state.engine.port_state().await?))
}

fn endpoint_resolution_json(resolution: crate::server::EndpointResolution) -> serde_json::Value {
    serde_json::json!({
        "serviceId": resolution.service_id,
        "status": resolution.status,
        "generation": resolution.generation,
        "endpoints": resolution.endpoints.iter().map(|endpoint| endpoint_json(endpoint, resolution.generation)).collect::<Vec<_>>()
    })
}

fn endpoint_json(
    endpoint: &crate::model::ServiceEndpoint,
    global_generation: u64,
) -> serde_json::Value {
    serde_json::json!({
        "serviceId": endpoint.service_id,
        "name": endpoint.name,
        "url": endpoint.url,
        "host": endpoint.host,
        "port": endpoint.port,
        "protocol": endpoint.protocol,
        "generation": global_generation,
        "publishedGeneration": endpoint.generation,
        "status": "healthy"
    })
}

#[derive(Debug, Deserialize)]
struct LogsQuery {
    since: Option<String>,
    until: Option<String>,
    limit: Option<String>,
}

async fn service_logs(
    State(state): State<AppState>,
    Path(id): Path<String>,
    Query(q): Query<LogsQuery>,
) -> Result<Json<serde_json::Value>> {
    let service_id = resolve_service_id(&state, &id)?;
    let opts = LogsOptions {
        since: parse_rfc3339_opt(q.since.as_deref())?,
        until: parse_rfc3339_opt(q.until.as_deref())?,
        limit: parse_usize_opt(q.limit.as_deref())?,
    };
    let logs = state.engine.logs(&service_id, opts).await?;
    Ok(Json(serde_json::to_value(logs)?))
}

fn resolve_service_id(state: &AppState, raw: &str) -> Result<ServiceId> {
    let token = raw.trim();
    if token.is_empty() {
        return Err(AppError::BadRequest("service id is required".to_string()));
    }

    let direct = ServiceId(token.to_string());
    match state.engine.get_service(&direct) {
        Ok(_) => return Ok(direct),
        Err(AppError::NotFound) => {}
        Err(err) => return Err(err),
    }

    let matches: Vec<Service> = state
        .engine
        .list_services()?
        .into_iter()
        .filter(|svc| svc.spec.name == token)
        .collect();

    match matches.as_slice() {
        [svc] => Ok(svc.id.clone()),
        [] => Err(AppError::NotFound),
        many => Err(AppError::BadRequest(format!(
            "service name {:?} is ambiguous; matching ids: {}",
            token,
            many.iter()
                .map(|svc| svc.id.0.as_str())
                .collect::<Vec<_>>()
                .join(", ")
        ))),
    }
}

#[derive(Debug, Deserialize)]
struct AuditQuery {
    limit: Option<String>,
}

async fn audit_list(
    State(state): State<AppState>,
    Query(q): Query<AuditQuery>,
) -> Result<Json<serde_json::Value>> {
    let limit = parse_usize_opt(q.limit.as_deref())?;
    let evts = state.engine.list_audit_events(limit)?;
    Ok(Json(serde_json::to_value(evts)?))
}

async fn export_store(State(state): State<AppState>) -> Result<Response> {
    let b = state.engine.export()?;
    Ok((
        StatusCode::OK,
        [(header::CONTENT_TYPE, "application/json")],
        b,
    )
        .into_response())
}

async fn import_store(State(state): State<AppState>, body: Bytes) -> Result<StatusCode> {
    state.engine.import(&body)?;
    Ok(StatusCode::NO_CONTENT)
}

async fn registry_state(State(state): State<AppState>) -> Result<Json<serde_json::Value>> {
    let cfg = registry_config(&state);
    let out = openhouse_registry::read_state(&cfg)?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn registry_components(State(state): State<AppState>) -> Result<Json<serde_json::Value>> {
    let cfg = registry_config(&state);
    let out = openhouse_registry::list_components(&cfg)?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn registry_component_get(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let cfg = registry_config(&state);
    let out = openhouse_registry::get_component(&cfg, &id)?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn registry_component_put(
    State(state): State<AppState>,
    Path(id): Path<String>,
    body: Bytes,
) -> Result<Json<serde_json::Value>> {
    let manifest: serde_json::Value = parse_json_body(&body)?;
    let cfg = registry_config(&state);
    let component = openhouse_registry::put_component(&cfg, &id, manifest)?;
    let state = openhouse_registry::sync_registry(&cfg)?;
    let out = openhouse_registry::RegistryMutationResult {
        component: Some(component),
        state,
    };
    Ok(Json(serde_json::to_value(out)?))
}

async fn registry_component_delete(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Json<serde_json::Value>> {
    let cfg = registry_config(&state);
    openhouse_registry::delete_component(&cfg, &id)?;
    let out = openhouse_registry::sync_registry(&cfg)?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn registry_sync(State(state): State<AppState>) -> Result<Json<serde_json::Value>> {
    let cfg = registry_config(&state);
    let out = openhouse_registry::sync_registry(&cfg)?;
    Ok(Json(serde_json::to_value(out)?))
}

async fn registry_apply(
    State(state): State<AppState>,
    body: Bytes,
) -> Result<Json<serde_json::Value>> {
    let request: openhouse_registry::RegistryApplyRequest = parse_json_body(&body)?;
    let prepared = openhouse_registry::prepare_apply_request(request)?;
    for (_, spec) in &prepared.services {
        if state.engine.registry().get(&spec.provider).is_none() {
            return Err(AppError::ProviderNotFound(spec.provider.0.clone()));
        }
    }

    let store_snapshot = if prepared.services.is_empty() {
        None
    } else {
        Some(state.engine.export_store_snapshot()?)
    };
    for (id, spec) in &prepared.services {
        if let Err(err) = state
            .engine
            .upsert_registered_service(ServiceId(id.clone()), spec.clone())
        {
            if let Some(snapshot) = store_snapshot.as_deref() {
                let _ = state.engine.restore_store_snapshot(snapshot);
            }
            return Err(err);
        }
    }

    let cfg = registry_config(&state);
    let out = match openhouse_registry::apply_prepared_registry(&cfg, &prepared) {
        Ok(out) => out,
        Err(err) => {
            if let Some(snapshot) = store_snapshot.as_deref() {
                let _ = state.engine.restore_store_snapshot(snapshot);
            }
            return Err(err);
        }
    };
    Ok(Json(serde_json::to_value(out)?))
}

fn registry_config(state: &AppState) -> openhouse_registry::RegistryConfig {
    openhouse_registry::RegistryConfig::new(
        state.config.openhouse_registry_source_dir.clone(),
        state.config.openhouse_registry_target_dir.clone(),
    )
}

fn parse_json_body<T: serde::de::DeserializeOwned>(b: &[u8]) -> Result<T> {
    if b.is_empty() {
        return Err(AppError::BadRequest("empty JSON body".to_string()));
    }
    serde_json::from_slice::<T>(b).map_err(|e| AppError::BadRequest(e.to_string()))
}

fn parse_rfc3339_opt(s: Option<&str>) -> Result<Option<DateTime<Utc>>> {
    let Some(s) = s else { return Ok(None) };
    let s = s.trim();
    if s.is_empty() {
        return Ok(None);
    }
    let dt = DateTime::parse_from_rfc3339(s)
        .map_err(|_| AppError::BadRequest("invalid timestamp; must be RFC3339".to_string()))?;
    Ok(Some(dt.with_timezone(&Utc)))
}

fn parse_usize_opt(s: Option<&str>) -> Result<Option<usize>> {
    let Some(s) = s else { return Ok(None) };
    let s = s.trim();
    if s.is_empty() {
        return Ok(None);
    }
    let n: usize = s
        .parse()
        .map_err(|_| AppError::BadRequest("invalid limit".to_string()))?;
    Ok(Some(n))
}

#[derive(Debug, Deserialize, Default)]
struct ServicesQuery {
    tag: Option<String>,
    tags: Option<String>,
    group: Option<String>,
    groups: Option<String>,
}

#[derive(Debug, Default)]
struct ServiceFilters {
    tags: Vec<String>,
    groups: Vec<String>,
}

impl ServiceFilters {
    fn from_query(q: &ServicesQuery) -> Self {
        let mut filters = Self::default();
        collect_selector_values(q.tag.as_deref(), &mut filters.tags);
        collect_selector_values(q.tags.as_deref(), &mut filters.tags);
        collect_selector_values(q.group.as_deref(), &mut filters.groups);
        collect_selector_values(q.groups.as_deref(), &mut filters.groups);
        filters
    }

    fn matches(&self, svc: &Service) -> bool {
        self.tags
            .iter()
            .all(|want| svc.spec.tags.iter().any(|tag| tag.trim() == want))
            && self.groups.iter().all(|want| {
                svc.spec.tags.iter().any(|tag| {
                    tag.trim()
                        .strip_prefix("group:")
                        .map(|name| name.trim() == want)
                        .unwrap_or(false)
                })
            })
    }
}

#[derive(Debug, Serialize)]
struct ServiceStatusItem {
    service: Service,
    #[serde(default)]
    status: Option<ServiceStatus>,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    error: String,
}

fn collect_selector_values(raw: Option<&str>, out: &mut Vec<String>) {
    let Some(raw) = raw else {
        return;
    };
    for part in raw.split(',') {
        let value = part.trim();
        if value.is_empty() {
            continue;
        }
        if !out.iter().any(|existing| existing == value) {
            out.push(value.to_string());
        }
    }
}

fn filter_services(services: Vec<Service>, filters: &ServiceFilters) -> Vec<Service> {
    if filters.tags.is_empty() && filters.groups.is_empty() {
        return services;
    }
    services
        .into_iter()
        .filter(|svc| filters.matches(svc))
        .collect()
}

async fn collect_service_statuses(
    state: &AppState,
    services: Vec<Service>,
) -> Vec<ServiceStatusItem> {
    let mut out = Vec::with_capacity(services.len());
    for svc in services {
        match state.engine.status(&svc.id).await {
            Ok(status) => out.push(ServiceStatusItem {
                service: svc,
                status: Some(status),
                error: String::new(),
            }),
            Err(e) => out.push(ServiceStatusItem {
                service: svc,
                status: None,
                error: e.to_string(),
            }),
        }
    }
    out
}

// Silence unused imports if we later want to add headers for web assets.
#[allow(dead_code)]
fn _set_json_headers(_h: &mut HeaderMap) {}

#[cfg(test)]
mod tests {
    use std::{
        collections::{BTreeMap, BTreeSet},
        fs,
        net::TcpListener,
        os::fd::AsRawFd,
        path::PathBuf,
        sync::Mutex,
        time::{SystemTime, UNIX_EPOCH},
    };

    use axum::{
        body::Body,
        http::{
            Request, StatusCode,
            header::{AUTHORIZATION, CONTENT_TYPE, COOKIE, SET_COOKIE},
        },
    };
    use http_body_util::BodyExt;
    use tower::ServiceExt;

    use crate::{
        model::{
            Capability, DetectResult, LogEntry, LogsOptions, Provider, ProviderId, Service,
            ServiceId, ServiceSpec, ServiceState, ServiceStatus,
        },
        ports::PortManager,
        server::{AppState, Config, Engine, ProviderRegistry, StoreConfig},
        store::JsonStore,
    };

    struct FakeProvider {
        id: ProviderId,
        state: Mutex<BTreeMap<String, ServiceState>>,
        child_pids: Mutex<BTreeMap<String, libc::pid_t>>,
        external_pids: Mutex<Vec<libc::pid_t>>,
        occupied_once: Mutex<BTreeSet<String>>,
    }

    impl FakeProvider {
        fn new(id: &str) -> Self {
            Self {
                id: ProviderId(id.to_string()),
                state: Mutex::new(BTreeMap::new()),
                child_pids: Mutex::new(BTreeMap::new()),
                external_pids: Mutex::new(Vec::new()),
                occupied_once: Mutex::new(BTreeSet::new()),
            }
        }

        fn spawn_child(listener: Option<TcpListener>) -> crate::error::Result<libc::pid_t> {
            let keep_fd = listener.as_ref().map(AsRawFd::as_raw_fd);
            let pid = unsafe { libc::fork() };
            if pid < 0 {
                return Err(crate::error::AppError::Io(std::io::Error::last_os_error()));
            }
            if pid == 0 {
                unsafe {
                    libc::setpgid(0, 0);
                    for fd in 3..1024 {
                        if Some(fd) != keep_fd {
                            libc::close(fd);
                        }
                    }
                    loop {
                        libc::pause();
                    }
                }
            }
            unsafe {
                libc::setpgid(pid, pid);
            }
            drop(listener);
            Ok(pid)
        }

        fn stop_child(&self, service_id: &str) {
            if let Some(pid) = self.child_pids.lock().unwrap().remove(service_id) {
                unsafe {
                    libc::kill(-pid, libc::SIGTERM);
                    libc::waitpid(pid, std::ptr::null_mut(), 0);
                }
            }
        }
    }

    impl Drop for FakeProvider {
        fn drop(&mut self) {
            let pids: Vec<libc::pid_t> = self
                .child_pids
                .get_mut()
                .unwrap()
                .values()
                .copied()
                .collect();
            for pid in pids {
                unsafe {
                    libc::kill(-pid, libc::SIGKILL);
                    libc::waitpid(pid, std::ptr::null_mut(), 0);
                }
            }
            for pid in self.external_pids.get_mut().unwrap().drain(..) {
                unsafe {
                    libc::kill(-pid, libc::SIGKILL);
                    libc::waitpid(pid, std::ptr::null_mut(), 0);
                }
            }
        }
    }

    #[async_trait::async_trait]
    impl Provider for FakeProvider {
        fn id(&self) -> ProviderId {
            self.id.clone()
        }

        fn display_name(&self) -> String {
            "Fake Provider".to_string()
        }

        fn description(&self) -> String {
            "Test-only provider".to_string()
        }

        fn capabilities(&self) -> Vec<Capability> {
            vec![
                Capability::Register,
                Capability::Unregister,
                Capability::Start,
                Capability::Stop,
                Capability::Restart,
                Capability::Status,
                Capability::Logs,
            ]
        }

        async fn detect(&self) -> crate::error::Result<DetectResult> {
            Ok(DetectResult {
                detected: true,
                details: String::new(),
            })
        }

        async fn register(&self, _svc: &Service) -> crate::error::Result<()> {
            Ok(())
        }

        async fn unregister(&self, _svc: &Service) -> crate::error::Result<()> {
            Ok(())
        }

        async fn start(&self, svc: &Service) -> crate::error::Result<()> {
            if svc.spec.env.get("FAKE_START_FAIL").map(String::as_str) == Some("1") {
                return Err(crate::error::AppError::BadRequest(
                    "fake start failure".to_string(),
                ));
            }
            let declared_port = svc
                .spec
                .env
                .get("PORT")
                .map(|port| {
                    port.parse::<u16>().map_err(|_| {
                        crate::error::AppError::BadRequest("invalid fake PORT".to_string())
                    })
                })
                .transpose()?;
            if svc
                .spec
                .env
                .get("FAKE_OCCUPY_FIRST_PORT")
                .map(String::as_str)
                == Some("1")
                && let Some(port) = declared_port
                && self.occupied_once.lock().unwrap().insert(svc.id.0.clone())
            {
                let listener = TcpListener::bind(("127.0.0.1", port))?;
                let pid = Self::spawn_child(Some(listener))?;
                self.external_pids.lock().unwrap().push(pid);
            }
            let listener = if svc.spec.env.get("FAKE_SKIP_BIND").map(String::as_str) != Some("1")
                && let Some(port) = declared_port
            {
                let bind_port = svc
                    .spec
                    .env
                    .get("FAKE_BIND_PORT")
                    .map(|value| value.parse::<u16>())
                    .transpose()
                    .map_err(|_| {
                        crate::error::AppError::BadRequest("invalid fake PORT".to_string())
                    })?
                    .unwrap_or(port);
                let bind_host = svc
                    .spec
                    .env
                    .get("FAKE_BIND_HOST")
                    .map(String::as_str)
                    .unwrap_or("127.0.0.1");
                Some(TcpListener::bind((bind_host, bind_port))?)
            } else {
                None
            };
            let pid = Self::spawn_child(listener)?;
            self.child_pids
                .lock()
                .unwrap()
                .insert(svc.id.0.clone(), pid);
            let mut m = self.state.lock().unwrap();
            m.insert(svc.id.0.clone(), ServiceState::Running);
            Ok(())
        }

        async fn stop(&self, svc: &Service) -> crate::error::Result<()> {
            if svc.spec.env.get("FAKE_STOP_FAIL").map(String::as_str) == Some("1") {
                return Err(crate::error::AppError::BadRequest(
                    "fake stop failure".to_string(),
                ));
            }
            self.stop_child(&svc.id.0);
            let mut m = self.state.lock().unwrap();
            m.insert(svc.id.0.clone(), ServiceState::Stopped);
            Ok(())
        }

        async fn restart(&self, svc: &Service) -> crate::error::Result<()> {
            self.stop(svc).await?;
            self.start(svc).await
        }

        async fn status(&self, svc: &Service) -> crate::error::Result<ServiceStatus> {
            let m = self.state.lock().unwrap();
            let st = m.get(&svc.id.0).copied().unwrap_or(ServiceState::Stopped);
            Ok(ServiceStatus {
                service_id: svc.id.clone(),
                state: st,
                message: String::new(),
                provider: svc.spec.provider.clone(),
                observed_at: chrono::Utc::now(),
                started_at: None,
                pid: (st == ServiceState::Running)
                    .then(|| self.child_pids.lock().unwrap().get(&svc.id.0).copied())
                    .flatten()
                    .map(|pid| pid as u32),
                exit_code: None,
            })
        }

        async fn logs(
            &self,
            _svc: &Service,
            _opts: LogsOptions,
        ) -> crate::error::Result<Vec<LogEntry>> {
            Ok(vec![LogEntry {
                time: chrono::Utc::now(),
                stream: "system".to_string(),
                message: "hello".to_string(),
            }])
        }
    }

    fn test_state() -> (AppState, String) {
        test_state_with_procfs_root(None)
    }

    fn test_state_with_procfs_root(procfs_root: Option<PathBuf>) -> (AppState, String) {
        let token = "test-token-123".to_string();

        let uniq = format!(
            "service-manager-test-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        );
        let base = std::env::temp_dir().join(uniq);
        let _ = fs::create_dir_all(&base);
        let store_path: PathBuf = base.join("store.json");

        let cfg = Config {
            listen_addr: "127.0.0.1:0".to_string(),
            data_dir: base.to_string_lossy().to_string(),
            service_registry_dir: base.join("services.d").to_string_lossy().to_string(),
            openhouse_registry_source_dir: base.join("openhouseai").to_string_lossy().to_string(),
            openhouse_registry_target_dir: base
                .join("termux-openhouseai")
                .to_string_lossy()
                .to_string(),
            auth_token: token.clone(),
            log_level: "info".to_string(),
            store: StoreConfig {
                ty: "json".to_string(),
                path: store_path.to_string_lossy().to_string(),
            },
            port_pools: vec![],
            port_state_path: base.join("ports.json").to_string_lossy().to_string(),
        };

        let store = std::sync::Arc::new(JsonStore::open(store_path).unwrap());
        let registry = ProviderRegistry::new();
        registry
            .add(std::sync::Arc::new(FakeProvider::new("fake")))
            .unwrap();
        let ports =
            std::sync::Arc::new(PortManager::open(base.join("ports.json"), vec![]).unwrap());
        let engine = std::sync::Arc::new(match procfs_root {
            Some(procfs_root) => Engine::new_with_procfs_root(store, registry, ports, procfs_root),
            None => Engine::new(store, registry, ports),
        });
        (
            AppState {
                config: cfg,
                engine,
            },
            token,
        )
    }

    fn free_tcp_port() -> u16 {
        TcpListener::bind(("127.0.0.1", 0))
            .unwrap()
            .local_addr()
            .unwrap()
            .port()
    }

    async fn create_service_with_port(
        app: &axum::Router,
        token: &str,
        name: &str,
        preferred: u16,
        mut health: serde_json::Value,
    ) -> String {
        if health.as_array().is_some_and(Vec::is_empty) {
            health = serde_json::json!([{
                "type": "tcp",
                "address": "127.0.0.1:{{port:web}}",
                "interval": "10ms",
                "timeout": "100ms"
            }]);
        }
        let spec = serde_json::json!({
            "name": name,
            "provider": "fake",
            "command": ["demo", "--port", "{{port:web}}"],
            "env": {"DEMO_URL": "http://127.0.0.1:{{port:web}}"},
            "health": health,
            "ports": [{
                "name": "web",
                "host": "127.0.0.1",
                "preferred": preferred,
                "dynamic": true,
                "pool": "local-web",
                "protocol": "tcp",
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }]
        });
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::CREATED);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        serde_json::from_slice::<serde_json::Value>(&body).unwrap()["id"]
            .as_str()
            .unwrap()
            .to_string()
    }

    #[tokio::test]
    async fn health_is_unprotected() {
        let (state, _tok) = test_state();
        let app = super::router(state);
        let res = app
            .oneshot(
                Request::builder()
                    .uri("/api/v1/health")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let v: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(v["ok"], true);
    }

    #[tokio::test]
    async fn residency_api_persists_choice_and_stop_suspends_it() {
        let (state, token) = test_state();
        let engine = state.engine.clone();
        let app = super::router(state);
        let spec = serde_json::json!({
            "name": "resident-demo",
            "provider": "fake",
            "command": ["demo"],
            "residentByDefault": false
        });
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::CREATED);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let id = serde_json::from_slice::<serde_json::Value>(&body).unwrap()["id"]
            .as_str()
            .unwrap()
            .to_string();

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("PUT")
                    .uri(format!("/api/v1/services/{id}/residency"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(r#"{"resident":true}"#))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let put_policy: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_residency_shape(&put_policy);

        engine.reconcile_residency_once().await.unwrap();
        assert_eq!(
            engine
                .status(&ServiceId::new(id.clone()))
                .await
                .unwrap()
                .state,
            ServiceState::Running
        );

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/stop"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/residency"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let policy: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(policy["resident"], true);
        assert_eq!(policy["suspendedByUser"], true);
        assert!(policy.get("lastError").is_some());
        assert!(policy.get("registered").is_some());
        assert_residency_shape(&policy);

        let response = app
            .oneshot(
                Request::builder()
                    .uri("/api/v1/residency")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let policies: serde_json::Value = serde_json::from_slice(&body).unwrap();
        let listed = policies
            .as_array()
            .unwrap()
            .iter()
            .find(|value| value["serviceId"] == id)
            .unwrap();
        assert_residency_shape(listed);
    }

    fn plain_fake_spec(name: &str, fail_start: bool) -> ServiceSpec {
        serde_json::from_value(serde_json::json!({
            "name": name,
            "provider": "fake",
            "command": ["demo"],
            "env": if fail_start { serde_json::json!({"FAKE_START_FAIL": "1"}) } else { serde_json::json!({}) }
        }))
        .unwrap()
    }

    fn assert_residency_shape(value: &serde_json::Value) {
        let object = value.as_object().unwrap();
        for key in [
            "serviceId",
            "resident",
            "suspendedByUser",
            "lastError",
            "updatedAt",
            "registered",
        ] {
            assert!(object.contains_key(key), "missing residency field {key}");
        }
        assert!(!object.contains_key("suspended"));
    }

    #[tokio::test]
    async fn queued_disable_wins_over_reconcile_start() {
        let (state, _) = test_state();
        let engine = state.engine;
        let service = engine
            .create_service(plain_fake_spec("disable-race", false))
            .await
            .unwrap();
        engine.set_residency(&service.id, true).await.unwrap();
        let lock = engine.test_service_lock(&service.id);
        let guard = lock.lock().await;

        let disabling_engine = engine.clone();
        let disabling_id = service.id.clone();
        let disable = tokio::spawn(async move {
            disabling_engine
                .set_residency(&disabling_id, false)
                .await
                .unwrap();
        });
        tokio::task::yield_now().await;
        let reconcile_engine = engine.clone();
        let reconcile = tokio::spawn(async move {
            reconcile_engine.reconcile_residency_once().await.unwrap();
        });
        drop(guard);
        disable.await.unwrap();
        reconcile.await.unwrap();

        assert!(!engine.get_residency(&service.id).unwrap().resident);
        assert_eq!(
            engine.status(&service.id).await.unwrap().state,
            ServiceState::Stopped
        );
    }

    #[tokio::test]
    async fn queued_stop_suspension_wins_over_reconcile_start() {
        let (state, _) = test_state();
        let engine = state.engine;
        let service = engine
            .create_service(plain_fake_spec("stop-race", false))
            .await
            .unwrap();
        engine.set_residency(&service.id, true).await.unwrap();
        let lock = engine.test_service_lock(&service.id);
        let guard = lock.lock().await;

        let stopping_engine = engine.clone();
        let stopping_id = service.id.clone();
        let stop = tokio::spawn(async move { stopping_engine.stop(&stopping_id).await.unwrap() });
        tokio::task::yield_now().await;
        let reconcile_engine = engine.clone();
        let reconcile = tokio::spawn(async move {
            reconcile_engine.reconcile_residency_once().await.unwrap();
        });
        drop(guard);
        stop.await.unwrap();
        reconcile.await.unwrap();

        let policy = engine.get_residency(&service.id).unwrap();
        assert!(policy.resident);
        assert!(policy.suspended);
        assert_eq!(
            engine.status(&service.id).await.unwrap().state,
            ServiceState::Stopped
        );
    }

    #[tokio::test]
    async fn failed_start_and_restart_still_clear_user_suspension() {
        let (state, _) = test_state();
        let engine = state.engine;
        let service = engine
            .create_service(plain_fake_spec("intent-on-failure", true))
            .await
            .unwrap();
        engine.set_residency(&service.id, true).await.unwrap();
        engine.stop(&service.id).await.unwrap();
        assert!(engine.get_residency(&service.id).unwrap().suspended);
        assert!(engine.start(&service.id).await.is_err());
        assert!(!engine.get_residency(&service.id).unwrap().suspended);

        engine.stop(&service.id).await.unwrap();
        assert!(engine.get_residency(&service.id).unwrap().suspended);
        assert!(engine.restart(&service.id).await.is_err());
        assert!(!engine.get_residency(&service.id).unwrap().suspended);
    }

    #[tokio::test]
    async fn one_time_ticket_creates_http_only_session_without_exposing_bearer() {
        let (state, token) = test_state();
        let app = super::router(state);
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/web-session-tickets")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let ticket_path = serde_json::from_slice::<serde_json::Value>(&body).unwrap()["path"]
            .as_str()
            .unwrap()
            .to_string();
        assert!(!ticket_path.contains(&token));

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(&ticket_path)
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::SEE_OTHER);
        let cookie = response
            .headers()
            .get(SET_COOKIE)
            .unwrap()
            .to_str()
            .unwrap();
        assert!(cookie.contains("HttpOnly"));
        assert!(cookie.contains("SameSite=Strict"));
        let cookie_pair = cookie.split(';').next().unwrap();

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services")
                    .header(COOKIE, cookie_pair)
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/web-session")
                    .header(COOKIE, cookie_pair)
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let csrf = serde_json::from_slice::<serde_json::Value>(&body).unwrap()["csrfToken"]
            .as_str()
            .unwrap()
            .to_string();
        let service_body = serde_json::json!({
            "name": "cookie-service",
            "provider": "fake",
            "command": ["demo"]
        })
        .to_string();

        let missing_origin = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(COOKIE, cookie_pair)
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(service_body.clone()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(missing_origin.status(), StatusCode::FORBIDDEN);

        let missing_csrf = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(COOKIE, cookie_pair)
                    .header("host", "127.0.0.1:20087")
                    .header("origin", "http://127.0.0.1:20087")
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(service_body.clone()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(missing_csrf.status(), StatusCode::FORBIDDEN);

        let wrong_origin = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(COOKIE, cookie_pair)
                    .header("host", "127.0.0.1:20087")
                    .header("origin", "http://evil.invalid")
                    .header("x-csrf-token", &csrf)
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(service_body.clone()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(wrong_origin.status(), StatusCode::FORBIDDEN);

        let allowed = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(COOKIE, cookie_pair)
                    .header("host", "127.0.0.1:20087")
                    .header("origin", "http://127.0.0.1:20087")
                    .header("x-csrf-token", &csrf)
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(service_body))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(allowed.status(), StatusCode::CREATED);

        let bearer_mutation = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(
                        serde_json::json!({
                            "name": "bearer-service",
                            "provider": "fake",
                            "command": ["demo"]
                        })
                        .to_string(),
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(bearer_mutation.status(), StatusCode::CREATED);

        let replay = app
            .oneshot(
                Request::builder()
                    .uri(&ticket_path)
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(replay.status(), StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn auth_is_required() {
        let (state, _tok) = test_state();
        let app = super::router(state);
        let res = app
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::UNAUTHORIZED);
        assert!(res.headers().get("www-authenticate").is_some());
    }

    #[tokio::test]
    async fn port_and_endpoint_routes_require_authentication() {
        let (state, _token) = test_state();
        let app = super::router(state);
        for uri in [
            "/api/v1/ports",
            "/api/v1/services/missing/endpoints",
            "/api/v1/services/missing/endpoints/web",
        ] {
            let response = app
                .clone()
                .oneshot(Request::builder().uri(uri).body(Body::empty()).unwrap())
                .await
                .unwrap();
            assert_eq!(response.status(), StatusCode::UNAUTHORIZED, "{uri}");
        }
    }

    #[tokio::test]
    async fn preferred_endpoint_is_published_and_stop_revokes_it() {
        let (state, token) = test_state();
        let app = super::router(state);
        let preferred = free_tcp_port();
        let id = create_service_with_port(
            &app,
            &token,
            "preferred-endpoint",
            preferred,
            serde_json::json!([]),
        )
        .await;

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/start"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/endpoints/web"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let endpoint: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(endpoint["status"], "healthy");
        assert_eq!(endpoint["port"], preferred);
        assert_eq!(endpoint["serviceId"], id);
        let published_generation = endpoint["generation"].as_u64().unwrap();

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/ports")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let ports: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(
            ports["leases"]
                .as_object()
                .unwrap()
                .values()
                .any(|lease| lease["serviceId"] == id)
        );

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/restart"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/endpoints/web"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let restarted_endpoint: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(restarted_endpoint["port"], preferred);

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/stop"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);

        let response = app
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/endpoints"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let resolution: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(resolution["status"], "stopped");
        assert_eq!(resolution["endpoints"].as_array().unwrap().len(), 0);
        assert!(resolution["generation"].as_u64().unwrap() > published_generation);
    }

    #[tokio::test]
    async fn occupied_preferred_port_falls_back_and_is_discoverable() {
        let occupied = TcpListener::bind(("127.0.0.1", 0)).unwrap();
        let preferred = occupied.local_addr().unwrap().port();
        let (state, token) = test_state();
        let app = super::router(state);
        let id = create_service_with_port(
            &app,
            &token,
            "fallback-endpoint",
            preferred,
            serde_json::json!([]),
        )
        .await;

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/start"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);

        let response = app
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/endpoints/web"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let endpoint: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_ne!(endpoint["port"], preferred);
        assert_eq!(endpoint["status"], "healthy");
    }

    #[tokio::test]
    async fn launch_retries_with_a_fallback_after_first_port_is_stolen() {
        let (state, token) = test_state();
        let app = super::router(state);
        let preferred = free_tcp_port();
        let spec = serde_json::json!({
            "name": "retry-fallback",
            "provider": "fake",
            "command": ["demo", "--port", "{{port:web}}"],
            "env": {"FAKE_OCCUPY_FIRST_PORT": "1"},
            "health": [{
                "type": "tcp",
                "address": "127.0.0.1:{{port:web}}",
                "interval": "10ms",
                "timeout": "100ms"
            }],
            "ports": [{
                "name": "web",
                "host": "127.0.0.1",
                "preferred": preferred,
                "dynamic": true,
                "pool": "local-web",
                "protocol": "tcp",
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }]
        });
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::CREATED);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let id = serde_json::from_slice::<serde_json::Value>(&body).unwrap()["id"]
            .as_str()
            .unwrap()
            .to_string();

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/start"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/endpoints/web"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let endpoint: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_ne!(endpoint["port"], preferred);

        let response = app
            .oneshot(
                Request::builder()
                    .uri("/api/v1/ports")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let state: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(state["orphans"].as_object().unwrap().is_empty());
    }

    #[tokio::test]
    async fn pidfd_owner_verification_rejects_wrong_host() {
        let (state, token) = test_state();
        let app = super::router(state);
        let preferred = free_tcp_port();
        let spec = serde_json::json!({
            "name": "wrong-host",
            "provider": "fake",
            "command": ["demo"],
            "env": {"FAKE_BIND_HOST": "127.0.0.1"},
            "health": [{
                "type": "tcp",
                "address": "127.0.0.1:{{port:web}}",
                "interval": "10ms",
                "timeout": "100ms"
            }],
            "ports": [{
                "name": "web",
                "host": "127.0.0.2",
                "preferred": preferred,
                "dynamic": true,
                "pool": "local-web",
                "protocol": "tcp",
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }]
        });
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::CREATED);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let id = serde_json::from_slice::<serde_json::Value>(&body).unwrap()["id"]
            .as_str()
            .unwrap()
            .to_string();
        let response = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/start"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let error: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(
            error["error"]["message"]
                .as_str()
                .unwrap()
                .contains("no matching tcp listener"),
            "{error}"
        );
    }

    #[tokio::test]
    async fn endpoint_without_health_is_rejected() {
        let (state, token) = test_state();
        let app = super::router(state);
        let spec = serde_json::json!({
            "name": "missing-health",
            "provider": "fake",
            "command": ["demo"],
            "ports": [{
                "name": "web",
                "preferred": free_tcp_port(),
                "dynamic": true,
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }]
        });
        let response = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn stop_failure_is_visible_as_orphan_in_ports_api() {
        let (state, token) = test_state();
        let app = super::router(state);
        let preferred = free_tcp_port();
        let spec = serde_json::json!({
            "name": "orphan-stop",
            "provider": "fake",
            "command": ["demo"],
            "env": {"FAKE_STOP_FAIL": "1"},
            "health": [{
                "type": "tcp",
                "address": "127.0.0.1:{{port:web}}",
                "interval": "10ms",
                "timeout": "100ms"
            }],
            "ports": [{
                "name": "web",
                "preferred": preferred,
                "dynamic": true,
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }]
        });
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let id = serde_json::from_slice::<serde_json::Value>(&body).unwrap()["id"]
            .as_str()
            .unwrap()
            .to_string();
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/start"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/stop"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::BAD_REQUEST);

        let response = app
            .oneshot(
                Request::builder()
                    .uri("/api/v1/ports")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let ports: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(ports["leases"].as_object().unwrap().is_empty());
        assert!(ports["endpoints"].as_object().unwrap().is_empty());
        let orphan = ports["orphans"]
            .as_object()
            .unwrap()
            .values()
            .next()
            .unwrap();
        assert_eq!(orphan["serviceId"], id);
        assert_eq!(orphan["lifecycle"], "orphaned");
        assert!(
            orphan["orphanReason"]
                .as_str()
                .unwrap()
                .contains("stop failed")
        );
    }

    #[tokio::test]
    async fn failed_health_never_publishes_endpoint() {
        let (state, token) = test_state();
        let app = super::router(state);
        let preferred = free_tcp_port();
        let id = create_service_with_port(
            &app,
            &token,
            "unhealthy-endpoint",
            preferred,
            serde_json::json!([{
                "type": "http",
                "url": "http://127.0.0.1:{{port:web}}/health",
                "interval": "10ms",
                "timeout": "10ms"
            }]),
        )
        .await;

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/start"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::BAD_REQUEST);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let error: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(
            error["error"]["message"]
                .as_str()
                .unwrap()
                .contains("unhealthy")
        );

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/endpoints"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let resolution: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(resolution["status"], "unhealthy");
        assert_eq!(resolution["endpoints"].as_array().unwrap().len(), 0);

        let response = app
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/endpoints/web"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    }

    #[tokio::test]
    async fn service_lifecycle() {
        let (state, tok) = test_state();
        let app = super::router(state);

        // Create
        let spec = serde_json::json!({
            "name": "demo",
            "description": "d",
            "provider": "fake",
            "command": ["echo", "hi"],
            "working_dir": "",
            "env": {},
            "runtime": {},
            "restart": {"mode": "no", "max_retries": 0},
            "health": [],
            "enabled": true,
            "tags": ["test"]
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::CREATED);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let v: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        let id = v["id"].as_str().unwrap().to_string();

        // Start
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/start"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NO_CONTENT);

        // Status
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/status"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let st: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(st["state"], "running");

        // Delete
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("DELETE")
                    .uri(format!("/api/v1/services/{id}"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NO_CONTENT);

        // Get (now 404)
        let res = app
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_FOUND);
    }

    #[tokio::test]
    async fn service_routes_accept_spec_name_alias() {
        let (state, tok) = test_state();
        let app = super::router(state);

        let spec = serde_json::json!({
            "name": "demo-alias",
            "description": "service name alias target",
            "provider": "fake",
            "command": ["echo", "hi"],
            "working_dir": "",
            "env": {},
            "runtime": {},
            "restart": {"mode": "no", "max_retries": 0},
            "health": [],
            "enabled": true,
            "tags": ["alias-test"]
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::CREATED);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let svc: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        let id = svc["id"].as_str().unwrap();
        assert_ne!(id, "demo-alias");

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services/demo-alias/start")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NO_CONTENT);

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services/demo-alias/status")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let status: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(status["service_id"], id);
        assert_eq!(status["state"], "running");

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services/demo-alias/logs")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);

        let res = app
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/status"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
    }

    #[tokio::test]
    async fn service_name_alias_rejects_ambiguous_matches() {
        let (state, tok) = test_state();
        let app = super::router(state);

        let mut ids = Vec::new();
        for description in ["first ambiguous service", "second ambiguous service"] {
            let spec = serde_json::json!({
                "name": "demo-ambiguous-alias",
                "description": description,
                "provider": "fake",
                "command": ["echo", description],
                "working_dir": "",
                "env": {},
                "runtime": {},
                "restart": {"mode": "no", "max_retries": 0},
                "health": [],
                "enabled": true,
                "tags": ["alias-ambiguity-test"]
            });
            let res = app
                .clone()
                .oneshot(
                    Request::builder()
                        .method("POST")
                        .uri("/api/v1/services")
                        .header(AUTHORIZATION, format!("Bearer {tok}"))
                        .header(CONTENT_TYPE, "application/json")
                        .body(Body::from(spec.to_string()))
                        .unwrap(),
                )
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::CREATED);
            let bytes = res.into_body().collect().await.unwrap().to_bytes();
            let svc: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
            ids.push(svc["id"].as_str().unwrap().to_string());
        }
        assert_ne!(ids[0], ids[1]);

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services/demo-ambiguous-alias/status")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::BAD_REQUEST);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let body: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert!(
            body["error"]["message"]
                .as_str()
                .unwrap()
                .contains("ambiguous")
        );

        let res = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services/demo-ambiguous-alias/start")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn restart_with_repair_hook_does_not_run_hook() {
        let (state, tok) = test_state();
        let app = super::router(state);
        let marker = std::env::temp_dir().join(format!(
            "service-manager-restart-hook-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));

        let spec = serde_json::json!({
            "name": "demo-restart-hook",
            "provider": "fake",
            "command": ["echo", "hi"],
            "repair": {
                "mode": "hook",
                "command": ["sh", "-c", "printf hook > \"$1\"", "sh", marker.to_string_lossy()],
                "timeout": "5s"
            }
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::CREATED);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let svc: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert!(svc["spec"]["repair"].is_object());
        assert!(svc["spec"]["runtime"]["service-manager.repair"].is_null());
        let id = svc["id"].as_str().unwrap();

        let res = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/restart"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NO_CONTENT);
        assert!(!marker.exists());
    }

    #[tokio::test]
    async fn repair_hook_receives_materialized_port_templates() {
        let (state, token) = test_state();
        let app = super::router(state);
        let marker = std::env::temp_dir().join(format!(
            "service-manager-repair-port-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let preferred = free_tcp_port();
        let spec = serde_json::json!({
            "name": "repair-port-template",
            "provider": "fake",
            "command": ["demo"],
            "health": [{
                "type": "tcp",
                "address": "127.0.0.1:{{port:web}}",
                "interval": "10ms",
                "timeout": "100ms"
            }],
            "ports": [{
                "name": "web",
                "preferred": preferred,
                "dynamic": true,
                "envVar": "PORT",
                "endpoint": {"scheme": "http", "path": "/"}
            }],
            "repair": {
                "mode": "hook",
                "command": [
                    "sh",
                    "-c",
                    "printf '%s' \"$REPAIR_PORT\" > \"$1\"",
                    "sh",
                    marker.to_string_lossy()
                ],
                "env": {"REPAIR_PORT": "{{port:web}}"},
                "timeout": "5s"
            }
        });
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::CREATED);
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let id = serde_json::from_slice::<serde_json::Value>(&body).unwrap()["id"]
            .as_str()
            .unwrap()
            .to_string();
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/start"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/endpoints/web"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let body = response.into_body().collect().await.unwrap().to_bytes();
        let endpoint: serde_json::Value = serde_json::from_slice(&body).unwrap();
        let allocated = endpoint["port"].as_u64().unwrap().to_string();

        let response = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/repair"))
                    .header(AUTHORIZATION, format!("Bearer {token}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::NO_CONTENT);
        assert_eq!(fs::read_to_string(&marker).unwrap(), allocated);
        let _ = fs::remove_file(marker);
    }

    #[tokio::test]
    async fn repair_without_hook_uses_legacy_restart() {
        let (state, tok) = test_state();
        let app = super::router(state);

        let spec = serde_json::json!({
            "name": "demo-legacy-repair",
            "provider": "fake",
            "command": ["echo", "hi"]
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::CREATED);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let svc: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        let id = svc["id"].as_str().unwrap();

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/repair"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NO_CONTENT);

        let res = app
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/status"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let status: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(status["state"], "running");
    }

    #[tokio::test]
    async fn repair_with_hook_executes_hook_and_propagates_failure() {
        let (state, tok) = test_state();
        let app = super::router(state);
        let marker = std::env::temp_dir().join(format!(
            "service-manager-repair-hook-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));

        let spec = serde_json::json!({
            "name": "demo-repair-hook",
            "provider": "fake",
            "command": ["echo", "hi"],
            "repair": {
                "mode": "hook",
                "command": [
                    "sh",
                    "-c",
                    "printf ran > \"$1\"; printf 'stdout-secret-token'; printf 'stderr-secret-token' >&2; exit 17",
                    "sh",
                    marker.to_string_lossy()
                ],
                "timeout": "5s"
            }
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::CREATED);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let svc: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        let id = svc["id"].as_str().unwrap();

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/repair"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::BAD_REQUEST);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let body: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert!(
            body["error"]["message"]
                .as_str()
                .unwrap()
                .contains("repair hook failed")
        );
        let body_text = body.to_string();
        assert!(!body_text.contains("stdout-secret-token"));
        assert!(!body_text.contains("stderr-secret-token"));
        assert_eq!(fs::read_to_string(&marker).unwrap(), "ran");

        let res = app
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/status"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let status: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(status["state"], "stopped");
    }

    #[tokio::test]
    async fn repair_with_successful_hook_does_not_restart_provider() {
        let (state, tok) = test_state();
        let app = super::router(state);
        let marker = std::env::temp_dir().join(format!(
            "service-manager-repair-success-hook-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));

        let spec = serde_json::json!({
            "name": "demo-repair-success-hook",
            "provider": "fake",
            "command": ["echo", "hi"],
            "repair": {
                "mode": "hook",
                "command": ["sh", "-c", "printf ran > \"$1\"", "sh", marker.to_string_lossy()],
                "timeout": "5s"
            }
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(spec.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::CREATED);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let svc: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        let id = svc["id"].as_str().unwrap();

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{id}/repair"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NO_CONTENT);
        assert_eq!(fs::read_to_string(&marker).unwrap(), "ran");

        let res = app
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1/services/{id}/status"))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let status: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(status["state"], "stopped");
    }

    #[tokio::test]
    async fn group_lifecycle() {
        let (state, tok) = test_state();
        let app = super::router(state);

        for name in ["demo-a", "demo-b"] {
            let spec = serde_json::json!({
                "name": name,
                "provider": "fake",
                "command": ["echo", name],
                "restart": {"mode": "no", "max_retries": 0},
                "tags": ["group:local-stack"]
            });
            let res = app
                .clone()
                .oneshot(
                    Request::builder()
                        .method("POST")
                        .uri("/api/v1/services")
                        .header(AUTHORIZATION, format!("Bearer {tok}"))
                        .header(CONTENT_TYPE, "application/json")
                        .body(Body::from(spec.to_string()))
                        .unwrap(),
                )
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::CREATED);
        }

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/groups")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let groups: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(groups.as_array().unwrap().len(), 1);
        assert_eq!(groups[0]["name"], "local-stack");
        assert_eq!(groups[0]["service_ids"].as_array().unwrap().len(), 2);

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/groups/local-stack/start")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let result: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(result["group"], "local-stack");
        assert_eq!(result["action"], "start");
        assert_eq!(result["total"], 2);
        assert_eq!(result["succeeded"].as_array().unwrap().len(), 2);
        assert_eq!(result["failed"].as_array().unwrap().len(), 0);

        let res = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/groups/missing/start")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_FOUND);
    }

    #[tokio::test]
    async fn service_filters_and_bulk_statuses() {
        let (state, tok) = test_state();
        let app = super::router(state);

        let mut ids = Vec::new();
        for (name, tags) in [
            ("phone-ai", vec!["smallphoneai", "group:phone-control"]),
            ("phone-app", vec!["smallphone", "group:phone-control"]),
            ("other", vec!["other", "group:other"]),
        ] {
            let spec = serde_json::json!({
                "name": name,
                "provider": "fake",
                "command": ["echo", name],
                "restart": {"mode": "no", "max_retries": 0},
                "tags": tags
            });
            let res = app
                .clone()
                .oneshot(
                    Request::builder()
                        .method("POST")
                        .uri("/api/v1/services")
                        .header(AUTHORIZATION, format!("Bearer {tok}"))
                        .header(CONTENT_TYPE, "application/json")
                        .body(Body::from(spec.to_string()))
                        .unwrap(),
                )
                .await
                .unwrap();
            assert_eq!(res.status(), StatusCode::CREATED);
            let bytes = res.into_body().collect().await.unwrap().to_bytes();
            let svc: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
            ids.push(svc["id"].as_str().unwrap().to_string());
        }

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri(format!("/api/v1/services/{}/start", ids[0]))
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NO_CONTENT);

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services?tag=smallphoneai")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let services: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(services.as_array().unwrap().len(), 1);
        assert_eq!(services[0]["spec"]["name"], "phone-ai");

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services?group=phone-control")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let services: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(services.as_array().unwrap().len(), 2);

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services/statuses?group=phone-control")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let statuses: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(statuses.as_array().unwrap().len(), 2);
        assert!(
            statuses
                .as_array()
                .unwrap()
                .iter()
                .any(|item| item["status"]["state"] == "running")
        );

        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/v1/groups/phone-control/status")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let statuses: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(statuses.as_array().unwrap().len(), 2);

        let res = app
            .oneshot(
                Request::builder()
                    .uri("/api/v1/groups/missing/status")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::NOT_FOUND);
    }

    #[tokio::test]
    async fn validation_and_provider_not_found() {
        let (state, tok) = test_state();
        let app = super::router(state);

        // Invalid name
        let bad = serde_json::json!({
            "name": "!!!",
            "provider": "fake"
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(bad.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::BAD_REQUEST);

        // Provider not found
        let bad = serde_json::json!({
            "name": "ok-name",
            "provider": "missing"
        });
        let res = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/services")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(bad.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::BAD_REQUEST);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let v: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(v["error"]["code"], "provider_not_found");
    }

    #[tokio::test]
    async fn registry_component_put_syncs_to_target() {
        let (state, tok) = test_state();
        let source_dir = PathBuf::from(&state.config.openhouse_registry_source_dir);
        let target_dir = PathBuf::from(&state.config.openhouse_registry_target_dir);
        let app = super::router(state);

        let manifest = serde_json::json!({
            "schemaVersion": 1,
            "id": "demo",
            "title": "Demo",
            "shellMenu": {},
            "smallphoneApp": {},
            "serviceManager": {},
            "ai": {}
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("PUT")
                    .uri("/api/v1/registry/components/demo")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(manifest.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert!(source_dir.join("components.d/demo.json").is_file());
        assert!(target_dir.join("components.d/demo.json").is_file());
        assert!(target_dir.join("registry-state.json").is_file());

        let res = app
            .oneshot(
                Request::builder()
                    .uri("/api/v1/registry/components")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let components: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(components.as_array().unwrap().len(), 1);
        assert_eq!(components[0]["id"], "demo");
    }

    #[tokio::test]
    async fn registry_apply_syncs_services_and_rejects_legacy_fields() {
        let (state, tok) = test_state();
        let source_dir = PathBuf::from(&state.config.openhouse_registry_source_dir);
        let target_dir = PathBuf::from(&state.config.openhouse_registry_target_dir);
        let app = super::router(state);

        let legacy = serde_json::json!({
            "component": {
                "schemaVersion": 1,
                "id": "demo",
                "title": "Demo",
                "shellMenu": {},
                "smallphoneApp": {},
                "serviceManager": {},
                "ai": {}
            },
            "serviceRegistry": {}
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/registry/apply")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(legacy.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::BAD_REQUEST);

        let payload = serde_json::json!({
            "component": {
                "schemaVersion": 1,
                "id": "demo",
                "title": "Demo",
                "shellMenu": {},
                "smallphoneApp": {},
                "serviceManager": {},
                "ai": {}
            },
            "services": [
                {
                    "id": "demo-service",
                    "service": {
                        "name": "demo-service",
                        "provider": "fake",
                        "command": ["echo", "demo"],
                        "restart": {"mode": "no", "max_retries": 0},
                        "tags": ["openhouse-component:demo"]
                    }
                }
            ],
            "aiDocs": [
                {
                    "path": "demo/openhouse.ai.md",
                    "content": "# Demo\n"
                }
            ]
        });
        let res = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/v1/registry/apply")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .header(CONTENT_TYPE, "application/json")
                    .body(Body::from(payload.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        assert!(source_dir.join("components.d/demo.json").is_file());
        assert!(
            source_dir
                .join("service-manager/services.d/demo-service.json")
                .is_file()
        );
        assert!(source_dir.join("ai-docs/demo/openhouse.ai.md").is_file());
        assert!(target_dir.join("components.d/demo.json").is_file());
        assert!(
            target_dir
                .join("service-manager/services.d/demo-service.json")
                .is_file()
        );
        assert!(target_dir.join("ai-docs/demo/openhouse.ai.md").is_file());
        assert!(target_dir.join("registry-state.json").is_file());

        let res = app
            .oneshot(
                Request::builder()
                    .uri("/api/v1/services?tag=openhouse-component:demo")
                    .header(AUTHORIZATION, format!("Bearer {tok}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(res.status(), StatusCode::OK);
        let bytes = res.into_body().collect().await.unwrap().to_bytes();
        let services: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(services.as_array().unwrap().len(), 1);
        assert_eq!(services[0]["id"], "demo-service");
        assert_eq!(services[0]["spec"]["name"], "demo-service");
    }
}
