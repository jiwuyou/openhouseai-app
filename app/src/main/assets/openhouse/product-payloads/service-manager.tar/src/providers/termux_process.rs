use std::{collections::BTreeMap, path::PathBuf};

use async_trait::async_trait;

use crate::{
    error::Result,
    model::{
        Capability, DetectResult, LogEntry, LogsOptions, Provider, ProviderId, Service,
        ServiceStatus,
    },
};

use super::{bad_request, find_in_path, process::ProcessProvider};

#[derive(Clone, Debug)]
pub struct TermuxProcessProvider {
    inner: ProcessProvider,
}

impl TermuxProcessProvider {
    pub fn new(data_dir: PathBuf) -> Self {
        Self {
            inner: ProcessProvider::new(data_dir),
        }
    }

    fn prefix() -> String {
        std::env::var("PREFIX").unwrap_or_else(|_| "/data/data/com.termux/files/usr".to_string())
    }

    fn home(svc: &Service) -> String {
        svc.spec
            .runtime
            .get("home")
            .and_then(|v| v.as_str())
            .filter(|v| !v.trim().is_empty())
            .map(|v| v.trim().to_string())
            .or_else(|| std::env::var("HOME").ok())
            .unwrap_or_else(|| "/data/data/com.termux/files/home".to_string())
    }

    fn path(prefix: &str, home: &str) -> String {
        [
            format!("{prefix}/bin"),
            format!("{home}/.local/bin"),
            format!("{home}/.local/node/bin"),
            format!("{home}/.npm-global/bin"),
            "/system/bin".to_string(),
            "/system/xbin".to_string(),
        ]
        .join(":")
    }

    fn path_dirs(path: &str) -> Vec<PathBuf> {
        path.split(':')
            .filter(|part| !part.trim().is_empty())
            .map(PathBuf::from)
            .collect()
    }

    fn resolve_command(command: &mut [String], path: &str) {
        let Some(program) = command.first_mut() else {
            return;
        };
        if program.contains('/') {
            return;
        }
        for dir in Self::path_dirs(path) {
            let candidate = dir.join(&program);
            if candidate.exists() {
                *program = candidate.to_string_lossy().to_string();
                return;
            }
        }
    }

    fn normalize_service(&self, svc: &Service) -> Service {
        let mut svc = svc.clone();
        svc.spec.provider = ProviderId("process".to_string());

        let prefix = Self::prefix();
        let home = Self::home(&svc);
        let path = Self::path(&prefix, &home);
        let defaults = BTreeMap::from([
            ("HOME".to_string(), home.clone()),
            ("PREFIX".to_string(), prefix.clone()),
            ("PATH".to_string(), path.clone()),
            ("LD_LIBRARY_PATH".to_string(), format!("{prefix}/lib")),
        ]);
        for (key, value) in defaults {
            svc.spec.env.entry(key).or_insert(value);
        }
        let runtime_path = svc.spec.env.get("PATH").cloned().unwrap_or(path);
        Self::resolve_command(&mut svc.spec.command, &runtime_path);
        svc
    }

    fn as_termux_status(mut status: ServiceStatus) -> ServiceStatus {
        status.provider = ProviderId("termux-process".to_string());
        status
    }
}

#[async_trait]
impl Provider for TermuxProcessProvider {
    fn id(&self) -> ProviderId {
        ProviderId("termux-process".to_string())
    }

    fn display_name(&self) -> String {
        "Termux process".to_string()
    }

    fn description(&self) -> String {
        "Spawn a Termux-native foreground process with Termux HOME/PREFIX/PATH defaults and process-group lifecycle tracking."
            .to_string()
    }

    fn capabilities(&self) -> Vec<Capability> {
        self.inner.capabilities()
    }

    async fn detect(&self) -> Result<DetectResult> {
        let prefix = Self::prefix();
        let sh = PathBuf::from(&prefix).join("bin").join("sh");
        if sh.exists() || find_in_path("sh", &[PathBuf::from(&prefix).join("bin")]).is_some() {
            return Ok(DetectResult {
                detected: true,
                details: "ok".to_string(),
            });
        }
        Ok(DetectResult {
            detected: false,
            details: format!("Termux shell not found under {prefix}/bin"),
        })
    }

    async fn register(&self, svc: &Service) -> Result<()> {
        if svc.spec.command.is_empty() {
            return Err(bad_request(
                "command is required for termux-process provider",
            ));
        }
        self.inner.register(&self.normalize_service(svc)).await
    }

    async fn unregister(&self, svc: &Service) -> Result<()> {
        self.inner.unregister(&self.normalize_service(svc)).await
    }

    async fn start(&self, svc: &Service) -> Result<()> {
        self.inner.start(&self.normalize_service(svc)).await
    }

    async fn stop(&self, svc: &Service) -> Result<()> {
        self.inner.stop(&self.normalize_service(svc)).await
    }

    async fn restart(&self, svc: &Service) -> Result<()> {
        self.inner.restart(&self.normalize_service(svc)).await
    }

    async fn status(&self, svc: &Service) -> Result<ServiceStatus> {
        self.inner
            .status(&self.normalize_service(svc))
            .await
            .map(Self::as_termux_status)
    }

    async fn logs(&self, svc: &Service, opts: LogsOptions) -> Result<Vec<LogEntry>> {
        self.inner.logs(&self.normalize_service(svc), opts).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{ProviderId, ServiceId, ServiceSpec};
    use chrono::Utc;

    fn svc() -> Service {
        Service {
            id: ServiceId("termux-demo".to_string()),
            spec: ServiceSpec {
                name: "termux-demo".to_string(),
                description: String::new(),
                provider: ProviderId("termux-process".to_string()),
                command: vec!["sh".to_string(), "-lc".to_string(), "true".to_string()],
                working_dir: String::new(),
                env: BTreeMap::new(),
                runtime: BTreeMap::new(),
                restart: Default::default(),
                health: vec![],
                ports: vec![],
                enabled: true,
                tags: vec![],
            },
            created_at: Utc::now(),
            updated_at: Utc::now(),
            deleted_at: None,
        }
    }

    #[test]
    fn normalize_service_adds_termux_defaults_and_delegates_to_process() {
        let provider = TermuxProcessProvider::new(std::env::temp_dir());
        let mut input = svc();
        let bin_dir = std::env::temp_dir().join(format!(
            "service-manager-termux-path-test-{}",
            std::process::id()
        ));
        std::fs::create_dir_all(&bin_dir).unwrap();
        let sh = bin_dir.join("sh");
        std::fs::write(&sh, b"#!/bin/sh\n").unwrap();
        input
            .spec
            .env
            .insert("PATH".to_string(), bin_dir.to_string_lossy().to_string());
        input.spec.runtime.insert(
            "home".to_string(),
            serde_json::Value::String("/data/data/com.termux/files/home".to_string()),
        );
        let svc = provider.normalize_service(&input);
        assert_eq!(svc.spec.provider.0, "process");
        assert_eq!(svc.spec.command[0], sh.to_string_lossy().to_string());
        assert!(svc.spec.env["HOME"].contains("com.termux"));
        assert!(svc.spec.env["PREFIX"].contains("com.termux"));
        assert_eq!(svc.spec.env["PATH"], bin_dir.to_string_lossy().to_string());
        assert!(svc.spec.env["LD_LIBRARY_PATH"].ends_with("/lib"));
        let _ = std::fs::remove_file(sh);
        let _ = std::fs::remove_dir(bin_dir);
    }

    #[test]
    fn normalize_service_preserves_explicit_env() {
        let provider = TermuxProcessProvider::new(std::env::temp_dir());
        let mut svc = svc();
        svc.spec
            .env
            .insert("HOME".to_string(), "/custom".to_string());
        let svc = provider.normalize_service(&svc);
        assert_eq!(svc.spec.env["HOME"], "/custom");
    }

    #[test]
    fn normalize_service_preserves_allocated_port_command_env_and_health() {
        use crate::model::{DurationDef, HealthCheck, HealthCheckType};
        use std::time::Duration;

        let provider = TermuxProcessProvider::new(std::env::temp_dir());
        let mut input = svc();
        input.spec.command = vec![
            "/data/data/com.termux/files/home/.local/bin/pi-web".to_string(),
            "--port".to_string(),
            "30142".to_string(),
        ];
        input
            .spec
            .env
            .insert("PI_WEB_PORT".to_string(), "30142".to_string());
        input.spec.health = vec![HealthCheck {
            ty: HealthCheckType::Http,
            interval: DurationDef(Duration::from_secs(5)),
            timeout: DurationDef(Duration::from_secs(2)),
            url: "http://127.0.0.1:30142/health".to_string(),
            address: String::new(),
        }];
        let original_command = input.spec.command.clone();
        let original_health = input.spec.health.clone();

        let normalized = provider.normalize_service(&input);

        assert_eq!(normalized.spec.command, original_command);
        assert_eq!(normalized.spec.env["PI_WEB_PORT"], "30142");
        assert_eq!(normalized.spec.health, original_health);
    }
}
