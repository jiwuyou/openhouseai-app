const fs = require("fs");
const os = require("os");
const path = require("path");

const SCHEMA_VERSION = 1;

function validId(value) {
  return /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(String(value || ""));
}

function candidatePaths(env = process.env) {
  const explicit = String(env.OPENHOUSE_ENDPOINTS_FILE || "").trim();
  if (explicit) return [explicit];
  const home = String(env.HOME || os.homedir() || "").trim();
  const candidates = [
    path.join(home, ".config", "openhouseai", "runtime", "endpoints.json"),
  ];
  const termuxHome = String(env.SMALLPHONEAI_TERMUX_HOME || "").trim();
  if (termuxHome) candidates.push(path.join(termuxHome, ".config", "openhouseai", "runtime", "endpoints.json"));
  candidates.push("/data/data/com.termux/files/home/.config/openhouseai/runtime/endpoints.json");
  return [...new Set(candidates.filter(Boolean))];
}

function normalizeLoopbackUrl(value) {
  try {
    const url = new URL(String(value || "").trim());
    if (url.protocol !== "http:"
      || !["127.0.0.1", "localhost", "::1", "[::1]"].includes(url.hostname)
      || !url.port
      || url.username
      || url.password
      || url.search
      || url.hash) return "";
    return url.href;
  } catch {
    return "";
  }
}

function parseSnapshot(value, now = Date.now) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("endpoint snapshot must be an object");
  if (value.schemaVersion !== SCHEMA_VERSION) throw new Error("unsupported endpoint snapshot schema");
  if (value.state !== "ready") throw new Error("endpoint snapshot is not ready");
  if (!String(value.managerInstanceId || "").trim()) throw new Error("endpoint snapshot managerInstanceId is missing");
  if (!Number.isInteger(value.snapshotRevision) || value.snapshotRevision < 0) throw new Error("endpoint snapshot revision is invalid");
  if (!Number.isInteger(value.portStateGeneration) || value.portStateGeneration < 0) throw new Error("endpoint port state generation is invalid");
  if (!Number.isFinite(Date.parse(value.generatedAt))) throw new Error("endpoint snapshot generatedAt is invalid");
  const expiresAt = Date.parse(value.expiresAt);
  if (!Number.isFinite(expiresAt) || expiresAt <= now()) throw new Error("endpoint snapshot expired");
  if (!Array.isArray(value.endpoints)) throw new Error("endpoint snapshot endpoints is invalid");
  const endpoints = new Map();
  for (const raw of value.endpoints) {
    const serviceId = String(raw?.serviceId || "").trim();
    const name = String(raw?.name || raw?.endpointName || "").trim();
    if (!validId(serviceId) || !validId(name)) throw new Error("endpoint serviceId/name is invalid");
    if (raw?.state && raw.state !== "ready") continue;
    const url = normalizeLoopbackUrl(raw?.url);
    if (!url) throw new Error("endpoint URL is not a loopback HTTP URL");
    endpoints.set(`${serviceId}\0${name}`, Object.freeze({
      serviceId,
      name,
      url,
      host: String(raw?.host || "").trim(),
      port: Number.isInteger(raw?.port) ? raw.port : Number(new URL(url).port),
      protocol: String(raw?.protocol || "").trim(),
      generation: Number.isInteger(raw?.generation) ? raw.generation : value.portStateGeneration,
      publishedAt: String(raw?.publishedAt || ""),
      state: "ready",
    }));
  }
  return Object.freeze({
    snapshotRevision: value.snapshotRevision,
    portStateGeneration: value.portStateGeneration,
    expiresAt,
    endpoints,
  });
}

class OpenHouseEndpointSnapshotReader {
  constructor(options = {}) {
    this.env = options.env || process.env;
    this.paths = options.filePath ? [options.filePath] : candidatePaths(this.env);
    this.now = options.now || Date.now;
    this.readFile = options.readFile || ((filePath) => fs.readFileSync(filePath, "utf8"));
    this.stat = options.stat || ((filePath) => fs.statSync(filePath));
    this.cached = null;
    this.cachedPath = "";
    this.cachedMtimeMs = -1;
    this.cachedSize = -1;
  }

  invalidate() {
    this.cached = null;
    this.cachedPath = "";
    this.cachedMtimeMs = -1;
    this.cachedSize = -1;
  }

  load() {
    let selected = null;
    for (const filePath of this.paths) {
      try {
        const info = this.stat(filePath);
        if (info.isFile()) {
          selected = { filePath, info };
          break;
        }
      } catch {
        // Try the next canonical location.
      }
    }
    if (!selected) {
      this.invalidate();
      return null;
    }
    const { filePath, info } = selected;
    if (this.cached
      && this.cachedPath === filePath
      && this.cachedMtimeMs === info.mtimeMs
      && this.cachedSize === info.size) {
      if (this.cached.expiresAt > this.now()) return this.cached;
      this.invalidate();
      return null;
    }
    try {
      const snapshot = parseSnapshot(JSON.parse(this.readFile(filePath)), this.now);
      this.cached = snapshot;
      this.cachedPath = filePath;
      this.cachedMtimeMs = info.mtimeMs;
      this.cachedSize = info.size;
      return snapshot;
    } catch {
      this.invalidate();
      return null;
    }
  }

  resolve(serviceId, endpointName) {
    if (!validId(serviceId) || !validId(endpointName)) return null;
    return this.load()?.endpoints.get(`${serviceId}\0${endpointName}`) || null;
  }
}

function resolveEndpointSnapshotPath(env = process.env) {
  return candidatePaths(env)[0];
}

module.exports = {
  SCHEMA_VERSION,
  OpenHouseEndpointSnapshotReader,
  normalizeLoopbackUrl,
  parseSnapshot,
  resolveEndpointSnapshotPath,
};
