const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");

const {
  OpenHouseEndpointSnapshotReader,
  normalizeLoopbackUrl,
} = require("../packages/shared/openhouse-endpoints");

function snapshot(url = "http://127.0.0.1:24000/") {
  return {
    schemaVersion: 1,
    state: "ready",
    managerInstanceId: "test-manager",
    snapshotRevision: 9,
    portStateGeneration: 9,
    generatedAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 60_000).toISOString(),
    endpoints: [{ serviceId: "smallphone-core", name: "api", url }],
  };
}

test("endpoint snapshot reader resolves ready dynamic URL", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "smallphone-endpoints-"));
  const file = path.join(dir, "endpoints.json");
  fs.writeFileSync(file, JSON.stringify(snapshot()));
  const reader = new OpenHouseEndpointSnapshotReader({ filePath: file });
  const endpoint = reader.resolve("smallphone-core", "api");
  assert.equal(endpoint.url, "http://127.0.0.1:24000/");
  assert.equal(reader.resolve("smallphone-frontend-beta", "web"), null);
});

test("expired, malformed, and external snapshots return null without fixed fallback", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "smallphone-endpoints-"));
  const file = path.join(dir, "endpoints.json");
  const expired = snapshot("http://127.0.0.1:22000/");
  expired.expiresAt = new Date(Date.now() - 1000).toISOString();
  fs.writeFileSync(file, JSON.stringify(expired));
  const reader = new OpenHouseEndpointSnapshotReader({ filePath: file });
  assert.equal(reader.resolve("smallphone-core", "api"), null);

  fs.writeFileSync(file, JSON.stringify(snapshot("http://example.com:24000/")));
  reader.invalidate();
  assert.equal(reader.resolve("smallphone-core", "api"), null);
});

test("URL sanitizer rejects credentials and query tokens", () => {
  assert.equal(normalizeLoopbackUrl("http://127.0.0.1:24000/api"), "http://127.0.0.1:24000/api");
  assert.equal(normalizeLoopbackUrl("http://user:secret@127.0.0.1:24000/"), "");
  assert.equal(normalizeLoopbackUrl("http://127.0.0.1:24000/?token=secret"), "");
});
