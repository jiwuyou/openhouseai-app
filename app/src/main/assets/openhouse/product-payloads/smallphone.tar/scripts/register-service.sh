#!/bin/sh
set -eu

log() { printf '%s\n' "$*"; }
warn() { printf 'WARN: %s\n' "$*" >&2; }

SCRIPT_DIR=$(cd "$(dirname "$0")" >/dev/null 2>&1 && pwd)
ROOT_DIR=$(cd "$SCRIPT_DIR/.." >/dev/null 2>&1 && pwd)
PARENT_DIR=$(cd "$ROOT_DIR/.." >/dev/null 2>&1 && pwd)

have() { command -v "$1" >/dev/null 2>&1; }

die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

resolve_sm_url() {
  raw="${SERVICE_MANAGER_URL:-}"
  if [ -n "$raw" ]; then
    printf '%s' "$raw"
    return 0
  fi
  raw="${SMALLPHONE_SERVICE_MANAGER_URL:-}"
  if [ -n "$raw" ]; then
    printf '%s' "$raw"
    return 0
  fi
  printf '%s' "http://127.0.0.1:20087"
}

resolve_sm_token() {
  raw="${SERVICE_MANAGER_TOKEN:-}"
  if [ -n "$raw" ]; then
    printf '%s' "$raw"
    return 0
  fi
  raw="${SMALLPHONE_SERVICE_MANAGER_TOKEN:-}"
  if [ -n "$raw" ]; then
    printf '%s' "$raw"
    return 0
  fi
  if have service-manager; then
    # Capture token without printing it.
    service-manager token show 2>/dev/null | tr -d '\r\n' || true
    return 0
  fi
  printf '%s' ""
}

print_intended_services() {
  group_tag="group:local-stack"

  core_port="${APP_BACKEND_PORT:-${SMALLPHONE_PORT:-22000}}"
  core_host="${APP_BACKEND_HOST:-${SMALLPHONE_HOST:-127.0.0.1}}"

  frontend_port="${FRONTEND_PORT:-22080}"
  frontend_host="${FRONTEND_HOST:-127.0.0.1}"

  beta_port="${BETA_FRONTEND_PORT:-22082}"
  beta_host="${BETA_FRONTEND_HOST:-$frontend_host}"

  backend_port="${BACKEND_PORT:-22096}"
  backend_host="${BACKEND_HOST:-127.0.0.1}"
  sillytavern_port="${SMALLPHONE_SILLYTAVERN_PORT:-${SILLYTAVERN_PORT:-8000}}"
  sillytavern_host="${SMALLPHONE_SILLYTAVERN_HOST:-${SILLYTAVERN_HOST:-127.0.0.1}}"
  controlled_browser_port="${SMALLPHONE_CONTROLLED_BROWSER_PORT:-23080}"
  controlled_browser_host="${SMALLPHONE_CONTROLLED_BROWSER_HOST:-127.0.0.1}"
  cloudcli_port="${SMALLPHONE_CLOUDCLI_PORT:-${CLOUDCLI_PORT:-${CLAUDE_CODE_UI_PORT:-23083}}}"
  cloudcli_host="${SMALLPHONE_CLOUDCLI_HOST:-${CLOUDCLI_HOST:-127.0.0.1}}"

  log "Intended services (name | bind | tags):"
  log "  smallphone-core | ${core_host}:${core_port} | ${group_tag}, openhouse-component:smallphone-core"
  log "  smallphone-frontend | ${frontend_host}:${frontend_port} | ${group_tag}, openhouse-component:smallphone-frontend"
  log "  smallphone-frontend-beta | ${beta_host}:${beta_port} | ${group_tag}, openhouse-component:smallphone-frontend-beta"
  log "  smallphone-backend | ${backend_host}:${backend_port} | ${group_tag}, openhouse-component:smallphone-backend"
  log "  smallphone-standalone-diary | 127.0.0.1:23001 | ${group_tag}, openhouse-component:smallphone-standalone, smallphone-app:diary"
  log "  smallphone-standalone-like-girl | 127.0.0.1:23003 | ${group_tag}, openhouse-component:smallphone-standalone, smallphone-app:like-girl"
  log "  smallphone-standalone-like-girl-clone | 127.0.0.1:23008 | ${group_tag}, openhouse-component:smallphone-standalone, smallphone-app:like-girl-clone"
  log "  smallphone-standalone-album | 127.0.0.1:23004 | ${group_tag}, openhouse-component:smallphone-standalone, smallphone-app:album"
  log "  smallphone-like-girl-source | 127.0.0.1:23002 | ${group_tag}, openhouse-component:smallphone-standalone, smallphone-kind:source-app"
  log "  smallphone-sillytavern | ${sillytavern_host}:${sillytavern_port} | ${group_tag}, openhouse-component:smallphone-standalone, smallphone-app:sillytavern"
  log "  controlled-browser | ${controlled_browser_host}:${controlled_browser_port} | ${group_tag}, openhouse-component:controlled-browser, smallphone-app:controlled-browser"
  log "  cloudcli | ${cloudcli_host}:${cloudcli_port} | ${group_tag}, openhouse-component:cloudcli, openhouse-ai-partner:cloudcli"
  log ""
  log "Notes:"
  log "  - smallphone-core port is SMALLPHONE_PORT (default 22000) or APP_BACKEND_PORT."
  log "  - stable frontend uses python3 http.server; beta frontend uses Node static-server.cjs."
  log "  - smallphone-backend is the OpenCode bun backend (optional; only registered if present)."
  log "  - standalone apps use PORT/HOST env vars; defaults are from each smallphone.app.json."
}

ensure_work_dir() {
  umask 077
  tmp_base="${TMPDIR:-/tmp}"
  if ! have mktemp; then
    return 1
  fi
  mktemp -d "${tmp_base%/}/smallphone-sm.XXXXXX" 2>/dev/null || true
}

write_curl_cfg() {
  cfg_path="$1"
  token="$2"
  # Use a curl config file so bearer tokens do not end up in process listings.
  printf 'header = "Authorization: Bearer %s"\n' "$token" >"$cfg_path"
  printf 'header = "Content-Type: application/json"\n' >>"$cfg_path"
}

service_name_to_id() {
  py="$1"
  name="$2"
  "${py}" -c '
import json
import sys

name = sys.argv[1]
raw = sys.stdin.read().strip()
if not raw:
    sys.exit(0)

try:
    payload = json.loads(raw)
except Exception:
    sys.exit(0)

services = []
if isinstance(payload, list):
    services = payload
elif isinstance(payload, dict):
    if isinstance(payload.get("services"), list):
        services = payload["services"]
    elif isinstance(payload.get("data"), list):
        services = payload["data"]
    elif isinstance(payload.get("data"), dict) and isinstance(payload["data"].get("services"), list):
        services = payload["data"]["services"]

for svc in services:
    if not isinstance(svc, dict):
        continue
    spec = svc.get("spec")
    if isinstance(spec, dict) and spec.get("name") == name:
        sid = svc.get("id")
        if isinstance(sid, str) and sid:
            sys.stdout.write(sid)
            break
' "$name"
}

emit_spec() {
  py="$1"
  key="$2"
  core_host="$3"
  core_port="$4"
  frontend_host="$5"
  frontend_port="$6"
  beta_host="$7"
  beta_port="$8"
  backend_host="$9"
  backend_port="${10}"
  service_manager_url="${11}"
  "${py}" - "$key" "$ROOT_DIR" "$PARENT_DIR" \
    "$core_host" "$core_port" \
    "$frontend_host" "$frontend_port" \
    "$beta_host" "$beta_port" \
    "$backend_host" "$backend_port" \
    "$service_manager_url" <<'PY'
import json
import os
import shutil
import sys
from pathlib import Path

(
    key,
    root_dir,
    parent_dir,
    core_host,
    core_port,
    frontend_host,
    frontend_port,
    beta_host,
    beta_port,
    backend_host,
    backend_port,
    service_manager_url,
) = sys.argv[1:]

root = Path(root_dir)
parent = Path(parent_dir)

group_tag = "group:local-stack"

def guest_path() -> str:
    entries = [
        "/root/.local/bin",
        "/root/.local/node/bin",
        "/root/.npm-global/bin",
        "/usr/local/bin",
        "/usr/local/sbin",
        "/usr/sbin",
        "/usr/bin",
        "/sbin",
        "/bin",
    ]
    seen: set[str] = set()
    merged: list[str] = []
    for raw in entries:
        if raw and raw not in seen:
            seen.add(raw)
            merged.append(raw)
    return ":".join(merged)

def merged_path() -> str:
    return guest_path()

termux_home = Path(os.environ.get("OPENHOUSEAI_TERMUX_HOME") or os.environ.get("SMALLPHONEAI_TERMUX_HOME") or "/data/data/com.termux/files/home")
termux_prefix = Path(os.environ.get("TERMUX_PREFIX") or "/data/data/com.termux/files/usr")
termux_config_root = termux_home / ".config" / "openhouseai"
service_manager_config_file = Path(
    os.environ.get("SMALLPHONEAI_SERVICE_MANAGER_CONFIG_PATH")
    or os.environ.get("SERVICE_MANAGER_CONFIG_PATH")
    or termux_config_root / "service-manager" / "config.json"
)
components_dir = Path(os.environ.get("SMALLPHONE_COMPONENTS_DIR") or termux_config_root / "components.d")
menu_overrides_file = Path(os.environ.get("SMALLPHONE_MENU_OVERRIDES_FILE") or termux_config_root / "menu-overrides.json")
endpoint_snapshot_file = Path(
    os.environ.get("OPENHOUSE_ENDPOINTS_FILE")
    or termux_home / ".config" / "openhouseai" / "runtime" / "endpoints.json"
)

def resolve_executable(env_names: list[str], candidates: list[str], fallback_name: str) -> str:
    for env_name in env_names:
        value = os.environ.get(env_name)
        if value:
            return value
    for candidate in candidates:
        if Path(candidate).is_file():
            return candidate
    found = shutil.which(fallback_name, path=merged_path())
    if found:
        return found
    return candidates[0] if candidates else fallback_name

def env_path(*names: str) -> Path | None:
    for name in names:
        raw = os.environ.get(name)
        if raw:
            return Path(raw).expanduser()
    return None

def first_existing(*paths: Path | None) -> Path:
    candidates = [path for path in paths if path is not None]
    for path in candidates:
        if path.exists():
            return path
    return candidates[0]

def resolve_frontend_dir() -> Path:
    explicit = env_path("SMALLPHONE_FRONTEND_DIR", "FRONTEND_DIR")
    if explicit is not None:
        return explicit
    return first_existing(
        root / "generic-mini-phone",
        Path("/root/generic-mini-phone"),
        root / "generic-mini-phone-beta",
    )

def resolve_sillytavern_dir() -> Path:
    explicit = env_path("SMALLPHONE_SILLYTAVERN_DIR", "SILLYTAVERN_DIR")
    if explicit is not None:
        return explicit
    return first_existing(
        parent / "sillytavern",
        Path("/root/SillyTavern"),
        Path("/root/.local/share/SillyTavern"),
    )

def tcp_check(host: str, port: str):
    return {
        "type": "tcp",
        "address": f"{host}:{port}",
        "interval": "30s",
        "timeout": "3s",
    }

def http_check(url: str):
    return {
        "type": "http",
        "url": url,
        "interval": "30s",
        "timeout": "5s",
    }

def port_spec(name: str, host: str, preferred: str, env_var: str, path: str = "/"):
    try:
        preferred_number = int(str(preferred))
    except (TypeError, ValueError):
        preferred_number = 1
    return {
        "name": name,
        "host": host,
        "preferred": max(1, min(65535, preferred_number)),
        "dynamic": True,
        "pool": "local-web",
        "protocol": "tcp",
        "envVar": env_var,
        "endpoint": {"scheme": "http", "path": path},
    }

def spec_process(name: str, desc: str, cmd: list[str], cwd: Path, env: dict, health: list, tags: list[str], ports=None):
    guest_env = [f"{key}={value}" for key, value in sorted(env.items())]
    wrapped_command = [
        "sh",
        "-lc",
        'set -eu; unset LD_LIBRARY_PATH LD_PRELOAD PREFIX; export HOME=/root TMPDIR=/tmp; export PATH="$1"; shift; while [ "$#" -gt 0 ] && [ "$1" != "--" ]; do export "$1"; shift; done; shift; exec "$@"',
        "service-manager-guest",
        guest_path(),
        *guest_env,
        "--",
        *cmd,
    ]
    service_tags = list(tags)
    for tag in ("runtime:ubuntu", "manager:termux-native"):
        if tag not in service_tags:
            service_tags.append(tag)
    spec = {
        "name": name,
        "description": desc,
        "provider": "proot-distro",
        "command": wrapped_command,
        "working_dir": str(cwd),
        "env": {
            "HOME": str(termux_home),
            "PREFIX": str(termux_prefix),
            "PATH": f"{termux_prefix}/bin:/system/bin:/system/xbin",
            "LD_LIBRARY_PATH": f"{termux_prefix}/lib",
            "TMPDIR": f"{termux_prefix}/tmp",
        },
        "runtime": {"distro": "ubuntu", "home": "/root", "user": "root"},
        "restart": {"mode": "always", "max_retries": 0},
        "health": health,
        "enabled": True,
        "tags": service_tags,
    }
    if ports:
        spec["ports"] = ports
    return spec

if key == "smallphone-core":
    app_dir = root / "smallphone-app"
    smallphone_home = str(parent / "smallphone-home")
    sillytavern_dir = resolve_sillytavern_dir()
    spec = spec_process(
        "smallphone-core",
        "SmallPhone core API backed by the Termux canonical OpenHouse registry",
        ["node", "./apps/core/run-managed.js"],
        app_dir,
        {
            "SMALLPHONE_HOME": smallphone_home,
            "SMALLPHONE_HOST": core_host,
            "SMALLPHONE_HOSTS": core_host,
            "SMALLPHONE_PORT": "{{port:api}}",
            "SMALLPHONE_COMPONENTS_DIR": str(components_dir),
            "SMALLPHONE_MENU_OVERRIDES_FILE": str(menu_overrides_file),
            "SMALLPHONE_RUNTIME_MODE": "cc-connect",
            "CC_CONNECT_CONFIG_FILE": "/root/.smallphoneai/cc-connect.toml",
            "SMALLPHONE_CCCONNECT_PLATFORM": "smallphone",
            "SMALLPHONE_SERVICE_MANAGER_URL": service_manager_url,
            "SMALLPHONE_SERVICE_MANAGER_CONFIG_FILE": str(service_manager_config_file),
            "OPENHOUSE_ENDPOINTS_FILE": str(endpoint_snapshot_file),
            "SMALLPHONE_SILLYTAVERN_DIR": str(sillytavern_dir),
            "SMALLPHONE_SILLYTAVERN_DATA_DIR": str(sillytavern_dir / "data"),
            "SMALLPHONE_SILLYTAVERN_SERVICE_ID": "smallphone-sillytavern",
        },
        [http_check(f"http://{core_host}:{{{{port:api}}}}/health")],
        [group_tag, "openhouse-component:smallphone-core", "smallphone"],
        [port_spec("api", core_host, core_port, "SMALLPHONE_PORT", "/")],
    )
elif key == "smallphone-frontend":
    front_dir = resolve_frontend_dir()
    spec = spec_process(
        "smallphone-frontend",
        "SmallPhone stable frontend (static, served by python http.server)",
        ["python3", "-m", "http.server", "{{port:web}}", "--bind", str(frontend_host)],
        front_dir,
        {},
        [http_check(f"http://{frontend_host}:{{{{port:web}}}}/")],
        [group_tag, "openhouse-component:smallphone-frontend", "smallphone"],
        [port_spec("web", frontend_host, frontend_port, "PORT", "/")],
    )
elif key == "smallphone-frontend-beta":
    front_dir = root / "generic-mini-phone-beta"
    spec = spec_process(
        "smallphone-frontend-beta",
        "SmallPhone beta frontend (static, served by Node)",
        ["node", "scripts/static-server.cjs", "{{port:web}}", str(beta_host)],
        front_dir,
        {
            "PORT": "{{port:web}}",
            "HOST": str(beta_host),
            "SMALLPHONE_SERVICE_MANAGER_URL": service_manager_url,
            "SMALLPHONEAI_SERVICE_MANAGER_CONFIG_PATH": str(service_manager_config_file),
            "SERVICE_MANAGER_CONFIG_PATH": str(service_manager_config_file),
            "OPENHOUSE_ENDPOINTS_FILE": str(endpoint_snapshot_file),
        },
        [http_check(f"http://{beta_host}:{{{{port:web}}}}/")],
        [group_tag, "openhouse-component:smallphone-frontend-beta", "smallphone"],
        [port_spec("web", beta_host, beta_port, "PORT", "/")],
    )
elif key == "smallphone-backend":
    opencode_dir = parent / "opencode"
    # This is optional; the caller should skip registration if the directory does not exist.
    spec = spec_process(
        "smallphone-backend",
        "SmallPhone backend (OpenCode bun server)",
        ["bun", "--cwd", "packages/opencode", "src/index.ts", "serve", "--hostname", str(backend_host), "--port", "{{port:web}}"],
        opencode_dir,
        {},
        [http_check(f"http://{backend_host}:{{{{port:web}}}}/")],
        [group_tag, "openhouse-component:smallphone-backend", "smallphone", "opencode"],
        [port_spec("web", backend_host, backend_port, "PORT", "/")],
    )
elif key == "smallphone-standalone-diary":
    app_dir = root / "standalone-apps" / "diary"
    port = "23001"
    spec = spec_process(
        "smallphone-standalone-diary",
        "SmallPhone standalone Diary app (Node/SQLite)",
        ["node", "./src/server.js"],
        app_dir,
        {"HOST": "127.0.0.1", "PORT": "{{port:web}}"},
        [http_check("http://127.0.0.1:{{port:web}}/health")],
        [group_tag, "openhouse-component:smallphone-standalone", "smallphone", "smallphone-app:diary"],
        [port_spec("web", "127.0.0.1", port, "PORT", "/")],
    )
elif key == "smallphone-standalone-album":
    app_dir = root / "standalone-apps" / "album"
    port = "23004"
    spec = spec_process(
        "smallphone-standalone-album",
        "SmallPhone standalone Album app (Node/SQLite)",
        ["node", "./src/server.js"],
        app_dir,
        {"HOST": "127.0.0.1", "PORT": "{{port:web}}"},
        [http_check("http://127.0.0.1:{{port:web}}/health")],
        [group_tag, "openhouse-component:smallphone-standalone", "smallphone", "smallphone-app:album"],
        [port_spec("web", "127.0.0.1", port, "PORT", "/")],
    )
elif key == "smallphone-standalone-like-girl":
    app_dir = root / "standalone-apps" / "like-girl"
    port = "23003"
    spec = spec_process(
        "smallphone-standalone-like-girl",
        "SmallPhone standalone LikeGirl app (Node/SQLite)",
        ["node", "./src/server.js"],
        app_dir,
        {"HOST": "127.0.0.1", "PORT": "{{port:web}}"},
        [http_check("http://127.0.0.1:{{port:web}}/health")],
        [group_tag, "openhouse-component:smallphone-standalone", "smallphone", "smallphone-app:like-girl", "control-test:smallphone-likegirl"],
        [port_spec("web", "127.0.0.1", port, "PORT", "/")],
    )
elif key == "smallphone-standalone-like-girl-clone":
    app_dir = root / "standalone-apps" / "like-girl"
    port = "23008"
    spec = spec_process(
        "smallphone-standalone-like-girl-clone",
        "SmallPhone standalone LikeGirl clone control app (Node/SQLite)",
        ["node", "./src/server.js"],
        app_dir,
        {
            "HOST": "127.0.0.1",
            "PORT": "{{port:web}}",
            "LIKE_GIRL_DB_FILE": "./data/instances/like-girl-clone/like-girl.sqlite",
            "LIKE_GIRL_PHOTO_UPLOADS_DIR": "./data/instances/like-girl-clone/uploads/photos",
        },
        [http_check("http://127.0.0.1:{{port:web}}/health")],
        [group_tag, "openhouse-component:smallphone-standalone", "smallphone", "smallphone-app:like-girl-clone", "control-test:smallphone-likegirl"],
        [port_spec("web", "127.0.0.1", port, "PORT", "/")],
    )
elif key == "smallphone-like-girl-source":
    app_dir = root / "standalone-apps" / "vocabulary"
    port = "23002"
    source_ready = (app_dir / "source").exists()
    desc = "SmallPhone LikeGirl source-app adapter (Node launcher + PHP built-in server)"
    tags = ["openhouse-component:smallphone-standalone", "smallphone", "smallphone-kind:source-app"]
    if source_ready:
        tags.insert(0, group_tag)
    else:
        desc += " (disabled: source checkout not present)"
    # This adapter spawns PHP; health is best-effort TCP only.
    spec = spec_process(
        "smallphone-like-girl-source",
        desc,
        ["node", "./scripts/start.mjs"],
        app_dir,
        {"HOST": "127.0.0.1", "PORT": "{{port:web}}"},
        [http_check("http://127.0.0.1:{{port:web}}/")],
        tags,
        [port_spec("web", "127.0.0.1", port, "PORT", "/")],
    )
    spec["enabled"] = source_ready
elif key == "smallphone-sillytavern":
    app_dir = resolve_sillytavern_dir()
    data_dir = Path(os.environ.get("SMALLPHONE_SILLYTAVERN_DATA_DIR") or os.environ.get("SILLYTAVERN_DATA_DIR") or str(app_dir / "data"))
    host = os.environ.get("SMALLPHONE_SILLYTAVERN_HOST") or os.environ.get("SILLYTAVERN_HOST") or "127.0.0.1"
    port = os.environ.get("SMALLPHONE_SILLYTAVERN_PORT") or os.environ.get("SILLYTAVERN_PORT") or "8000"
    spec = spec_process(
        "smallphone-sillytavern",
        "SmallPhone SillyTavern service (Node app)",
        ["node", "server.js"],
        app_dir,
        {
            "HOST": host,
            "PORT": "{{port:web}}",
            "SILLYTAVERN_DATA_DIR": str(data_dir),
            "SMALLPHONE_SILLYTAVERN_DATA_DIR": str(data_dir),
        },
        [http_check(f"http://{host}:{{{{port:web}}}}/")],
        [group_tag, "openhouse-component:smallphone-standalone", "smallphone", "smallphone-app:sillytavern", "smallphone-instance:sillytavern"],
        [port_spec("web", host, port, "PORT", "/")],
    )
elif key == "controlled-browser":
    status_command = os.environ.get("SMALLPHONE_CONTROLLED_BROWSER_COMMAND") or (
        "printf '%s\\n' 'controlled-browser is event-driven; use openhouse-browser commands to control the app WebView'; "
        "while :; do sleep \"${SMALLPHONE_CONTROLLED_BROWSER_KEEPALIVE_INTERVAL:-3600}\"; done"
    )
    spec = spec_process(
        "controlled-browser",
        "OpenHouse controlled browser CLI helper",
        ["sh", "-lc", status_command],
        root,
        {},
        [],
        [group_tag, "openhouse-component:controlled-browser", "smallphone", "smallphone-app:controlled-browser", "smallphone-instance:controlled-browser"],
    )
elif key == "cloudcli":
    host = os.environ.get("SMALLPHONE_CLOUDCLI_HOST") or os.environ.get("CLOUDCLI_HOST") or "127.0.0.1"
    port = os.environ.get("SMALLPHONE_CLOUDCLI_PORT") or os.environ.get("CLOUDCLI_PORT") or os.environ.get("CLAUDE_CODE_UI_PORT") or "23083"
    claude_cli = os.environ.get("CLAUDE_CLI_PATH") or "/root/.local/bin/claude"
    cloudcli_bin = resolve_executable(
        ["SMALLPHONE_CLOUDCLI_BIN", "CLOUDCLI_BIN"],
        ["/root/.npm-global/bin/cloudcli", "/usr/local/bin/cloudcli"],
        "cloudcli",
    )
    # Invoke node directly so service-manager's strict /proc cmdline verification
    # matches the live process. Running the cloudcli symlink rewrites argv to
    # "node /path/to/cloudcli ..." and makes stop/restart lose the pidfile.
    spec = spec_process(
        "cloudcli",
        "CC/Codex web console powered by CloudCLI / Claude Code UI",
        ["node", cloudcli_bin, "start", "--port", "{{port:web}}"],
        Path("/root"),
        {
            "HOME": "/root",
            "SERVER_PORT": "{{port:web}}",
            "PORT": "{{port:web}}",
            "HOST": host,
            "CLAUDE_CLI_PATH": claude_cli,
            "WORKSPACES_ROOT": os.environ.get("WORKSPACES_ROOT") or "/root",
            "DATABASE_PATH": os.environ.get("DATABASE_PATH") or "/root/.cloudcli/openhouse-auth.db",
        },
        [http_check(f"http://{host}:{{{{port:web}}}}/")],
        [group_tag, "openhouse-component:cloudcli", "openhouse-ai-partner:cloudcli", "smallphone"],
        [port_spec("web", host, port, "PORT", "/")],
    )
else:
    raise SystemExit(f"unknown spec key: {key}")

json.dump(spec, sys.stdout, ensure_ascii=True)
PY
}

build_registry_apply_payload() {
  py="$1"
  output_file="$2"
  spec_dir="$3"
  shift 3
  "$py" - "$output_file" "$spec_dir" "$@" <<'PY'
import json
import sys
from pathlib import Path

output = Path(sys.argv[1])
spec_dir = Path(sys.argv[2])
service_ids = sys.argv[3:]
services = []
for service_id in service_ids:
    spec = json.loads((spec_dir / f"{service_id}.json").read_text(encoding="utf-8"))
    services.append({"schemaVersion": 1, "id": service_id, "service": spec})
output.write_text(json.dumps({"services": services}, ensure_ascii=True), encoding="utf-8")
PY
}

purge_existing_services() {
  sm_url="$1"
  curl_cfg="$2"
  py="$3"
  shift 3
  services_json="$(curl -q -fsS --max-time 5 -K "$curl_cfg" "${sm_url%/}/api/v1/services")" || return 1
  existing_ids="$(
    printf '%s' "$services_json" | "$py" -c '
import json
import sys

stable_ids = set(sys.argv[1:])
payload = json.load(sys.stdin)
services = payload if isinstance(payload, list) else payload.get("services", [])
if isinstance(services, dict):
    services = services.get("services", [])
for item in services:
    if not isinstance(item, dict):
        continue
    nested = item.get("service") if isinstance(item.get("service"), dict) else item
    service_id = str(item.get("id") or nested.get("id") or item.get("serviceId") or item.get("service_id") or "").strip()
    spec = nested.get("spec") if isinstance(nested.get("spec"), dict) else nested
    name = str(spec.get("name") or item.get("name") or "").strip()
    if service_id and (service_id in stable_ids or name in stable_ids):
        print(service_id)
' "$@" 2>/dev/null || true
  )"
  [ -n "$existing_ids" ] || return 0
  printf '%s\n' "$existing_ids" | while IFS= read -r existing_id; do
    [ -n "$existing_id" ] || continue
    log "service-manager: replacing existing id=${existing_id}"
    curl -q -fsS --max-time 10 -X POST -K "$curl_cfg" "${sm_url%/}/api/v1/services/${existing_id}/stop" >/dev/null 2>&1 || true
    curl -q -fsS --max-time 10 -X DELETE -K "$curl_cfg" "${sm_url%/}/api/v1/services/${existing_id}" >/dev/null || \
      die "service-manager: failed to delete ${existing_id} before registry apply"
  done
}

apply_registry() {
  sm_url="$1"
  curl_cfg="$2"
  payload_file="$3"
  shift 3
  log "service-manager: applying stable SmallPhone service registry"
  curl -q -fsS --max-time 20 -X POST -K "$curl_cfg" --data-binary "@$payload_file" \
    "${sm_url%/}/api/v1/registry/apply" >/dev/null
  for service_id in "$@"; do
    curl -q -fsS --max-time 5 -X POST -K "$curl_cfg" \
      "${sm_url%/}/api/v1/services/${service_id}/register" >/dev/null 2>&1 || true
  done
}

print_manual_commands() {
  sm_url="$1"
  log ""
  log "Manual registration (curl + token):"
  log "  export SERVICE_MANAGER_URL=\"${sm_url}\""
  log "  export SERVICE_MANAGER_TOKEN=\"<token>\""
  log '  curl -fsS -H "Authorization: Bearer $SERVICE_MANAGER_TOKEN" -H "Content-Type: application/json" \'
  log "    -d '{\"services\":[{\"id\":\"smallphone-core\",\"service\":{...}}]}' \"${sm_url%/}/api/v1/registry/apply\""
  log ""
  log "Tip: create/update via the service-manager Web UI at: ${sm_url%/}/"
}

print_spec() {
  key="${1:-}"
  [ -n "$key" ] || die "usage: $0 --print-spec <service-key>"
  py="$(command -v python3 || command -v python || true)"
  [ -n "$py" ] || die "python is required"
  emit_spec "$py" "$key" \
    "${APP_BACKEND_HOST:-${SMALLPHONE_HOST:-127.0.0.1}}" \
    "${APP_BACKEND_PORT:-${SMALLPHONE_PORT:-22000}}" \
    "${FRONTEND_HOST:-127.0.0.1}" "${FRONTEND_PORT:-22080}" \
    "${BETA_FRONTEND_HOST:-${FRONTEND_HOST:-127.0.0.1}}" "${BETA_FRONTEND_PORT:-22082}" \
    "${BACKEND_HOST:-127.0.0.1}" "${BACKEND_PORT:-22096}" \
    "$(resolve_sm_url)"
}

main() {
  log "SmallPhone service registration (best-effort)"
  sm_url="$(resolve_sm_url)"
  log "service-manager url: ${sm_url}"
  log "registration token sources: SERVICE_MANAGER_TOKEN, SMALLPHONE_SERVICE_MANAGER_TOKEN, or \`service-manager token show\`"
  log "smallphone-core reads the runtime token from the Termux canonical service-manager config"
  log ""
  print_intended_services

  if ! have curl; then
    warn "curl not found; cannot call service-manager API"
    print_manual_commands "$sm_url"
    exit 0
  fi

  if ! curl -fsS --max-time 2 "${sm_url%/}/api/v1/health" >/dev/null 2>&1; then
    warn "service-manager is not reachable at: ${sm_url}"
    warn "start it with: service-manager serve --bind 127.0.0.1:20087"
    print_manual_commands "$sm_url"
    exit 0
  fi

  sm_token="$(resolve_sm_token)"
  if [ -z "$sm_token" ]; then
    warn "service-manager token not available; skipping automatic registration"
    if have service-manager; then
      warn "run: service-manager token show"
    fi
    print_manual_commands "$sm_url"
    exit 0
  fi
  py=""
  if have python3; then
    py="python3"
  elif have python; then
    py="python"
  fi
  if [ -z "$py" ]; then
    warn "python not found; skipping idempotent registration"
    print_manual_commands "$sm_url"
    exit 0
  fi

  work_dir="$(ensure_work_dir || true)"
  if [ -z "$work_dir" ] || [ ! -d "$work_dir" ]; then
    warn "mktemp not available; skipping service-manager registration to avoid predictable temp files"
    print_manual_commands "$sm_url"
    exit 0
  fi

  curl_cfg="$work_dir/curl.cfg"
  apply_file="$work_dir/registry-apply.json"

  cleanup() {
    for cleanup_file in "$work_dir"/*; do
      [ -e "$cleanup_file" ] || continue
      rm -f "$cleanup_file" >/dev/null 2>&1 || true
    done
    rmdir "$work_dir" >/dev/null 2>&1 || true
  }
  trap cleanup 0 INT HUP TERM

  write_curl_cfg "$curl_cfg" "$sm_token"

  core_port="${APP_BACKEND_PORT:-${SMALLPHONE_PORT:-22000}}"
  core_host="${APP_BACKEND_HOST:-${SMALLPHONE_HOST:-127.0.0.1}}"
  frontend_port="${FRONTEND_PORT:-22080}"
  frontend_host="${FRONTEND_HOST:-127.0.0.1}"
  beta_port="${BETA_FRONTEND_PORT:-22082}"
  beta_host="${BETA_FRONTEND_HOST:-$frontend_host}"
  backend_port="${BACKEND_PORT:-22096}"
  backend_host="${BACKEND_HOST:-127.0.0.1}"

  service_ids="smallphone-core smallphone-frontend smallphone-frontend-beta smallphone-standalone-diary smallphone-standalone-like-girl smallphone-standalone-like-girl-clone smallphone-standalone-album smallphone-like-girl-source smallphone-sillytavern controlled-browser cloudcli"

  # Register the OpenCode backend only when the checkout exists.
  if [ -d "$PARENT_DIR/opencode" ]; then
    service_ids="${service_ids} smallphone-backend"
  else
    warn "opencode checkout not found at $PARENT_DIR/opencode; skipping smallphone-backend registration"
  fi

  for service_id in $service_ids; do
    emit_spec "$py" "$service_id" \
      "$core_host" "$core_port" \
      "$frontend_host" "$frontend_port" \
      "$beta_host" "$beta_port" \
      "$backend_host" "$backend_port" \
      "$sm_url" >"$work_dir/$service_id.json"
  done

  build_registry_apply_payload "$py" "$apply_file" "$work_dir" $service_ids
  purge_existing_services "$sm_url" "$curl_cfg" "$py" $service_ids
  apply_registry "$sm_url" "$curl_cfg" "$apply_file" $service_ids

  log "done"
}

if [ "${1:-}" = "--print-spec" ]; then
  print_spec "${2:-}"
else
  main "$@"
fi
