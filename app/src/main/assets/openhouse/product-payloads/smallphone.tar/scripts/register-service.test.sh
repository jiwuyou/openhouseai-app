#!/bin/sh
set -eu

SCRIPT_DIR=$(cd "$(dirname "$0")" >/dev/null 2>&1 && pwd)
REGISTER="$SCRIPT_DIR/register-service.sh"
WORK_DIR=$(mktemp -d "${TMPDIR:-/tmp}/smallphone-register-test.XXXXXX")
trap 'rm -rf "$WORK_DIR"' EXIT INT HUP TERM

SERVICE_MANAGER_TOKEN="must-not-enter-service-spec" \
  "$REGISTER" --print-spec smallphone-core > "$WORK_DIR/core.json"
"$REGISTER" --print-spec smallphone-frontend-beta > "$WORK_DIR/beta.json"
"$REGISTER" --print-spec smallphone-standalone-diary > "$WORK_DIR/diary.json"
"$REGISTER" --print-spec cloudcli > "$WORK_DIR/cloudcli.json"

python3 - "$WORK_DIR" <<'PY'
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
specs = {name: json.loads((root / f"{name}.json").read_text()) for name in ("core", "beta", "diary", "cloudcli")}

for name, spec in specs.items():
    assert spec["provider"] == "proot-distro", (name, spec["provider"])
    assert spec["runtime"] == {"distro": "ubuntu", "home": "/root", "user": "root"}
    assert "runtime:ubuntu" in spec["tags"]
    assert "manager:termux-native" in spec["tags"]
    assert spec["command"][:2] == ["sh", "-lc"]
    assert "unset LD_LIBRARY_PATH LD_PRELOAD PREFIX" in spec["command"][2]

core = specs["core"]
serialized = json.dumps(core)
assert "must-not-enter-service-spec" not in serialized
assert "SMALLPHONE_SERVICE_MANAGER_TOKEN" not in serialized
assert "./apps/core/run-managed.js" in core["command"]
assert "SMALLPHONE_COMPONENTS_DIR=/data/data/com.termux/files/home/.config/openhouseai/components.d" in core["command"]
assert "SMALLPHONE_MENU_OVERRIDES_FILE=/data/data/com.termux/files/home/.config/openhouseai/menu-overrides.json" in core["command"]
assert "SMALLPHONE_SERVICE_MANAGER_CONFIG_FILE=/data/data/com.termux/files/home/.config/openhouseai/service-manager/config.json" in core["command"]
assert "OPENHOUSE_ENDPOINTS_FILE=/data/data/com.termux/files/home/.config/openhouseai/runtime/endpoints.json" in core["command"]

assert "scripts/static-server.cjs" in specs["beta"]["command"]
assert "OPENHOUSE_ENDPOINTS_FILE=/data/data/com.termux/files/home/.config/openhouseai/runtime/endpoints.json" in specs["beta"]["command"]
for name, endpoint_name in (("core", "api"), ("beta", "web"), ("diary", "web"), ("cloudcli", "web")):
    spec = specs[name]
    assert len(spec["ports"]) == 1, name
    port = spec["ports"][0]
    assert port["name"] == endpoint_name, (name, port)
    assert port["dynamic"] is True, name
    assert port["pool"] == "local-web", name
    assert port["endpoint"] == {"scheme": "http", "path": "/"}, name
    assert f"{{{{port:{endpoint_name}}}}}" in json.dumps(spec), name

print("register-service tests passed")
PY

grep -q '/api/v1/registry/apply' "$REGISTER"

MOCK_BIN="$WORK_DIR/mock-bin"
MOCK_LOG="$WORK_DIR/mock-curl.log"
mkdir -p "$MOCK_BIN"
cat > "$MOCK_BIN/curl" <<'SH'
#!/bin/sh
set -eu
method=GET
url=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    -X)
      method="$2"
      shift 2
      ;;
    -K|--max-time|--data-binary)
      shift 2
      ;;
    http://*|https://*)
      url="$1"
      shift
      ;;
    *)
      shift
      ;;
  esac
done
printf '%s %s\n' "$method" "$url" >> "$MOCK_CURL_LOG"
case "$url" in
  */api/v1/health)
    printf '%s' '{"ok":true}'
    ;;
  */api/v1/services)
    printf '%s' '[{"id":"smallphone-core","spec":{"name":"smallphone-core"}},{"id":"hash-core-old","spec":{"name":"smallphone-core"}},{"id":"unrelated","spec":{"name":"unrelated"}}]'
    ;;
  *)
    printf '%s' '{}'
    ;;
esac
SH
chmod +x "$MOCK_BIN/curl"

run_mock_registration() {
  : > "$MOCK_LOG"
  PATH="$MOCK_BIN:$PATH" \
    MOCK_CURL_LOG="$MOCK_LOG" \
    SERVICE_MANAGER_TOKEN="test-token" \
    "$REGISTER" >/dev/null

  python3 - "$MOCK_LOG" <<'PY'
import pathlib
import sys

events = pathlib.Path(sys.argv[1]).read_text().splitlines()

def index(fragment):
    return next(i for i, event in enumerate(events) if fragment in event)

apply_index = index("POST http://127.0.0.1:20087/api/v1/registry/apply")
for service_id in ("smallphone-core", "hash-core-old"):
    stop_index = index(f"POST http://127.0.0.1:20087/api/v1/services/{service_id}/stop")
    delete_index = index(f"DELETE http://127.0.0.1:20087/api/v1/services/{service_id}")
    assert stop_index < delete_index < apply_index, (service_id, events)

assert not any("/api/v1/services/unrelated/" in event for event in events), events
assert not any(event.endswith("/start") for event in events), events
assert index("POST http://127.0.0.1:20087/api/v1/services/smallphone-core/register") > apply_index
print("register-service replace tests passed")
PY
}

run_mock_registration
run_mock_registration
