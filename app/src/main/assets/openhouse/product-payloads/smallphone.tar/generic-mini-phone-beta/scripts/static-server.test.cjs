const test = require("node:test");
const assert = require("node:assert/strict");

const {
  appendApiPath,
  resolveRuntimeConfig,
} = require("./static-server.cjs");

test("runtime config reads the public endpoint snapshot without service-manager token or fetch", () => {
  let calls = 0;
  const runtime = resolveRuntimeConfig({
    endpointReader: {
      resolve(serviceId, endpointName) {
        calls += 1;
        assert.equal(serviceId, "smallphone-core");
        assert.equal(endpointName, "api");
        return { url: "http://127.0.0.1:24731/", generation: 8 };
      },
    },
  });

  assert.equal(calls, 1);
  assert.deepEqual(runtime, {
    apiBaseUrl: "http://127.0.0.1:24731/api",
    serviceRef: { serviceId: "smallphone-core", endpointName: "api" },
    generation: 8,
  });
  assert.doesNotMatch(JSON.stringify(runtime), /token|Authorization/i);
});

test("runtime config rejects missing snapshot endpoint and non-http core endpoints", () => {
  assert.throws(
    () => resolveRuntimeConfig({ endpointReader: { resolve: () => null } }),
    /snapshot is unavailable/,
  );
  assert.throws(() => appendApiPath("file:///tmp/core"), /http or https/);
});
