const fs = require("fs");
const http = require("http");
const path = require("path");
const {
  OpenHouseEndpointSnapshotReader,
} = require("../../smallphone-app/packages/shared/openhouse-endpoints");

const contentTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".ico": "image/x-icon",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json",
  ".mjs": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".webp": "image/webp",
};

const runtimeServiceRef = Object.freeze({
  serviceId: "smallphone-core",
  endpointName: "api",
});
const defaultEndpointReader = new OpenHouseEndpointSnapshotReader();

function send(res, status, body, headers = {}, method = "GET") {
  const payload = Buffer.isBuffer(body) ? body : Buffer.from(String(body || ""));
  res.writeHead(status, {
    "Content-Length": payload.length,
    ...headers,
  });
  if (method === "HEAD") return res.end();
  res.end(payload);
}

function sendJson(res, status, payload, method = "GET") {
  send(res, status, JSON.stringify(payload), {
    "Cache-Control": "no-store",
    "Content-Type": "application/json; charset=utf-8",
  }, method);
}

function appendApiPath(endpointUrl) {
  const parsed = new URL(String(endpointUrl || "").trim());
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("smallphone-core endpoint must use http or https");
  }
  parsed.username = "";
  parsed.password = "";
  parsed.search = "";
  parsed.hash = "";
  const basePath = parsed.pathname.replace(/\/+$/, "");
  parsed.pathname = `${basePath}/api`.replace(/\/+/g, "/");
  return parsed.toString().replace(/\/$/, "");
}

function resolveRuntimeConfig(options = {}) {
  const endpointReader = options.endpointReader || defaultEndpointReader;
  const endpoint = endpointReader.resolve(runtimeServiceRef.serviceId, runtimeServiceRef.endpointName);
  if (!endpoint?.url) throw new Error("smallphone-core endpoint snapshot is unavailable");
  return {
    apiBaseUrl: appendApiPath(endpoint.url),
    serviceRef: runtimeServiceRef,
    generation: Number(endpoint.generation || 0),
  };
}

function resolveRequestPath(root, reqUrl, origin) {
  const url = new URL(reqUrl, origin);
  let pathname;
  try {
    pathname = decodeURIComponent(url.pathname);
  } catch {
    return null;
  }
  if (pathname === "/") pathname = "/index.html";

  const filePath = path.resolve(root, `.${pathname}`);
  if (filePath !== root && !filePath.startsWith(`${root}${path.sep}`)) {
    return null;
  }
  return filePath;
}

function createStaticServer(options = {}) {
  const port = Number(options.port ?? process.argv[2] ?? process.env.PORT);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("SmallPhone frontend requires a service-manager assigned PORT");
  }
  const host = String(options.host || process.argv[3] || process.env.HOST || "127.0.0.1");
  const root = path.resolve(options.root || process.cwd());
  const runtimeResolver = options.runtimeResolver || (() => resolveRuntimeConfig(options));
  const origin = `http://${host}:${port}`;

  return http.createServer(async (req, res) => {
    if (req.method !== "GET" && req.method !== "HEAD") {
      return send(res, 405, "Method Not Allowed", { Allow: "GET, HEAD" }, req.method);
    }

    const url = new URL(req.url, origin);
    if (url.pathname === "/openhouse-runtime.json") {
      try {
        return sendJson(res, 200, await runtimeResolver(), req.method);
      } catch (error) {
        return sendJson(res, 503, {
          error: error instanceof Error ? error.message : "runtime endpoint unavailable",
          serviceRef: runtimeServiceRef,
        }, req.method);
      }
    }

    const filePath = resolveRequestPath(root, req.url, origin);
    if (!filePath) return send(res, 400, "Bad Request", {}, req.method);

    fs.stat(filePath, (statErr, stat) => {
      const finalPath = !statErr && stat.isDirectory()
        ? path.join(filePath, "index.html")
        : filePath;

      fs.readFile(finalPath, (readErr, data) => {
        if (readErr) return send(res, 404, "Not Found", {}, req.method);

        const type = contentTypes[path.extname(finalPath).toLowerCase()]
          || "application/octet-stream";
        send(res, 200, data, { "Content-Type": type }, req.method);
      });
    });
  });
}

if (require.main === module) {
  const server = createStaticServer();
  server.listen(Number(process.argv[2] || process.env.PORT), process.argv[3] || process.env.HOST || "127.0.0.1", () => {
    const listening = server.address();
    console.log(`[smallphone-frontend-beta] serving ${path.resolve(process.cwd())} at http://${listening.address}:${listening.port}`);
  });
}

module.exports = {
  appendApiPath,
  createStaticServer,
  resolveRuntimeConfig,
  runtimeServiceRef,
};
