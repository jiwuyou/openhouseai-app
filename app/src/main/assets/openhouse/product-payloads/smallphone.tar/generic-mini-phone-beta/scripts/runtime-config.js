export const OPENHOUSE_RUNTIME_PATH = '/openhouse-runtime.json';

function normalizeHttpUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  let parsed;
  try {
    parsed = new URL(raw);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return '';
  parsed.username = '';
  parsed.password = '';
  parsed.search = '';
  parsed.hash = '';
  return parsed.toString().replace(/\/$/, '');
}

export function normalizeOpenHouseRuntimeConfig(payload) {
  const serviceRef = payload?.serviceRef && typeof payload.serviceRef === 'object'
    ? payload.serviceRef
    : {};
  const apiBaseUrl = normalizeHttpUrl(payload?.apiBaseUrl);
  if (!apiBaseUrl) throw new Error('运行时配置没有可用的 SmallPhone API endpoint。');
  if (serviceRef.serviceId !== 'smallphone-core' || serviceRef.endpointName !== 'api') {
    throw new Error('运行时配置中的 SmallPhone serviceRef 无效。');
  }
  return {
    apiBaseUrl,
    serviceRef: {
      serviceId: 'smallphone-core',
      endpointName: 'api',
    },
    generation: Number(payload?.generation || 0),
  };
}

export async function fetchOpenHouseRuntimeConfig(options = {}) {
  const fetchImpl = options.fetchImpl || globalThis.fetch?.bind(globalThis);
  if (!fetchImpl) throw new Error('浏览器不支持读取运行时配置。');
  const response = await fetchImpl(options.url || OPENHOUSE_RUNTIME_PATH, {
    method: 'GET',
    headers: { Accept: 'application/json' },
    cache: 'no-store',
    signal: options.signal,
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(detail || `运行时配置不可用：${response.status}`);
  }
  return normalizeOpenHouseRuntimeConfig(await response.json());
}
